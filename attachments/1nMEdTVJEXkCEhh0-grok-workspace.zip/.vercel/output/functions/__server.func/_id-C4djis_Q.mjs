import { S as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { c as useAppStore, o as Route$8 } from "./_ssr/router-z_xU0oK5.mjs";
import { t as PersonAvatar } from "./_ssr/avatar-sLvn2RL6.mjs";
import { o as relativeTime } from "./_ssr/format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./_ssr/page-header-DdUbVup6.mjs";
import { t as EmptyState } from "./_ssr/empty-state-CivQ_9Zu.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./_ssr/card-B_I_naJs.mjs";
import { t as Badge } from "./_ssr/badge-Caj8QGQQ.mjs";
import { i as StatusBadge } from "./_ssr/status-badge-CgLI5ccz.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./_ssr/tabs-BQwTj3Mx.mjs";
import { t as Switch } from "./_ssr/switch-95CbCe8f.mjs";
import { t as StatCard } from "./_ssr/stat-card-0qMA4LOU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-C4djis_Q.js
var import_jsx_runtime = require_jsx_runtime();
function EmployeeDetailPage({ employeeId }) {
	const employee = useAppStore((s) => s.employees.find((e) => e.id === employeeId));
	const students = useAppStore((s) => s.students.filter((st) => st.employeeId === employeeId));
	const applications = useAppStore((s) => s.applications.filter((a) => a.employeeId === employeeId));
	const activity = useAppStore((s) => s.auditEvents.filter((e) => e.userId === employeeId).slice(0, 12));
	const updateEmployee = useAppStore((s) => s.updateEmployee);
	const navigate = useNavigate();
	if (!employee) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Employee not found",
		actionLabel: "Back",
		onAction: () => void navigate({ to: "/admin/employees" })
	});
	const offers = students.filter((s) => s.status === "Offered" || s.status === "Got Visa").length;
	const visas = students.filter((s) => s.status === "Got Visa").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: employee.name,
				description: `${employee.title} · ${employee.department}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
					name: employee.name,
					hue: employee.avatarHue,
					className: "size-12"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: employee.email
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: employee.status === "Active" ? "success" : "secondary",
					children: employee.status
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Students",
						value: students.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Applications",
						value: applications.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Offers",
						value: offers
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Visas",
						value: visas
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "personal",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "personal",
							children: "Personal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "students",
							children: "Assigned students"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "activity",
							children: "Activity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "permissions",
							children: "Permissions"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "personal",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-5 grid gap-3 sm:grid-cols-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: employee.phone
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Joined"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: relativeTime(employee.joinedAt)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Last active"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: relativeTime(employee.lastActive)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Role"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium capitalize",
									children: employee.role
								})] })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "students",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "overflow-hidden p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-table",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-left text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-5 py-2",
												children: "Student"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-5 py-2",
												children: "Country"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-5 py-2",
												children: "Status"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: students.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "cursor-pointer border-b last:border-0 hover:bg-secondary/60",
									onClick: () => void navigate({ to: `/admin/students/${s.id}` }),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: s.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: s.country
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s.status })
										})
									]
								}, s.id)) })]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "activity",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-5 space-y-3",
							children: activity.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: e.details
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-micro text-muted-foreground",
									children: [
										e.recordId,
										" · ",
										relativeTime(e.timestamp)
									]
								})]
							}, e.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "permissions",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Access" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center justify-between text-sm",
								children: ["Active account", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: employee.status === "Active",
									onCheckedChange: (v) => {
										updateEmployee(employee.id, { status: v ? "Active" : "Inactive" });
										toast.success("Employee updated");
									}
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Permissions are simulated in this prototype."
							})]
						})] })
					})
				]
			})
		]
	});
}
function Page() {
	const { id } = Route$8.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeDetailPage, { employeeId: id });
}
//#endregion
export { Page as component };
