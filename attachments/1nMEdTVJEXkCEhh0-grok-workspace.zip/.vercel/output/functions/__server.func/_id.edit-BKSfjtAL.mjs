import { F as require_jsx_runtime } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as Route } from "./_ssr/router-z_xU0oK5.mjs";
import { t as StudentFormPage } from "./_ssr/student-form-D4fthVCH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id.edit-BKSfjtAL.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentFormPage, { studentId: id });
}
//#endregion
export { Page as component };
