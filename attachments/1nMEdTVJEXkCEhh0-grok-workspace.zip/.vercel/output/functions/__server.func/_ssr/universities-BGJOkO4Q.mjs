import { t as UniversitiesPage } from "./universities-page-C1lgr0bw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/universities-BGJOkO4Q.js
var SplitComponent = UniversitiesPage;
//#endregion
export { SplitComponent as component };
