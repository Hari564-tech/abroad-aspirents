import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { $ as ChevronRight, J as Columns3, et as ChevronLeft, g as Search, tt as ChevronDown } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { n as DropdownMenuCheckboxItem, o as DropdownMenuTrigger, r as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-CuItBiKD.mjs";
import { t as EmptyState } from "./empty-state-CivQ_9Zu.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as Checkbox } from "./checkbox-CtJUj_K5.mjs";
import { a as getPaginationRowModel, i as getFilteredRowModel, n as useReactTable, o as getSortedRowModel, r as getCoreRowModel, t as flexRender } from "../_libs/@tanstack/react-table+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-table-CQHsEWvg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Table$1 = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "relative w-full overflow-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
		ref,
		className: cn("w-full caption-bottom text-table", className),
		...props
	})
}));
Table$1.displayName = "Table";
var TableHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
	ref,
	className: cn("[&_tr]:border-b", className),
	...props
}));
TableHeader.displayName = "TableHeader";
var TableBody = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
	ref,
	className: cn("[&_tr:last-child]:border-0", className),
	...props
}));
TableBody.displayName = "TableBody";
var TableRow = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
	ref,
	className: cn("border-b border-border transition-colors hover:bg-secondary/60 data-[state=selected]:bg-accent", className),
	...props
}));
TableRow.displayName = "TableRow";
var TableHead = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
	ref,
	className: cn("h-10 px-3 text-left align-middle text-xs font-medium text-muted-foreground whitespace-nowrap", className),
	...props
}));
TableHead.displayName = "TableHead";
var TableCell = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
	ref,
	className: cn("px-3 py-2.5 align-middle", className),
	...props
}));
TableCell.displayName = "TableCell";
function DataTable({ data, columns, searchPlaceholder = "Search…", globalFilter, onGlobalFilterChange, extraFilters, onRowClick, getRowId, getRowClassName, emptyTitle = "No results", emptyDescription = "Try changing your filters or search query.", onClearFilters, selectable, renderMobileCard, pageSize = 10, toolbarEnd, bulkActions }) {
	const [sorting, setSorting] = (0, import_react.useState)([]);
	const [visibility, setVisibility] = (0, import_react.useState)({});
	const [rowSelection, setRowSelection] = (0, import_react.useState)({});
	const [internalFilter, setInternalFilter] = (0, import_react.useState)("");
	const filter = globalFilter ?? internalFilter;
	const setFilter = onGlobalFilterChange ?? setInternalFilter;
	const cols = (0, import_react.useMemo)(() => {
		if (!selectable) return columns;
		return [{
			id: "select",
			header: ({ table }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
				checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
				onCheckedChange: (v) => table.toggleAllPageRowsSelected(!!v),
				"aria-label": "Select all"
			}),
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
				checked: row.getIsSelected(),
				onCheckedChange: (v) => row.toggleSelected(!!v),
				"aria-label": "Select row",
				onClick: (e) => e.stopPropagation()
			}),
			enableSorting: false
		}, ...columns];
	}, [columns, selectable]);
	const table = useReactTable({
		data,
		columns: cols,
		state: {
			sorting,
			columnVisibility: visibility,
			rowSelection,
			globalFilter: filter
		},
		onSortingChange: setSorting,
		onColumnVisibilityChange: setVisibility,
		onRowSelectionChange: setRowSelection,
		getCoreRowModel: getCoreRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		initialState: { pagination: { pageSize } },
		getRowId: getRowId ? (row) => getRowId(row) : void 0,
		globalFilterFn: "includesString"
	});
	const selected = table.getSelectedRowModel().rows.map((r) => r.original);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 lg:flex-row lg:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: filter,
						onChange: (e) => setFilter(e.target.value),
						placeholder: searchPlaceholder,
						className: "pl-9",
						"aria-label": searchPlaceholder
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						extraFilters,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								className: "hidden sm:inline-flex",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Columns3, { className: "size-3.5" }),
									"Columns",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 opacity-60" })
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
							align: "end",
							children: table.getAllColumns().filter((c) => c.getCanHide()).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
								checked: c.getIsVisible(),
								onCheckedChange: (v) => c.toggleVisibility(!!v),
								className: "capitalize",
								children: c.id
							}, c.id))
						})] }),
						toolbarEnd
					]
				})]
			}),
			selectable && selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 rounded-lg bg-accent px-3 py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-medium",
					children: [selected.length, " selected"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [bulkActions?.(selected, () => table.resetRowSelection()), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "xs",
						variant: "ghost",
						onClick: () => table.resetRowSelection(),
						children: "Clear"
					})]
				})]
			}),
			renderMobileCard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 md:hidden",
				children: table.getRowModel().rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: emptyTitle,
					description: emptyDescription,
					actionLabel: onClearFilters ? "Clear filters" : void 0,
					onAction: onClearFilters
				}) : table.getRowModel().rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("rounded-xl bg-card p-3 shadow-card", onRowClick && "cursor-pointer", getRowClassName?.(row.original)),
					onClick: () => onRowClick?.(row.original),
					children: renderMobileCard(row.original)
				}, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("overflow-hidden rounded-xl bg-card shadow-card", renderMobileCard && "hidden md:block"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
					className: "sticky top-0 z-10 bg-card",
					children: table.getHeaderGroups().map((hg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
						className: "hover:bg-transparent",
						children: hg.headers.map((header) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableHead, {
							className: header.column.getCanSort() ? "cursor-pointer select-none" : void 0,
							onClick: header.column.getToggleSortingHandler(),
							children: [header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext()), {
								asc: " ↑",
								desc: " ↓"
							}[header.column.getIsSorted()] ?? null]
						}, header.id))
					}, hg.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: table.getRowModel().rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
					className: "hover:bg-transparent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						colSpan: cols.length,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: emptyTitle,
							description: emptyDescription,
							actionLabel: onClearFilters ? "Clear filters" : void 0,
							onAction: onClearFilters
						})
					})
				}) : table.getRowModel().rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, {
					"data-state": row.getIsSelected() && "selected",
					className: cn(onRowClick ? "cursor-pointer" : void 0, getRowClassName?.(row.original)),
					onClick: () => onRowClick?.(row.original),
					children: row.getVisibleCells().map((cell) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: flexRender(cell.column.columnDef.cell, cell.getContext()) }, cell.id))
				}, row.id)) })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums",
					children: [table.getFilteredRowModel().rows.length, " records"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: !table.getCanPreviousPage(),
							onClick: () => table.previousPage(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Prev"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								table.getState().pagination.pageIndex + 1,
								" / ",
								table.getPageCount() || 1
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: !table.getCanNextPage(),
							onClick: () => table.nextPage(),
							children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { DataTable as t };
