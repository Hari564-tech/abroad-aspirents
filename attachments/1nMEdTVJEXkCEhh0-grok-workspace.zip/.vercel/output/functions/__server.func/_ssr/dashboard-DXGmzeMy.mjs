import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { a as formatShortDate, o as relativeTime } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B_I_naJs.mjs";
import { i as StatusBadge, n as PriorityBadge } from "./status-badge-CgLI5ccz.mjs";
import { r as useScopedIds, t as greetingName } from "./scoped-BYNid1DS.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DocumentsAttentionWidget } from "./documents-attention-widget-CxC1aue4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DXGmzeMy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EmployeeDashboardPage() {
	const user = useAppStore((s) => s.currentUser);
	const updateWork = useAppStore((s) => s.updateWorkItem);
	const { students, workItems } = useScopedIds();
	const { base } = useWorkspace();
	const navigate = useNavigate();
	const stats = (0, import_react.useMemo)(() => {
		return {
			students: students.length,
			apps: students.filter((s) => s.status === "Applications Started" || s.status === "Shortlisting Sent").length,
			offers: students.filter((s) => s.status === "Offered").length,
			waiting: students.filter((s) => s.status === "Waiting").length,
			visa: students.filter((s) => s.status === "Got Visa").length,
			pay: students.filter((s) => s.paymentStatus !== "Paid").length
		};
	}, [students]);
	const leads = useAppStore((s) => s.leads).filter((l) => l.employeeId === user?.id && l.pipeline === "New");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: greetingName(user?.name ?? "there"),
				description: "Here's your current workload.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void navigate({ to: `${base}/students/new` }),
					children: "Add student"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 grid-cols-2 xl:grid-cols-4 2xl:grid-cols-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "My students",
						value: stats.students
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "New leads",
						value: leads.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Applications",
						value: stats.apps
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Offers",
						value: stats.offers
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Waiting",
						value: stats.waiting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Visa received",
						value: stats.visa
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Payment pending",
						value: stats.pay
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentsAttentionWidget, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "My work queue" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-table",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: "border-b",
							children: [
								"Student",
								"Task",
								"Priority",
								"Deadline",
								"Status"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-2 font-medium",
								children: h
							}, h))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [workItems.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "px-5 py-10 text-center text-sm text-muted-foreground",
						children: "Queue is clear for now."
					}) }), workItems.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-medium hover:underline",
									onClick: () => void navigate({ to: `${base}/students/${w.studentId}` }),
									children: w.studentName
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: w.task
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityBadge, { priority: w.priority })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5 text-muted-foreground",
								children: formatShortDate(w.deadline)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "xs",
									variant: w.status === "Done" ? "secondary" : "outline",
									onClick: () => updateWork(w.id, { status: w.status === "Done" ? "Pending" : "Done" }),
									children: w.status
								})
							})
						]
					}, w.id))] })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "My students" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => void navigate({ to: `${base}/students` }),
					children: "View all"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-table",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: "border-b",
							children: [
								"Student",
								"Country",
								"Status",
								"Updated"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-2 font-medium",
								children: h
							}, h))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: students.slice(0, 8).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "cursor-pointer border-b last:border-0 hover:bg-secondary/60",
						onClick: () => void navigate({ to: `${base}/students/${s.id}` }),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
										name: s.name,
										hue: s.avatarHue,
										className: "size-6"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-medium",
										children: s.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-micro text-muted-foreground",
										children: s.id
									})] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: s.country
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s.status })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-2.5 text-muted-foreground",
								children: relativeTime(s.updatedAt)
							})
						]
					}, s.id)) })]
				})
			})] })
		]
	});
}
var SplitComponent = EmployeeDashboardPage;
//#endregion
export { SplitComponent as component };
