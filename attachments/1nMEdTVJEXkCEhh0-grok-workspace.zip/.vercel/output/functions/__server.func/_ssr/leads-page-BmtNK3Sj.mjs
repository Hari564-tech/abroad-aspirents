import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { N as LayoutGrid, u as Table, x as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { P as INTAKES, c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { o as relativeTime } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as Card } from "./card-B_I_naJs.mjs";
import { n as useEmployeeMap, r as useScopedIds } from "./scoped-BYNid1DS.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-B8yEom4G.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as FormField } from "./form-field-LURrrOeP.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
import { t as FilterSelect } from "./filter-select-DRpDDDny.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-page-BmtNK3Sj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PIPELINES = [
	"New",
	"Shortlisting",
	"Applications",
	"Offer",
	"Visa"
];
function LeadsPage() {
	const { leads } = useScopedIds();
	const employees = useAppStore((s) => s.employees);
	const upsertLead = useAppStore((s) => s.upsertLead);
	const empMap = useEmployeeMap();
	const currentUser = useAppStore((s) => s.currentUser);
	const [view, setView] = (0, import_react.useState)("pipeline");
	const [employee, setEmployee] = (0, import_react.useState)("all");
	const [type, setType] = (0, import_react.useState)("all");
	const [country, setCountry] = (0, import_react.useState)("all");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [intake, setIntake] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)({});
	const filtered = (0, import_react.useMemo)(() => leads.filter((l) => {
		if (employee !== "all" && l.employeeId !== employee) return false;
		if (type !== "all" && l.type !== type) return false;
		if (country !== "all" && l.country !== country) return false;
		if (status !== "all" && l.pipeline !== status) return false;
		if (intake !== "all" && l.intake !== intake) return false;
		return true;
	}), [
		leads,
		employee,
		type,
		country,
		status,
		intake
	]);
	const columns = (0, import_react.useMemo)(() => [
		{
			accessorKey: "name",
			header: "Lead"
		},
		{
			accessorKey: "type",
			header: "Type"
		},
		{
			accessorKey: "b2bOrg",
			header: "B2B org",
			cell: ({ row }) => row.original.b2bOrg ?? "—"
		},
		{
			accessorKey: "country",
			header: "Country"
		},
		{
			accessorKey: "intake",
			header: "Intake"
		},
		{
			id: "emp",
			header: "Employee",
			cell: ({ row }) => empMap[row.original.employeeId]?.name ?? "—"
		},
		{
			accessorKey: "pipeline",
			header: "Status"
		},
		{
			accessorKey: "updatedAt",
			header: "Updated",
			cell: ({ row }) => relativeTime(row.original.updatedAt)
		}
	], [empMap]);
	function create() {
		if (!draft.name) {
			toast.error("Name is required");
			return;
		}
		const id = `LD-${Math.floor(100 + Math.random() * 900)}`;
		const now = (/* @__PURE__ */ new Date()).toISOString();
		upsertLead({
			id,
			name: draft.name,
			email: draft.email ?? "",
			phone: draft.phone ?? "",
			country: draft.country ?? "Germany",
			intake: draft.intake ?? "Winter 2026",
			employeeId: draft.employeeId ?? currentUser?.id ?? employees[1]?.id ?? "EMP-002",
			type: draft.type ?? "Direct",
			b2bOrg: draft.type === "B2B" ? draft.b2bOrg : void 0,
			pipeline: "New",
			status: "New",
			createdAt: now,
			updatedAt: now,
			notes: ""
		});
		toast.success("Lead created");
		setOpen(false);
		setDraft({});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Leads",
				description: "Track inbound Direct and B2B enquiries through the pipeline.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex rounded-lg bg-secondary p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "xs",
						variant: view === "table" ? "default" : "ghost",
						onClick: () => setView("table"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, { className: "size-3.5" }), " Table"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "xs",
						variant: view === "pipeline" ? "default" : "ghost",
						onClick: () => setView("pipeline"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-3.5" }), " Pipeline"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add lead"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: employee,
						onChange: setEmployee,
						placeholder: "Employee",
						options: employees.filter((e) => e.role === "employee").map((e) => ({
							value: e.id,
							label: e.name
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: type,
						onChange: setType,
						placeholder: "Lead type",
						options: ["Direct", "B2B"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: country,
						onChange: setCountry,
						placeholder: "Country",
						options: [
							"Germany",
							"UK",
							"USA"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: status,
						onChange: setStatus,
						placeholder: "Status",
						options: PIPELINES
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: intake,
						onChange: setIntake,
						placeholder: "Intake",
						options: INTAKES
					})
				]
			}),
			view === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: filtered,
				columns,
				getRowId: (l) => l.id,
				searchPlaceholder: "Search leads…",
				emptyTitle: "No leads found",
				onClearFilters: () => {
					setEmployee("all");
					setType("all");
					setCountry("all");
					setStatus("all");
					setIntake("all");
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 overflow-x-auto pb-2 md:grid-cols-5",
				children: PIPELINES.map((col) => {
					const items = filtered.filter((l) => l.pipeline === col);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-[200px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground",
							children: [col, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: items.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [items.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: l.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-micro text-muted-foreground",
										children: [
											l.country,
											" · ",
											l.type,
											l.b2bOrg ? ` · ${l.b2bOrg}` : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: l.pipeline,
										onValueChange: (v) => {
											upsertLead({
												...l,
												pipeline: v,
												status: v,
												updatedAt: (/* @__PURE__ */ new Date()).toISOString()
											});
											toast.success("Lead moved");
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "mt-2 h-7 text-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: PIPELINES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: p,
											children: p
										}, p)) })]
									})
								]
							}, l.id)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("rounded-xl border border-dashed px-3 py-8 text-center text-xs text-muted-foreground"),
								children: "Empty"
							})]
						})]
					}, col);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New lead" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Name",
							required: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: draft.name ?? "",
								onChange: (e) => setDraft({
									...draft,
									name: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Email",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: draft.email ?? "",
								onChange: (e) => setDraft({
									...draft,
									email: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Phone",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: draft.phone ?? "",
								onChange: (e) => setDraft({
									...draft,
									phone: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Country",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: draft.country ?? "Germany",
								onValueChange: (v) => setDraft({
									...draft,
									country: v
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
									"Germany",
									"UK",
									"USA"
								].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: c,
									children: c
								}, c)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Lead type",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: draft.type ?? "Direct",
								onValueChange: (v) => setDraft({
									...draft,
									type: v
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Direct",
									children: "Direct"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "B2B",
									children: "B2B"
								})] })]
							})
						}),
						draft.type === "B2B" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "B2B organization",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: draft.b2bOrg ?? "",
								onChange: (e) => setDraft({
									...draft,
									b2bOrg: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: create,
							children: "Create lead"
						})
					]
				})] })
			})
		]
	});
}
//#endregion
export { LeadsPage as t };
