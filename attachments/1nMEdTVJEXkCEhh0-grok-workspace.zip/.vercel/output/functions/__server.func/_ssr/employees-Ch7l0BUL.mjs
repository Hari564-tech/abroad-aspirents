import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { o as relativeTime } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as Badge } from "./badge-Caj8QGQQ.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employees-Ch7l0BUL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EmployeesPage() {
	const employees = useAppStore((s) => s.employees);
	const students = useAppStore((s) => s.students);
	const applications = useAppStore((s) => s.applications);
	const navigate = useNavigate();
	const staff = employees.filter((e) => e.role === "employee");
	const stats = {
		total: staff.length,
		active: staff.filter((e) => e.status === "Active").length,
		inactive: staff.filter((e) => e.status === "Inactive").length,
		newThis: staff.filter((e) => Date.now() - new Date(e.joinedAt).getTime() < 2592e6).length
	};
	const columns = (0, import_react.useMemo)(() => [
		{
			accessorKey: "name",
			header: "Employee",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
					name: row.original.name,
					hue: row.original.avatarHue,
					className: "size-7"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: row.original.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-micro text-muted-foreground",
					children: row.original.email
				})] })]
			})
		},
		{
			accessorKey: "title",
			header: "Role"
		},
		{
			id: "students",
			header: "Students",
			cell: ({ row }) => students.filter((s) => s.employeeId === row.original.id).length
		},
		{
			id: "apps",
			header: "Applications",
			cell: ({ row }) => applications.filter((a) => a.employeeId === row.original.id).length
		},
		{
			id: "offers",
			header: "Offers",
			cell: ({ row }) => students.filter((s) => s.employeeId === row.original.id && (s.status === "Offered" || s.status === "Got Visa")).length
		},
		{
			id: "visa",
			header: "Visa",
			cell: ({ row }) => students.filter((s) => s.employeeId === row.original.id && s.status === "Got Visa").length
		},
		{
			accessorKey: "status",
			header: "Status",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: row.original.status === "Active" ? "success" : "secondary",
				children: row.original.status
			})
		},
		{
			accessorKey: "lastActive",
			header: "Last active",
			cell: ({ row }) => relativeTime(row.original.lastActive)
		}
	], [students, applications]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Employees",
				description: "Directory, assignments and performance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total employees",
						value: stats.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active",
						value: stats.active
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Inactive",
						value: stats.inactive
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "New this month",
						value: stats.newThis
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: staff,
				columns,
				getRowId: (e) => e.id,
				searchPlaceholder: "Search employees…",
				onRowClick: (e) => void navigate({ to: `/admin/employees/${e.id}` }),
				emptyTitle: "No employees found",
				renderMobileCard: (e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
						name: e.name,
						hue: e.avatarHue
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: e.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: e.title
					})] })]
				})
			})
		]
	});
}
var SplitComponent = EmployeesPage;
//#endregion
export { SplitComponent as component };
