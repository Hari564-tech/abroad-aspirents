import { t as PaymentsPage } from "./payments-page-sM-PKaYm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/payments-DHG3cQZH.js
var SplitComponent = PaymentsPage;
//#endregion
export { SplitComponent as component };
