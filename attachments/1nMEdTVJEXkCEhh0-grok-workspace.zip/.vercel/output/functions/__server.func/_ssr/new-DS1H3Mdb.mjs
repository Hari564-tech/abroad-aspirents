import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as StudentFormPage } from "./student-form-D4fthVCH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-DS1H3Mdb.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentFormPage, {});
//#endregion
export { SplitComponent as component };
