import { t as DocumentsPage } from "./documents-page-cKHz8Rsg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-BlMIv4rQ.js
var SplitComponent = DocumentsPage;
//#endregion
export { SplitComponent as component };
