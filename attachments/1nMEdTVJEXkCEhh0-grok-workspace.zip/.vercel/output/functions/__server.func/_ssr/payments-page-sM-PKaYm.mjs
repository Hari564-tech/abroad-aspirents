import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { i as formatLakhs, o as relativeTime, r as formatINR } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as PaymentBadge } from "./status-badge-CgLI5ccz.mjs";
import { i as useStudentMap, r as useScopedIds } from "./scoped-BYNid1DS.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-B8yEom4G.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as FormField } from "./form-field-LURrrOeP.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/payments-page-sM-PKaYm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PaymentsPage() {
	const { payments } = useScopedIds();
	const students = useStudentMap();
	const updatePayment = useAppStore((s) => s.updatePayment);
	const { base } = useWorkspace();
	const navigate = useNavigate();
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("");
	const totals = (0, import_react.useMemo)(() => {
		return {
			revenue: payments.reduce((n, p) => n + p.totalFee, 0),
			collected: payments.reduce((n, p) => n + (p.totalFee - p.remaining - p.discount), 0),
			pending: payments.reduce((n, p) => n + p.remaining, 0),
			discounts: payments.reduce((n, p) => n + p.discount, 0)
		};
	}, [payments]);
	const columns = (0, import_react.useMemo)(() => [
		{
			id: "student",
			header: "Student",
			cell: ({ row }) => students[row.original.studentId]?.name ?? row.original.studentId
		},
		{
			accessorKey: "totalFee",
			header: "Total fee",
			cell: ({ row }) => formatINR(row.original.totalFee)
		},
		{
			accessorKey: "initialPayment",
			header: "Initial payment",
			cell: ({ row }) => formatINR(row.original.initialPayment)
		},
		{
			accessorKey: "remaining",
			header: "Remaining",
			cell: ({ row }) => formatINR(row.original.remaining)
		},
		{
			accessorKey: "discount",
			header: "Discount",
			cell: ({ row }) => formatINR(row.original.discount)
		},
		{
			accessorKey: "status",
			header: "Status",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, { status: row.original.status })
		},
		{
			id: "last",
			header: "Last payment",
			cell: ({ row }) => row.original.lastPayment ? relativeTime(row.original.lastPayment) : "—"
		},
		{
			id: "act",
			header: "",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "xs",
				variant: "outline",
				onClick: (e) => {
					e.stopPropagation();
					setEdit(row.original);
					setAmount(String(students[row.original.studentId]?.paidAmount ?? 0));
				},
				children: "Update"
			})
		}
	], [students]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Payments",
				description: "Collected fees, remaining balances and discounts."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total revenue",
						value: formatLakhs(totals.revenue)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Collected",
						value: formatLakhs(totals.collected)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending",
						value: formatLakhs(totals.pending)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Discounts",
						value: formatLakhs(totals.discounts)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: payments,
				columns,
				getRowId: (p) => p.id,
				searchPlaceholder: "Search payments…",
				onRowClick: (p) => void navigate({ to: `${base}/students/${p.studentId}` }),
				emptyTitle: "No payments found",
				renderMobileCard: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: students[p.studentId]?.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [formatINR(p.remaining), " remaining"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, { status: p.status })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!edit,
				onOpenChange: (v) => !v && setEdit(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Update payment" }) }), edit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: students[edit.studentId]?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Amount paid (₹)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: amount,
								onChange: (e) => setAmount(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								updatePayment(edit.studentId, { paidAmount: Number(amount) });
								toast.success("Payment information updated");
								setEdit(null);
							},
							children: "Save"
						})
					]
				})] })
			})
		]
	});
}
//#endregion
export { PaymentsPage as t };
