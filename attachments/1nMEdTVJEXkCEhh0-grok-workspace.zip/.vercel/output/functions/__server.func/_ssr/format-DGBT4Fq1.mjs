import { n as formatDistanceToNowStrict, r as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-DGBT4Fq1.js
function formatINR(n) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(n);
}
function formatLakhs(n) {
	if (Math.abs(n) >= 1e5) {
		const l = n / 1e5;
		const digits = Math.abs(l) >= 10 ? 1 : 2;
		return `₹${l.toFixed(digits)}L`;
	}
	return formatINR(n);
}
function relativeTime(iso) {
	try {
		return formatDistanceToNowStrict(new Date(iso), { addSuffix: true });
	} catch {
		return iso;
	}
}
function formatDateTime(iso) {
	try {
		return format(new Date(iso), "d MMM yyyy · h:mm:ss a");
	} catch {
		return iso;
	}
}
function formatShortDate(iso) {
	try {
		return format(new Date(iso), "d MMM yyyy");
	} catch {
		return iso;
	}
}
function downloadText(filename, content, mime = "text/csv;charset=utf-8") {
	const blob = new Blob([content], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function toCsv(rows) {
	if (!rows.length) return "";
	const headers = Object.keys(rows[0]);
	const esc = (v) => {
		const s = v == null ? "" : String(v);
		return /["\n,]/.test(s) ? `"${s.replaceAll("\"", "\"\"")}"` : s;
	};
	return [headers.join(","), ...rows.map((row) => headers.map((h) => esc(row[h])).join(","))].join("\n");
}
//#endregion
export { formatShortDate as a, formatLakhs as i, formatDateTime as n, relativeTime as o, formatINR as r, toCsv as s, downloadText as t };
