import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { a as formatShortDate } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { i as StatusBadge } from "./status-badge-CgLI5ccz.mjs";
import { a as useUniversityMap, i as useStudentMap, n as useEmployeeMap, r as useScopedIds } from "./scoped-BYNid1DS.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-page-DXK4vr3X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ApplicationsPage() {
	const { applications } = useScopedIds();
	const students = useStudentMap();
	const unis = useUniversityMap();
	const empMap = useEmployeeMap();
	const { base } = useWorkspace();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const stats = (0, import_react.useMemo)(() => ({
		total: applications.length,
		submitted: applications.filter((a) => a.submittedAt).length,
		offers: applications.filter((a) => a.offerReceived || a.status === "Offered" || a.status === "Got Visa").length,
		waiting: applications.filter((a) => a.status === "Waiting").length,
		deferred: applications.filter((a) => a.status === "Deferred").length,
		dropped: applications.filter((a) => a.status === "Dropped").length
	}), [applications]);
	const columns = (0, import_react.useMemo)(() => [
		{
			id: "student",
			header: "Student",
			cell: ({ row }) => students[row.original.studentId]?.name ?? row.original.studentId
		},
		{
			id: "university",
			header: "University",
			cell: ({ row }) => unis[row.original.universityId]?.name ?? row.original.universityId
		},
		{
			accessorKey: "course",
			header: "Course"
		},
		{
			accessorKey: "country",
			header: "Country"
		},
		{
			accessorKey: "status",
			header: "Application status",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: row.original.status })
		},
		{
			accessorKey: "submittedAt",
			header: "Submitted",
			cell: ({ row }) => row.original.submittedAt ? formatShortDate(row.original.submittedAt) : "—"
		},
		{
			id: "offer",
			header: "Offer",
			cell: ({ row }) => row.original.offerReceived ? "Yes" : "—"
		},
		{
			accessorKey: "deadline",
			header: "Deadline",
			cell: ({ row }) => formatShortDate(row.original.deadline)
		},
		{
			id: "emp",
			header: "Employee",
			cell: ({ row }) => empMap[row.original.employeeId]?.name ?? "—"
		}
	], [
		students,
		unis,
		empMap
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Applications",
				description: "Track every university application in flight."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 grid-cols-2 lg:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total",
						value: stats.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Submitted",
						value: stats.submitted
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Offers",
						value: stats.offers
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Waiting",
						value: stats.waiting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Deferred",
						value: stats.deferred
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dropped",
						value: stats.dropped
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: applications,
				columns,
				getRowId: (a) => a.id,
				searchPlaceholder: "Search applications…",
				globalFilter: q,
				onGlobalFilterChange: setQ,
				onRowClick: (a) => void navigate({ to: `${base}/students/${a.studentId}` }),
				emptyTitle: "No applications found",
				renderMobileCard: (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: students[a.studentId]?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: unis[a.universityId]?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: a.status })
					})
				] })
			})
		]
	});
}
//#endregion
export { ApplicationsPage as t };
