import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { P as INTAKES, c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as Card } from "./card-B_I_naJs.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-BQwTj3Mx.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as Switch } from "./switch-95CbCe8f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-D8LLYrGW.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const settings = useAppStore((s) => s.settings);
	const update = useAppStore((s) => s.updateSettings);
	const theme = useAppStore((s) => s.theme);
	const setTheme = useAppStore((s) => s.setTheme);
	const resetDemo = useAppStore((s) => s.resetDemo);
	const employees = useAppStore((s) => s.employees);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Settings",
			description: "Organization preferences. Controls are simulated."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "org",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "h-auto flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "org",
							children: "Organization"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "users",
							children: "Users & roles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "permissions",
							children: "Permissions"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "notifications",
							children: "Notifications"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "security",
							children: "Security"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "appearance",
							children: "Appearance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "audit",
							children: "Audit settings"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "org",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "grid max-w-xl gap-4 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1.5 text-sm",
								children: ["Workspace name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: settings.name,
									onChange: (e) => update({ name: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1.5 text-sm",
								children: ["Legal name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: settings.legalName,
									onChange: (e) => update({ legalName: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1.5 text-sm",
								children: ["Default intake", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: settings.defaultIntake,
									onValueChange: (v) => update({ defaultIntake: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: INTAKES.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: i,
										children: i
									}, i)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => toast.success("Organization updated"),
								className: "w-fit",
								children: "Save"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "users",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "overflow-hidden p-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-table",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-left text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-5 py-2",
											children: "Name"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-5 py-2",
											children: "Role"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-5 py-2",
											children: "Status"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: employees.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b last:border-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2",
										children: e.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2 capitalize",
										children: e.role
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2",
										children: e.status
									})
								]
							}, e.id)) })]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "permissions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "p-5 text-sm text-muted-foreground",
						children: "Role permissions are simulated. Admins can view Audit Center, Employees, Reports and Settings. Employees operate students, leads, applications and payments for their own book."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "notifications",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "space-y-4 p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Email alerts",
							checked: settings.emailAlerts,
							onChange: (v) => update({ emailAlerts: v })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Slack alerts",
							checked: settings.slackAlerts,
							onChange: (v) => update({ slackAlerts: v })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "security",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "space-y-4 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Two-factor authentication",
								checked: settings.twoFactor,
								onChange: (v) => update({ twoFactor: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Login notifications",
								checked: settings.loginNotifications,
								onChange: (v) => update({ loginNotifications: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid max-w-xs gap-1.5 text-sm",
								children: ["Session timeout (minutes)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: settings.sessionTimeout,
									onChange: (e) => update({ sessionTimeout: Number(e.target.value) })
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "appearance",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm font-medium",
							children: "Theme"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: [
								"light",
								"dark",
								"system"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: theme === t ? "default" : "outline",
								className: "capitalize",
								onClick: () => setTheme(t),
								children: t
							}, t))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "audit",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "space-y-4 p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid max-w-xs gap-1.5 text-sm",
							children: ["Retention (days)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: settings.auditRetentionDays,
								onChange: (e) => update({ auditRetentionDays: Number(e.target.value) })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								resetDemo();
								toast.message("Demo data reset");
							},
							children: "Reset demo data"
						})]
					})
				})
			]
		})]
	});
}
function Row({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-center justify-between text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange: onChange
		})]
	});
}
var SplitComponent = SettingsPage;
//#endregion
export { SplitComponent as component };
