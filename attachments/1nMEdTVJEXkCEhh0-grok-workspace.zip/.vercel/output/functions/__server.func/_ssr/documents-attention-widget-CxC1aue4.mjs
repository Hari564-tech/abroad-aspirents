import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { t as isToday } from "../_libs/date-fns.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B_I_naJs.mjs";
import { r as useScopedIds } from "./scoped-BYNid1DS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-attention-widget-CxC1aue4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DocumentsAttentionWidget() {
	const { documents } = useScopedIds();
	const { base } = useWorkspace();
	const navigate = useNavigate();
	const currentUser = useAppStore((s) => s.currentUser);
	const stats = (0, import_react.useMemo)(() => {
		return {
			pendingReview: documents.filter((d) => d.status === "under_review" || d.status === "uploaded").length,
			today: documents.filter((d) => d.uploadedAt && isToday(new Date(d.uploadedAt)) && d.uploadedByRole === "student").length,
			rejected: documents.filter((d) => d.status === "rejected").length
		};
	}, [documents]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
		className: "flex-row items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Documents needing attention" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "ghost",
			onClick: () => void navigate({ to: currentUser?.role === "admin" ? "/admin/documents" : `${base}/documents` }),
			children: "View documents"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "grid gap-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.pendingReview, " documents pending review"] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.today, " student uploads received today"] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.rejected, " rejected documents require replacement"] })
		]
	})] });
}
//#endregion
export { DocumentsAttentionWidget as t };
