import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { K as CreditCard, L as GraduationCap, S as Pencil, W as Ellipsis, l as Trash2, m as ShieldAlert } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useAppStore, k as APPLICATION_STATUSES } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { i as DropdownMenuItem, o as DropdownMenuTrigger, r as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-CuItBiKD.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { a as formatShortDate, n as formatDateTime, o as relativeTime, r as formatINR } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as EmptyState } from "./empty-state-CivQ_9Zu.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B_I_naJs.mjs";
import { i as StatusBadge, t as PaymentBadge } from "./status-badge-CgLI5ccz.mjs";
import { a as useUniversityMap, n as useEmployeeMap } from "./scoped-BYNid1DS.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-CnGpc8qo.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-BQwTj3Mx.mjs";
import { r as Progress } from "./document-preview-CyV17_st.mjs";
import { n as PasswordField, t as DocumentWorkspace } from "./document-workspace-hBhufopM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student-detail-DeWrQk24.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Timeline({ events }) {
	if (!events.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-8 text-center text-sm text-muted-foreground",
		children: "No activity yet."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "relative space-y-0",
		children: events.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex gap-3 pb-5 last:pb-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 size-2.5 rounded-full bg-primary ring-4 ring-primary/15" }), i < events.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-px flex-1 bg-border" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("min-w-0 pb-1"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: e.title
					}),
					e.detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm text-muted-foreground",
						children: e.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-micro text-muted-foreground",
						children: [formatDateTime(e.timestamp), e.user ? ` · ${e.user}` : ""]
					})
				]
			})]
		}, e.id))
	});
}
function StudentDetailPage({ studentId }) {
	const student = useAppStore((s) => s.students).find((s) => s.id === studentId);
	const applications = useAppStore((s) => s.applications).filter((a) => a.studentId === studentId);
	const documents = useAppStore((s) => s.documents).filter((d) => d.studentId === studentId);
	const payments = useAppStore((s) => s.payments).filter((p) => p.studentId === studentId);
	const audit = useAppStore((s) => s.auditEvents).filter((e) => e.recordId === studentId);
	const changeStatus = useAppStore((s) => s.changeStudentStatus);
	const deleteStudent = useAppStore((s) => s.deleteStudent);
	const empMap = useEmployeeMap();
	const uniMap = useUniversityMap();
	const { base, role } = useWorkspace();
	const navigate = useNavigate();
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const timeline = (0, import_react.useMemo)(() => {
		if (!student) return [];
		return [
			{
				id: "reg",
				timestamp: student.createdAt,
				title: "Student registered",
				detail: `${student.name} was added to ${student.intake}.`,
				user: empMap[student.employeeId]?.name
			},
			...applications.filter((a) => a.submittedAt).map((a) => ({
				id: a.id,
				timestamp: a.submittedAt,
				title: a.offerReceived ? "Offer received" : "Application submitted",
				detail: `${uniMap[a.universityId]?.name ?? "University"} · ${a.course}`,
				user: empMap[a.employeeId]?.name
			})),
			...audit.slice(0, 12).map((e) => ({
				id: e.id,
				timestamp: e.timestamp,
				title: e.details,
				detail: e.before && e.after ? `${e.before} → ${e.after}` : void 0,
				user: e.user
			}))
		].sort((a, b) => a.timestamp < b.timestamp ? 1 : -1);
	}, [
		student,
		applications,
		audit,
		empMap,
		uniMap
	]);
	if (!student) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Student not found",
		description: "This record may have been deleted.",
		actionLabel: "Back to students",
		onAction: () => void navigate({ to: `${base}/students` })
	});
	const remaining = Math.max(0, student.totalFee - student.discount - student.paidAmount);
	const pct = student.totalFee ? Math.round(student.paidAmount / (student.totalFee - student.discount || 1) * 100) : 0;
	const counselor = empMap[student.employeeId];
	const offers = applications.filter((a) => a.offerReceived).length;
	const initialTab = typeof window !== "undefined" && (new URLSearchParams(window.location.search).get("tab") === "documents" || sessionStorage.getItem(`meridian-upload-${student.id}`) || sessionStorage.getItem(`meridian-portal-${student.id}`)) ? "documents" : "overview";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: student.name,
				description: `${student.id} · ${student.country} · ${student.intake}`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: student.status,
						onValueChange: (v) => {
							changeStatus(student.id, v);
							toast.success("Status changed");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-[220px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: APPLICATION_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: s,
							children: s
						}, s)) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void navigate({ to: `${base}/universities?student=${student.id}` }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-4" }), " Check eligibility"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void navigate({ to: `${base}/students/${student.id}/edit` }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }), " Edit student"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
						align: "end",
						children: role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							destructive: true,
							onClick: () => setConfirm(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Delete"]
						})
					})] })
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
					name: student.name,
					hue: student.avatarHue,
					className: "size-12"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: student.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, { status: student.paymentStatus })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							student.branch,
							" · ",
							student.college
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Current status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold",
							children: student.status
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Lead employee"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold",
							children: counselor?.name ?? "Unassigned"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm font-semibold",
								children: [
									formatINR(student.paidAmount),
									" / ",
									formatINR(student.totalFee)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								value: Math.min(100, pct),
								className: "mt-2"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Applications"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm font-semibold",
							children: [
								applications.length,
								" · ",
								offers,
								" offers"
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: initialTab,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "h-auto w-full flex-wrap justify-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "overview",
								children: "Overview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "academic",
								children: "Academic"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "applications",
								children: "Applications"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "payments",
								children: "Payments"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "documents",
								children: ["Documents", documents.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-1.5 text-micro text-muted-foreground",
									children: [
										documents.filter((d) => d.required && (d.status === "uploaded" || d.status === "under_review" || d.status === "verified")).length,
										"/",
										documents.filter((d) => d.required).length
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "universities",
								children: "Universities"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "activity",
								children: "Activity"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "overview",
						className: "grid gap-4 lg:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Personal" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "grid grid-cols-2 gap-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Phone 1",
										value: student.phone1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Phone 2",
										value: student.phone2 || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Email",
										value: student.email
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Lead type",
										value: student.leadType
									}),
									student.b2bOrg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "B2B organization",
										value: student.b2bOrg
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Device",
										value: student.device
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
								className: "flex-row items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Account credentials" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-micro text-warning",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-3" }), " Sensitive data"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "grid gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Only authorized users should access this information. This prototype does not securely store credentials."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Gmail ID",
										value: student.gmailId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
										label: "Gmail password",
										value: student.gmailPassword
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Recovery number",
										value: student.recoveryNumber
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "2-step verification",
										value: student.twoStep ? "Enabled" : "Off"
									})
								]
							})] }),
							student.country === "Germany" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "lg:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Germany-specific" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
									className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
											label: "APS username",
											value: student.apsUsername ?? "",
											warning: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
											label: "APS password",
											value: student.apsPassword ?? ""
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Uni-Assist ID",
											value: student.uniAssistId ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
											label: "Uni-Assist password",
											value: student.uniAssistPassword ?? ""
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Uni-Assist documents",
											value: student.uniAssistDocuments ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Blocked account",
											value: student.blockedAccount ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Enrollment",
											value: student.enrollment ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Student dorm",
											value: student.studentDorm ?? "—"
										})
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "academic",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "CGPA",
									value: student.cgpa.toFixed(2)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "IELTS",
									value: student.ielts?.toFixed(1) ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "TOEFL",
									value: student.toefl?.toString() ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Duolingo",
									value: student.duolingo?.toString() ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "German grade",
									value: student.germanGrade?.toFixed(1) ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "GRE",
									value: student.gre?.toString() ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "German language",
									value: student.germanLanguage
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Branch",
									value: student.branch
								})
							]
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "applications",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "overflow-x-auto p-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-table",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-left text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
										className: "border-b",
										children: [
											"University",
											"Course",
											"Status",
											"Submitted",
											"Offer",
											"Deadline"
										].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-5 py-2 font-medium",
											children: h
										}, h))
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: applications.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b last:border-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: uniMap[a.universityId]?.name ?? a.universityId
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: a.course
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: a.status })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5 text-muted-foreground",
											children: a.submittedAt ? formatShortDate(a.submittedAt) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5",
											children: a.offerReceived ? "Yes" : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-5 py-2.5 text-muted-foreground",
											children: formatShortDate(a.deadline)
										})
									]
								}, a.id)) })]
							}), applications.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { title: "No applications yet" })]
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "payments",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4" }), " Payment summary"]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Total fee",
										value: formatINR(student.totalFee)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Collected",
										value: formatINR(student.paidAmount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Discount",
										value: formatINR(student.discount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Remaining",
										value: formatINR(remaining)
									})
								]
							}), payments.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between rounded-lg border px-3 py-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.method ?? "Record" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: p.lastPayment ? relativeTime(p.lastPayment) : "No payment yet"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, { status: p.status })
								]
							}, p.id))]
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "documents",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentWorkspace, { student })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "universities",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: applications.map((a) => {
								const u = uniMap[a.universityId];
								if (!u) return null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: u.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-muted-foreground",
											children: [
												u.course,
												" · ",
												u.location
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: a.status })
										})
									]
								}, a.id);
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "activity",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timeline, { events: timeline })
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirm,
				onOpenChange: setConfirm,
				title: "Delete student?",
				description: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"This action cannot be undone.",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-2 block font-medium text-foreground",
						children: [
							student.name,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: student.id
							})
						]
					})
				] }),
				confirmLabel: "Delete student",
				onConfirm: () => {
					deleteStudent(student.id);
					toast.success("Student deleted");
					navigate({ to: `${base}/students` });
				}
			})
		]
	});
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-0.5 text-sm font-medium",
		children: value
	})] });
}
//#endregion
export { StudentDetailPage as t };
