import { t as StudentsPage } from "./students-page-82bnfbIm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students-gLmKA9Z2.js
var SplitComponent = StudentsPage;
//#endregion
export { SplitComponent as component };
