import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Badge } from "./badge-Caj8QGQQ.mjs";
import { n as documentTone, t as TONE_BADGE } from "./status-BbxO-Ia2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/document-status-badge-Xjx6MsLi.js
var import_jsx_runtime = require_jsx_runtime();
var LABELS = {
	verified: "✓ Verified",
	uploaded: "✓ Uploaded",
	under_review: "◷ Under Review",
	pending: "! Pending",
	rejected: "× Rejected",
	expired: "Expired"
};
function DocumentStatusBadge({ status, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "outline",
		className: cn("border-0 font-medium ring-1", TONE_BADGE[documentTone(status)] ?? TONE_BADGE.muted, className),
		"aria-label": LABELS[status],
		children: LABELS[status]
	});
}
//#endregion
export { DocumentStatusBadge as t };
