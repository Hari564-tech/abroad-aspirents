import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as Upload, nt as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as isSubmitted, S as isOverdue, c as useAppStore, s as Route$10, v as documentStats, w as portalEffectiveStatus } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { a as formatShortDate } from "./format-DGBT4Fq1.mjs";
import { t as Card } from "./card-B_I_naJs.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-CnGpc8qo.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as DocumentStatusBadge } from "./document-status-badge-Xjx6MsLi.mjs";
import { n as DocumentUpload, r as Progress, t as DocumentPreview } from "./document-preview-CyV17_st.mjs";
import { t as Logo } from "./logo-Db11eYx6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student-upload._token-BisRLmu6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentUploadPortal({ token }) {
	const hydrated = useAppStore((s) => s.hydrated);
	const portals = useAppStore((s) => s.portals);
	const students = useAppStore((s) => s.students);
	const documents = useAppStore((s) => s.documents);
	const touch = useAppStore((s) => s.touchPortalAccess);
	const log = useAppStore((s) => s.logPortalAccess);
	const portal = portals.find((p) => p.token === token);
	const student = students.find((s) => s.id === portal?.studentId);
	const docs = documents.filter((d) => d.studentId === portal?.studentId);
	const status = portal ? portalEffectiveStatus(portal) : "invalid";
	const [gate, setGate] = (0, import_react.useState)("ready");
	const [email, setEmail] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [uploadDoc, setUploadDoc] = (0, import_react.useState)(null);
	const [viewDoc, setViewDoc] = (0, import_react.useState)(null);
	const [replaceConfirm, setReplaceConfirm] = (0, import_react.useState)(null);
	const [replaceDoc, setReplaceDoc] = (0, import_react.useState)(null);
	const [success, setSuccess] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !portal) return;
		if (portalEffectiveStatus(portal) !== "active") return;
		if (portal.accessMethod === "link_only") {
			setGate("ready");
			touch(token);
			return;
		}
		const key = `meridian-portal-auth-${token}`;
		if (sessionStorage.getItem(key) === "1") {
			setGate("ready");
			return;
		}
		setGate("email");
	}, [
		hydrated,
		portal,
		token,
		touch
	]);
	const stats = (0, import_react.useMemo)(() => documentStats(docs), [docs]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col gap-4 px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-40 rounded-md bg-secondary skeleton-shimmer" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 rounded-xl bg-secondary skeleton-shimmer" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 rounded-xl bg-secondary skeleton-shimmer" })
		]
	});
	if (!portal || !student) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-xl font-semibold",
		children: "Invalid portal link."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted-foreground",
		children: "Please request a new link from your counselor."
	})] });
	if (status === "expired") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-xl font-semibold",
		children: "This document portal has expired."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted-foreground",
		children: "Please contact your counselor for a new link."
	})] });
	if (status === "revoked") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-xl font-semibold",
		children: "Access revoked."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm text-muted-foreground",
		children: "This document portal is no longer active."
	})] });
	if (gate === "email") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-xl font-semibold",
			children: "Enter your email"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Access is configured by your counselor. Use the email they registered for you."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6 grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				if (email.trim().toLowerCase() !== (portal.email ?? student.email).toLowerCase()) {
					toast.error("That email does not match this portal.");
					return;
				}
				setGate("code");
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "email",
				required: true,
				value: email,
				onChange: (e) => setEmail(e.target.value),
				placeholder: student.email
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "Continue"
			})]
		})
	] });
	if (gate === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-xl font-semibold",
			children: "Verification code"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Enter the 6-digit code sent to your email. In this prototype, any 6-digit code works."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6 grid gap-3",
			onSubmit: (e) => {
				e.preventDefault();
				if (!/^\d{6}$/.test(code)) {
					toast.error("Enter a 6-digit code.");
					return;
				}
				sessionStorage.setItem(`meridian-portal-auth-${token}`, "1");
				touch(token);
				setGate("ready");
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				inputMode: "numeric",
				pattern: "\\d{6}",
				maxLength: 6,
				value: code,
				onChange: (e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6)),
				placeholder: "••••••",
				className: "text-center font-mono text-lg tracking-[0.4em]",
				"aria-label": "Verification code"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "Verify"
			})]
		})
	] });
	const required = docs.filter((d) => d.required);
	const allIn = stats.remaining === 0 && stats.requiredTotal > 0;
	const perms = portal.permissions;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-lg items-center justify-between px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-micro font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Meridian"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "Student Document Portal"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { compact: true })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg px-4 pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: student.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-micro text-muted-foreground",
							children: student.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								student.country,
								" · ",
								student.intake
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-lg space-y-5 px-4 py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg font-semibold",
							children: "Complete your document submission"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm tabular-nums text-muted-foreground",
							children: [
								stats.complete,
								" / ",
								stats.requiredTotal,
								" documents submitted"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: stats.percent,
							className: "mt-3 h-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: [stats.remaining, " documents remaining"]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "grid grid-cols-2 gap-3 p-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Document completion"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-lg font-semibold tabular-nums",
								children: [
									stats.complete,
									" / ",
									stats.requiredTotal
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-micro text-muted-foreground",
								children: [stats.percent, "%"]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1 text-micro",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.verified, " Verified"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.underReview, " Under Review"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.pending, " Pending"] })
							]
						})]
					}),
					allIn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-success/30 bg-success/5 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 font-semibold text-success",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Documents submitted"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "You have completed all currently requested documents. Your documents are now available to the counselor for review."
						})]
					}),
					docs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-6 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "No documents requested yet."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Your counselor has not requested any documents."
						})]
					}),
					required.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 text-sm font-semibold",
						children: "Required documents"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: required.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentDocRow, {
							doc,
							perms,
							onUpload: () => setUploadDoc(doc),
							onView: () => setViewDoc(doc),
							onReplace: () => setReplaceConfirm(doc)
						}, doc.id))
					})] }),
					docs.some((d) => !d.required) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 text-sm font-semibold",
						children: "Optional documents"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: docs.filter((d) => !d.required).map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentDocRow, {
							doc,
							perms,
							onUpload: () => setUploadDoc(doc),
							onView: () => setViewDoc(doc),
							onReplace: () => setReplaceConfirm(doc)
						}, doc.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-8 text-center text-micro text-muted-foreground",
						children: "Need help? Contact your counselor. Access is configured by your counselor."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentUpload, {
				open: !!uploadDoc,
				onOpenChange: (v) => !v && setUploadDoc(null),
				student,
				presetType: uploadDoc?.type,
				replaceOf: uploadDoc ?? void 0,
				asStudent: true,
				onUploaded: (doc) => {
					setSuccess(doc);
					log(portal.id, `uploaded ${doc.fileName ?? doc.type}`, student.name);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentUpload, {
				open: !!replaceDoc,
				onOpenChange: (v) => !v && setReplaceDoc(null),
				student,
				replaceOf: replaceDoc ?? void 0,
				asStudent: true,
				onUploaded: (doc) => {
					setSuccess(doc);
					log(portal.id, `replaced ${doc.fileName ?? doc.type}`, student.name);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!replaceConfirm,
				onOpenChange: (v) => !v && setReplaceConfirm(null),
				title: "Replace document?",
				description: "The new file will become the latest version.",
				confirmLabel: "Upload replacement",
				destructive: false,
				onConfirm: () => {
					setReplaceDoc(replaceConfirm);
					setReplaceConfirm(null);
				}
			}),
			viewDoc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 overflow-y-auto bg-background p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: viewDoc.fileName || viewDoc.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setViewDoc(null),
							children: "Close"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentPreview, { doc: viewDoc })]
				})
			}),
			success && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end bg-foreground/20 p-4 sm:items-center sm:justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "w-full max-w-md p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 font-semibold text-success",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Document uploaded successfully"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: success.fileName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-micro text-muted-foreground",
							children: "Submitted just now"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm",
							children: ["Status: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: "under_review" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							onClick: () => setSuccess(null),
							children: "Done"
						})
					]
				})
			})
		]
	});
}
function StudentDocRow({ doc, perms, onUpload, onView, onReplace }) {
	const overdue = isOverdue(doc.dueDate, doc.status);
	const submitted = isSubmitted(doc.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: doc.universityName ? `${doc.type} — ${doc.universityName}` : doc.type
				}),
				doc.universityName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-micro text-muted-foreground",
					children: doc.course
				}),
				doc.studentInstruction && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-micro text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: "Instructions. "
					}), doc.studentInstruction]
				}),
				doc.replacementRequested && doc.replacementMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-micro text-warning",
					children: doc.replacementMessage
				}),
				doc.dueDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-1 text-micro", overdue ? "font-medium text-destructive" : "text-muted-foreground"),
					children: overdue ? "Overdue" : `Due by: ${formatShortDate(doc.dueDate)}`
				})
			] }), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-micro font-medium text-success",
				children: "✓ Submitted"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: doc.status })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [
				!submitted && perms.upload && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: onUpload,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Upload"]
				}),
				submitted && perms.view && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: onView,
					children: "View"
				}),
				submitted && perms.replace && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: onReplace,
					children: "Replace"
				}),
				(doc.status === "rejected" || doc.replacementRequested) && perms.upload && submitted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: onUpload,
					children: "Upload replacement"
				})
			]
		})]
	});
}
function GateShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-micro font-medium uppercase tracking-[0.16em] text-muted-foreground",
				children: "Student Document Portal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})
		]
	});
}
function StudentUploadRoute() {
	const { token } = Route$10.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentUploadPortal, { token });
}
//#endregion
export { StudentUploadRoute as component };
