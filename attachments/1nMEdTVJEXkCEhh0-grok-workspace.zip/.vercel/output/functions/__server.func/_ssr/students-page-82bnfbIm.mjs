import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Download, U as ExternalLink, W as Ellipsis, a as Upload, q as Copy, x as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { P as INTAKES, T as portalUrl, c as useAppStore, k as APPLICATION_STATUSES, w as portalEffectiveStatus } from "./router-z_xU0oK5.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { i as DropdownMenuItem, o as DropdownMenuTrigger, r as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-CuItBiKD.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { o as relativeTime, s as toCsv, t as downloadText } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { i as StatusBadge, t as PaymentBadge } from "./status-badge-CgLI5ccz.mjs";
import { n as useEmployeeMap, r as useScopedIds } from "./scoped-BYNid1DS.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-CnGpc8qo.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
import { t as FilterSelect } from "./filter-select-DRpDDDny.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students-page-82bnfbIm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentsPage() {
	const { students } = useScopedIds();
	const employees = useAppStore((s) => s.employees);
	const deleteStudent = useAppStore((s) => s.deleteStudent);
	const appendAudit = useAppStore((s) => s.appendAudit);
	const portals = useAppStore((s) => s.portals);
	const empMap = useEmployeeMap();
	const { base, role } = useWorkspace();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const [country, setCountry] = (0, import_react.useState)("all");
	const [intake, setIntake] = (0, import_react.useState)("all");
	const [employee, setEmployee] = (0, import_react.useState)("all");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => {
		return students.filter((s) => {
			if (country !== "all" && s.country !== country) return false;
			if (intake !== "all" && s.intake !== intake) return false;
			if (employee !== "all" && s.employeeId !== employee) return false;
			if (status !== "all" && s.status !== status) return false;
			if (q && !`${s.name} ${s.id} ${s.email}`.toLowerCase().includes(q.toLowerCase())) return false;
			return true;
		});
	}, [
		students,
		country,
		intake,
		employee,
		status,
		q
	]);
	const columns = (0, import_react.useMemo)(() => [
		{
			accessorKey: "id",
			header: "Student ID",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: row.original.id
			})
		},
		{
			accessorKey: "name",
			header: "Student",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
					name: row.original.name,
					hue: row.original.avatarHue,
					className: "size-7"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: row.original.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-micro text-muted-foreground",
					children: row.original.email
				})] })]
			})
		},
		{
			accessorKey: "country",
			header: "Country"
		},
		{
			accessorKey: "intake",
			header: "Intake"
		},
		{
			id: "employee",
			header: "Employee",
			cell: ({ row }) => empMap[row.original.employeeId]?.name ?? "—"
		},
		{
			accessorKey: "status",
			header: "Application status",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: row.original.status })
		},
		{
			accessorKey: "paymentStatus",
			header: "Payment",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, { status: row.original.paymentStatus })
		},
		{
			accessorKey: "updatedAt",
			header: "Updated",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: relativeTime(row.original.updatedAt)
			})
		},
		{
			id: "actions",
			header: "",
			enableSorting: false,
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					className: "size-8",
					onClick: (e) => e.stopPropagation(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onClick: () => void navigate({ to: `${base}/students/${row.original.id}` }),
						children: "View student"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => {
							sessionStorage.setItem(`meridian-upload-${row.original.id}`, "1");
							navigate({ to: `${base}/students/${row.original.id}` });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Upload document"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => {
							sessionStorage.setItem(`meridian-portal-${row.original.id}`, "1");
							navigate({ to: `${base}/students/${row.original.id}` });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" }), " Open document portal"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => {
							const portal = portals.find((p) => p.studentId === row.original.id && portalEffectiveStatus(p) === "active");
							if (!portal) {
								toast.message("No active portal yet. Generate one from the student profile.");
								sessionStorage.setItem(`meridian-portal-${row.original.id}`, "1");
								navigate({ to: `${base}/students/${row.original.id}` });
								return;
							}
							navigator.clipboard.writeText(portalUrl(portal.token)).then(() => {
								appendAudit({
									action: "PORTAL_LINK_COPIED",
									module: "Documents",
									recordId: row.original.id,
									details: "Copied student portal link",
									severity: "INFO"
								});
								toast.success("Link copied");
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), " Copy portal link"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onClick: () => void navigate({ to: `${base}/students/${row.original.id}/edit` }),
						children: "Edit"
					}),
					role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						destructive: true,
						onClick: () => setPendingDelete(row.original),
						children: "Delete"
					})
				]
			})] })
		}
	], [
		empMap,
		base,
		navigate,
		role,
		portals,
		appendAudit
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Students",
				description: "Manage registered students and applications.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => {
						downloadText("students.csv", toCsv(filtered.map((s) => ({
							id: s.id,
							name: s.name,
							country: s.country,
							intake: s.intake,
							status: s.status,
							payment: s.paymentStatus,
							employee: empMap[s.employeeId]?.name
						}))));
						appendAudit({
							action: "EXPORT",
							module: "Students",
							recordId: "LIST",
							details: `Exported ${filtered.length} students`,
							severity: "INFO"
						});
						toast.success("Students exported");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Export"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void navigate({ to: `${base}/students/new` }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add student"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: filtered,
				columns,
				getRowId: (s) => s.id,
				searchPlaceholder: "Search students…",
				globalFilter: q,
				onGlobalFilterChange: setQ,
				selectable: true,
				onRowClick: (s) => void navigate({ to: `${base}/students/${s.id}` }),
				emptyTitle: "No students found",
				emptyDescription: "Try changing your filters or search query.",
				onClearFilters: () => {
					setQ("");
					setCountry("all");
					setIntake("all");
					setEmployee("all");
					setStatus("all");
				},
				extraFilters: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: country,
						onChange: setCountry,
						placeholder: "Country",
						options: [
							"Germany",
							"UK",
							"USA"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: intake,
						onChange: setIntake,
						placeholder: "Intake",
						options: INTAKES
					}),
					role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: employee,
						onChange: setEmployee,
						placeholder: "Employee",
						options: employees.filter((e) => e.role === "employee").map((e) => ({
							value: e.id,
							label: e.name
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: status,
						onChange: setStatus,
						placeholder: "Status",
						options: APPLICATION_STATUSES
					})
				] }),
				renderMobileCard: (s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
							name: s.name,
							hue: s.avatarHue
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: s.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-micro text-muted-foreground",
								children: s.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									s.country,
									" · ",
									s.intake
								]
							})
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s.status })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!pendingDelete,
				onOpenChange: (v) => !v && setPendingDelete(null),
				title: "Delete student?",
				description: pendingDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"This action cannot be undone.",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-2 block font-medium text-foreground",
						children: [
							pendingDelete.name,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: pendingDelete.id
							})
						]
					})
				] }) : null,
				confirmLabel: "Delete student",
				onConfirm: () => {
					if (pendingDelete) {
						deleteStudent(pendingDelete.id);
						toast.success("Student deleted");
						setPendingDelete(null);
					}
				}
			})
		]
	});
}
//#endregion
export { StudentsPage as t };
