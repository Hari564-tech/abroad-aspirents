import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scoped-BYNid1DS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function greetingName(name) {
	const h = (/* @__PURE__ */ new Date()).getHours();
	return `${h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"}, ${name.split(" ")[0]}`;
}
function useEmployeeMap() {
	const employees = useAppStore((s) => s.employees);
	return (0, import_react.useMemo)(() => Object.fromEntries(employees.map((e) => [e.id, e])), [employees]);
}
function useUniversityMap() {
	const universities = useAppStore((s) => s.universities);
	return (0, import_react.useMemo)(() => Object.fromEntries(universities.map((u) => [u.id, u])), [universities]);
}
function useStudentMap() {
	const students = useAppStore((s) => s.students);
	return (0, import_react.useMemo)(() => Object.fromEntries(students.map((s) => [s.id, s])), [students]);
}
function useScopedIds() {
	const { role } = useWorkspace();
	const user = useAppStore((s) => s.currentUser);
	const students = useAppStore((s) => s.students);
	const applications = useAppStore((s) => s.applications);
	const payments = useAppStore((s) => s.payments);
	const leads = useAppStore((s) => s.leads);
	const documents = useAppStore((s) => s.documents);
	const workItems = useAppStore((s) => s.workItems);
	const auditEvents = useAppStore((s) => s.auditEvents);
	const notifications = useAppStore((s) => s.notifications);
	return (0, import_react.useMemo)(() => {
		if (role !== "employee" || !user) return {
			students,
			applications,
			payments,
			leads,
			documents,
			workItems,
			auditEvents,
			notifications
		};
		const mine = students.filter((s) => s.employeeId === user.id);
		const ids = new Set(mine.map((s) => s.id));
		return {
			students: mine,
			applications: applications.filter((a) => a.employeeId === user.id || ids.has(a.studentId)),
			payments: payments.filter((p) => ids.has(p.studentId)),
			leads: leads.filter((l) => l.employeeId === user.id),
			documents: documents.filter((d) => ids.has(d.studentId)),
			workItems: workItems.filter((w) => w.employeeId === user.id),
			auditEvents: auditEvents.filter((e) => e.userId === user.id || ids.has(e.recordId)),
			notifications: notifications.map((n) => ({
				...n,
				href: n.href.replace("/admin/", "/employee/")
			}))
		};
	}, [
		role,
		user,
		students,
		applications,
		payments,
		leads,
		documents,
		workItems,
		auditEvents,
		notifications
	]);
}
//#endregion
export { useUniversityMap as a, useStudentMap as i, useEmployeeMap as n, useScopedIds as r, greetingName as t };
