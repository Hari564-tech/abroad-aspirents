import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as TrendingDown, s as TrendingUp } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Card } from "./card-B_I_naJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stat-card-0qMA4LOU.js
var import_jsx_runtime = require_jsx_runtime();
function StatCard({ label, value, hint, delta, icon: Icon }) {
	const up = delta != null && delta >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-xl font-semibold tabular-nums tracking-tight",
						children: value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1.5 flex items-center gap-2",
						children: [delta != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("inline-flex items-center gap-0.5 text-micro font-medium tabular-nums", up ? "text-success" : "text-destructive"),
							children: [
								up ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-3" }),
								up ? "+" : "",
								delta.toFixed(1),
								"%"
							]
						}), hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-micro text-muted-foreground",
							children: hint
						})]
					})
				]
			}), Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			})]
		})
	});
}
//#endregion
export { StatCard as t };
