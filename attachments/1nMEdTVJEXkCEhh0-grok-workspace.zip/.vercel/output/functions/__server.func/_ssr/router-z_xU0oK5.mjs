import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { C as useRouter, _ as Outlet, b as createRootRoute, d as Scripts, f as HeadContent, g as createRouter, q as redirect, v as lazyRouteComponent, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-z_xU0oK5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var APPLICATION_STATUSES = [
	"Shortlisting Sent",
	"Applications Started",
	"Applications on Hold",
	"Offered",
	"Waiting",
	"Deferred",
	"Dropped",
	"Private Registered",
	"Private Shifted",
	"Still Thinking",
	"Got Visa"
];
var INTAKES = [
	"Winter 2026",
	"Summer 2026",
	"January 2026",
	"Spring 2026",
	"Winter 2025"
];
var BRANCHES = [
	"Computer Science",
	"Mechanical Engineering",
	"Electrical Engineering",
	"Civil Engineering",
	"Business Administration",
	"Data Science",
	"Electronics & Communication",
	"Biotechnology",
	"Architecture",
	"Finance"
];
var GERMAN_LEVELS = [
	"None",
	"A1",
	"A2",
	"B1",
	"B2",
	"C1"
];
var DOCUMENT_CATEGORIES = [
	"Identity",
	"Academic",
	"Language",
	"Financial",
	"Application",
	"University",
	"Visa",
	"Other"
];
var AUDIT_ACTIONS = [
	"CREATE",
	"UPDATE",
	"DELETE",
	"LOGIN",
	"LOGOUT",
	"STATUS_CHANGE",
	"PAYMENT_UPDATE",
	"EMPLOYEE_ASSIGN",
	"UNIVERSITY_UPDATE",
	"EXPORT",
	"VIEW",
	"SHORTLIST",
	"DOCUMENT_UPLOADED",
	"DOCUMENT_VIEWED",
	"DOCUMENT_DOWNLOADED",
	"DOCUMENT_REPLACED",
	"DOCUMENT_VERIFIED",
	"DOCUMENT_REJECTED",
	"DOCUMENT_DELETED",
	"DOCUMENT_REQUESTED",
	"PORTAL_CREATED",
	"PORTAL_ACCESSED",
	"PORTAL_SHARED",
	"PORTAL_LINK_COPIED",
	"PORTAL_REVOKED",
	"PORTAL_REGENERATED",
	"STUDENT_UPLOADED_DOCUMENT",
	"STUDENT_REPLACED_DOCUMENT"
];
var DOCUMENT_TYPE_CATALOG = [
	{
		type: "Passport",
		category: "Identity",
		requiredByDefault: true
	},
	{
		type: "Photo",
		category: "Identity",
		requiredByDefault: false
	},
	{
		type: "National ID",
		category: "Identity",
		requiredByDefault: false
	},
	{
		type: "Degree Certificate",
		category: "Academic",
		requiredByDefault: true
	},
	{
		type: "Transcript",
		category: "Academic",
		requiredByDefault: true
	},
	{
		type: "Provisional Certificate",
		category: "Academic",
		requiredByDefault: false
	},
	{
		type: "Language Certificate",
		category: "Language",
		requiredByDefault: true
	},
	{
		type: "IELTS Certificate",
		category: "Language",
		requiredByDefault: false
	},
	{
		type: "TOEFL Certificate",
		category: "Language",
		requiredByDefault: false
	},
	{
		type: "German Language Certificate",
		category: "Language",
		requiredByDefault: false,
		countries: ["Germany"]
	},
	{
		type: "Financial Proof",
		category: "Financial",
		requiredByDefault: true
	},
	{
		type: "Blocked Account Proof",
		category: "Financial",
		requiredByDefault: false,
		countries: ["Germany"]
	},
	{
		type: "SOP",
		category: "Application",
		requiredByDefault: true
	},
	{
		type: "LOR",
		category: "Application",
		requiredByDefault: true
	},
	{
		type: "CV",
		category: "Application",
		requiredByDefault: true
	},
	{
		type: "APS Documents",
		category: "Application",
		requiredByDefault: false,
		countries: ["Germany"]
	},
	{
		type: "Uni-Assist Documents",
		category: "Application",
		requiredByDefault: false,
		countries: ["Germany"]
	},
	{
		type: "University Offer Letter",
		category: "University",
		requiredByDefault: false
	},
	{
		type: "Visa Application Form",
		category: "Visa",
		requiredByDefault: false
	},
	{
		type: "Other",
		category: "Other",
		requiredByDefault: false
	}
];
/** Country-configured requirement lists — business rules, not universal facts. */
var COUNTRY_DOCUMENT_RULES = {
	Germany: [
		{
			type: "Passport",
			required: true,
			instruction: "Upload a clear colour scan of the photo page."
		},
		{
			type: "Degree Certificate",
			required: true,
			instruction: "Latest official degree or provisional certificate."
		},
		{
			type: "Transcript",
			required: true,
			instruction: "Please upload the latest official transcript."
		},
		{
			type: "Language Certificate",
			required: true
		},
		{
			type: "APS Documents",
			required: true,
			instruction: "APS certificate or acknowledgment, if issued."
		},
		{
			type: "Uni-Assist Documents",
			required: true
		},
		{
			type: "German Language Certificate",
			required: false,
			priority: "optional"
		},
		{
			type: "CV",
			required: true
		},
		{
			type: "SOP",
			required: true
		},
		{
			type: "LOR",
			required: true
		},
		{
			type: "Financial Proof",
			required: true,
			instruction: "Blocked account, sponsor letter, or equivalent proof."
		},
		{
			type: "Photo",
			required: false,
			priority: "optional"
		}
	],
	UK: [
		{
			type: "Passport",
			required: true
		},
		{
			type: "Degree Certificate",
			required: true
		},
		{
			type: "Transcript",
			required: true
		},
		{
			type: "IELTS Certificate",
			required: true
		},
		{
			type: "SOP",
			required: true
		},
		{
			type: "LOR",
			required: true
		},
		{
			type: "CV",
			required: true
		},
		{
			type: "Financial Proof",
			required: true
		},
		{
			type: "Photo",
			required: false,
			priority: "optional"
		}
	],
	USA: [
		{
			type: "Passport",
			required: true
		},
		{
			type: "Degree Certificate",
			required: true
		},
		{
			type: "Transcript",
			required: true
		},
		{
			type: "Language Certificate",
			required: true
		},
		{
			type: "SOP",
			required: true
		},
		{
			type: "LOR",
			required: true
		},
		{
			type: "CV",
			required: true
		},
		{
			type: "Financial Proof",
			required: true
		},
		{
			type: "Photo",
			required: false,
			priority: "optional"
		}
	]
};
var REJECT_REASONS = [
	"Incorrect document",
	"Document unclear",
	"Expired document",
	"Wrong document",
	"Missing information",
	"Other"
];
var FILE_RULES = {
	allowedExtensions: [
		".pdf",
		".jpg",
		".jpeg",
		".png",
		".webp",
		".doc",
		".docx"
	],
	allowedMime: [
		"application/pdf",
		"image/jpeg",
		"image/png",
		"image/webp",
		"application/msword",
		"application/vnd.openxmlformats-officedocument.wordprocessingml.document"
	],
	maxBytes: 26214400,
	maxNameLength: 120
};
var DEFAULT_PORTAL_PERMISSIONS = {
	view: true,
	upload: true,
	replace: true,
	delete: false,
	download: true
};
function catalogEntry(type) {
	return DOCUMENT_TYPE_CATALOG.find((d) => d.type === type);
}
function categoryForType(type) {
	return catalogEntry(type)?.category ?? "Other";
}
function isSubmitted(status) {
	return status === "uploaded" || status === "under_review" || status === "verified";
}
function documentStats(docs) {
	const required = docs.filter((d) => d.required);
	const complete = required.filter((d) => isSubmitted(d.status)).length;
	const remaining = Math.max(0, required.length - complete);
	return {
		total: docs.length,
		requiredTotal: required.length,
		complete,
		remaining,
		percent: required.length ? Math.round(complete / required.length * 100) : 100,
		uploaded: docs.filter((d) => isSubmitted(d.status)).length,
		pending: docs.filter((d) => d.status === "pending").length,
		underReview: docs.filter((d) => d.status === "under_review").length,
		verified: docs.filter((d) => d.status === "verified").length,
		rejected: docs.filter((d) => d.status === "rejected").length,
		expired: docs.filter((d) => d.status === "expired").length,
		studentUploads: docs.filter((d) => d.uploadedByRole === "student").length
	};
}
function groupedByCategory(docs, includeEmpty = true) {
	const groups = [];
	for (const category of [
		"Identity",
		"Academic",
		"Language",
		"Financial",
		"Application",
		"University",
		"Visa",
		"Other"
	]) {
		const items = docs.filter((d) => d.category === category);
		if (items.length || includeEmpty) groups.push({
			category,
			items
		});
	}
	return groups;
}
function generatePortalToken() {
	const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
	let out = "";
	for (let i = 0; i < 13; i++) out += chars[Math.floor(Math.random() * 57)];
	return out;
}
function portalPath(token) {
	return `/student-upload/${token}`;
}
function portalUrl(token) {
	if (typeof window === "undefined") return `https://meridian.example${portalPath(token)}`;
	return `${window.location.origin}${portalPath(token)}`;
}
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
function validateUploadFile(file) {
	const name = file.name.trim();
	if (!name) return "File name is required.";
	if (name.length > FILE_RULES.maxNameLength) return "File name is too long.";
	const ext = name.includes(".") ? `.${name.split(".").pop().toLowerCase()}` : "";
	if (!FILE_RULES.allowedExtensions.includes(ext)) return `Unsupported file type. Use ${FILE_RULES.allowedExtensions.join(", ")}.`;
	if (file.size > FILE_RULES.maxBytes) return `File is larger than ${formatBytes(FILE_RULES.maxBytes)}.`;
	return null;
}
function expiryFromPreset(preset, custom) {
	if (preset === "never") return void 0;
	if (preset === "custom") return custom || void 0;
	const days = preset === "24h" ? 1 : preset === "7d" ? 7 : 30;
	return new Date(Date.now() + days * 864e5).toISOString();
}
function portalEffectiveStatus(portal) {
	if (portal.status === "revoked") return "revoked";
	if (portal.expiresAt && new Date(portal.expiresAt).getTime() < Date.now()) return "expired";
	return portal.status;
}
function defaultDocumentName(type, studentName, universityName) {
	if (universityName) return `${type} — ${universityName}`;
	return `${type} — ${studentName}`;
}
function buildRequirementDocs(student, extras, now = (/* @__PURE__ */ new Date()).toISOString()) {
	const rows = (COUNTRY_DOCUMENT_RULES[student.country] ?? COUNTRY_DOCUMENT_RULES.Germany).map((rule) => ({
		studentId: student.id,
		name: defaultDocumentName(rule.type, student.name),
		type: rule.type,
		category: categoryForType(rule.type),
		status: "pending",
		required: rule.required,
		priority: rule.priority ?? (rule.required ? "normal" : "optional"),
		version: 0,
		updatedAt: now,
		studentInstruction: rule.instruction
	}));
	for (const extra of extras ?? []) rows.push({
		studentId: student.id,
		name: defaultDocumentName(extra.type, student.name, extra.universityName),
		type: extra.type,
		category: extra.universityName ? "University" : categoryForType(extra.type),
		status: "pending",
		required: extra.required ?? true,
		priority: extra.required === false ? "optional" : "high",
		version: 0,
		updatedAt: now,
		universityId: extra.universityId,
		universityName: extra.universityName,
		course: extra.course
	});
	return rows;
}
function statusLabel(status) {
	switch (status) {
		case "verified": return "Verified";
		case "uploaded": return "Uploaded";
		case "under_review": return "Under Review";
		case "pending": return "Pending";
		case "rejected": return "Rejected";
		case "expired": return "Expired";
	}
}
function canPreview(fileType, fileName) {
	const t = (fileType || "").toLowerCase();
	const n = (fileName || "").toLowerCase();
	return t.startsWith("image/") || t === "application/pdf" || /\.(png|jpe?g|webp|gif|pdf)$/.test(n);
}
function relativeShort(iso) {
	if (!iso) return "—";
	const d = new Date(iso);
	const start = /* @__PURE__ */ new Date();
	start.setHours(0, 0, 0, 0);
	const day = new Date(d);
	day.setHours(0, 0, 0, 0);
	const diff = (start.getTime() - day.getTime()) / 864e5;
	if (diff === 0) return "Today";
	if (diff === 1) return "Yesterday";
	return d.toLocaleDateString("en-GB", {
		day: "numeric",
		month: "short"
	});
}
function isOverdue(dueDate, status) {
	if (!dueDate) return false;
	if (status && isSubmitted(status)) return false;
	return new Date(dueDate).getTime() < Date.now();
}
function rng(seed) {
	let s = seed >>> 0;
	return () => {
		s = Math.imul(s, 1664525) + 1013904223 >>> 0;
		return s / 4294967296;
	};
}
function pick(r, arr) {
	return arr[Math.floor(r() * arr.length)];
}
function pickN(r, arr, n) {
	const copy = [...arr];
	const out = [];
	for (let i = 0; i < n && copy.length; i++) {
		const idx = Math.floor(r() * copy.length);
		out.push(copy.splice(idx, 1)[0]);
	}
	return out;
}
function pad(n, w = 3) {
	return String(n).padStart(w, "0");
}
function iso(ms) {
	return new Date(ms).toISOString();
}
function phone(r) {
	const n = 6e9 + Math.floor(r() * 3999999999);
	const s = String(n);
	return `+91 ${s.slice(0, 5)} ${s.slice(5)}`;
}
function hue(r) {
	return Math.floor(r() * 360);
}
var FIRST = [
	"Rahul",
	"Priya",
	"Ananya",
	"Vikram",
	"Sneha",
	"Arjun",
	"Kavya",
	"Rohan",
	"Divya",
	"Aditya",
	"Meera",
	"Karan",
	"Pooja",
	"Siddharth",
	"Ishita",
	"Nikhil",
	"Anjali",
	"Varun",
	"Shreya",
	"Manish",
	"Neha",
	"Aakash",
	"Harini",
	"Suresh",
	"Deepika",
	"Ravi",
	"Nisha",
	"Gaurav",
	"Aishwarya",
	"Sanjay",
	"Lakshmi",
	"Abhinav",
	"Tanvi",
	"Harsh",
	"Keerthi",
	"Yash",
	"Sowmya",
	"Pranav",
	"Ritika",
	"Vivek"
];
var LAST = [
	"Kumar",
	"Sharma",
	"Reddy",
	"Singh",
	"Patel",
	"Nair",
	"Iyer",
	"Mehta",
	"Krishnan",
	"Rao",
	"Joshi",
	"Malhotra",
	"Desai",
	"Gupta",
	"Verma",
	"Kapoor",
	"Bansal",
	"Tiwari",
	"Chopra",
	"Agarwal",
	"Menon",
	"Pillai",
	"Bhat",
	"Saxena",
	"Ghosh",
	"Das",
	"Kulkarni",
	"Jain",
	"Choudhary",
	"Pandey"
];
var COLLEGES = [
	"JNTU Hyderabad",
	"Osmania University",
	"Andhra University",
	"VIT Vellore",
	"SRM Chennai",
	"Anna University",
	"NIT Warangal",
	"NIT Trichy",
	"BITS Hyderabad",
	"KL University",
	"CBIT Hyderabad",
	"Vasavi College of Engineering",
	"CVR College",
	"Gokaraju Rangaraju",
	"MVSR Engineering",
	"Chaitanya Bharathi"
];
var DEVICES = [
	"iPhone 14",
	"iPhone 15",
	"Samsung S24",
	"Pixel 8",
	"OnePlus 12",
	"iPad Air",
	"MacBook Air"
];
var AGENTS = [
	"Chrome / macOS",
	"Chrome / Windows",
	"Safari / iOS",
	"Chrome / Android",
	"Edge / Windows",
	"Firefox / macOS"
];
var IPS = [
	"192.168.14.22",
	"192.168.8.41",
	"103.210.44.18",
	"103.77.12.90",
	"49.37.8.122",
	"117.192.64.11"
];
var UNI_DE = [
	["Technical University of Munich", "Munich"],
	["RWTH Aachen University", "Aachen"],
	["University of Stuttgart", "Stuttgart"],
	["TU Berlin", "Berlin"],
	["Heidelberg University", "Heidelberg"],
	["University of Cologne", "Cologne"],
	["TU Darmstadt", "Darmstadt"],
	["University of Hamburg", "Hamburg"],
	["Karlsruhe Institute of Technology", "Karlsruhe"],
	["University of Freiburg", "Freiburg"],
	["TU Dresden", "Dresden"],
	["University of Bonn", "Bonn"]
];
var UNI_UK = [
	["University of Manchester", "Manchester"],
	["University of Birmingham", "Birmingham"],
	["University of Leeds", "Leeds"],
	["University of Glasgow", "Glasgow"],
	["University of Sheffield", "Sheffield"],
	["King's College London", "London"],
	["University of Edinburgh", "Edinburgh"],
	["University of Bristol", "Bristol"],
	["University of Nottingham", "Nottingham"],
	["Queen Mary University of London", "London"]
];
var UNI_US = [
	["Arizona State University", "Tempe"],
	["Northeastern University", "Boston"],
	["University of Texas at Dallas", "Dallas"],
	["New York University", "New York"],
	["University of Illinois Chicago", "Chicago"],
	["San Jose State University", "San Jose"],
	["University of Florida", "Gainesville"],
	["Boston University", "Boston"],
	["University of Southern California", "Los Angeles"],
	["Purdue University", "West Lafayette"]
];
var COURSES = {
	"Computer Science": [
		"M.Sc. Computer Science",
		"M.Sc. Informatics",
		"MS CS"
	],
	"Data Science": [
		"M.Sc. Data Science",
		"M.Sc. Data Engineering",
		"MS Data Analytics"
	],
	"Mechanical Engineering": [
		"M.Sc. Mechanical Engineering",
		"M.Sc. Automotive",
		"MS ME"
	],
	"Electrical Engineering": ["M.Sc. Electrical Engineering", "M.Sc. Power Engineering"],
	"Business Administration": [
		"MBA",
		"M.Sc. Management",
		"M.Sc. Business Analytics"
	],
	Finance: ["M.Sc. Finance", "M.Sc. Accounting & Finance"],
	"Electronics & Communication": ["M.Sc. Embedded Systems", "M.Sc. Communications Engineering"],
	Biotechnology: ["M.Sc. Biotechnology", "M.Sc. Molecular Biology"],
	"Civil Engineering": ["M.Sc. Civil Engineering", "M.Sc. Structural Engineering"],
	Architecture: ["M.Arch", "M.Sc. Urban Design"]
};
var TASKS = [
	"Submit Uni-Assist",
	"Collect APS certificate",
	"Upload SOP draft",
	"Follow up on offer",
	"Verify transcripts",
	"Blocked account application",
	"Pay remaining fee",
	"Book visa slot",
	"Courier documents",
	"Update IELTS score"
];
var PIPELINES = [
	"New",
	"Shortlisting",
	"Applications",
	"Offer",
	"Visa"
];
function intakePrefix(intake) {
	if (intake.startsWith("Winter")) return "W" + intake.slice(-2);
	if (intake.startsWith("Summer")) return "S" + intake.slice(-2);
	if (intake.startsWith("January")) return "JAN";
	return "SP" + intake.slice(-2);
}
function weightedStatus(r) {
	const x = r();
	if (x < .16) return "Shortlisting Sent";
	if (x < .38) return "Applications Started";
	if (x < .46) return "Applications on Hold";
	if (x < .62) return "Offered";
	if (x < .72) return "Waiting";
	if (x < .78) return "Deferred";
	if (x < .84) return "Dropped";
	if (x < .88) return "Private Registered";
	if (x < .91) return "Private Shifted";
	if (x < .94) return "Still Thinking";
	return "Got Visa";
}
function paymentFromAmounts(total, paid, discount) {
	if (paid >= total - discount) return "Paid";
	if (paid <= 0) return "Pending";
	if (paid < total * .25) return "Overdue";
	return "Partially Paid";
}
function createSeed(now = Date.now()) {
	const r = rng(26092026);
	const employees = [
		{
			id: "EMP-001",
			name: "Hari",
			email: "admin@demo.com",
			phone: "+91 98480 11001",
			role: "admin",
			title: "Administrator",
			department: "Operations",
			status: "Active",
			lastActive: iso(now - 48e4),
			joinedAt: iso(now - 74304e6),
			avatarHue: 210
		},
		{
			id: "EMP-002",
			name: "Nagaraju",
			email: "employee@demo.com",
			phone: "+91 98480 11002",
			role: "employee",
			title: "Senior Counselor",
			department: "Germany Desk",
			status: "Active",
			lastActive: iso(now - 72e4),
			joinedAt: iso(now - 55296e6),
			avatarHue: 188
		},
		{
			id: "EMP-003",
			name: "Bhavani",
			email: "bhavani@meridian.edu",
			phone: "+91 98480 11003",
			role: "employee",
			title: "Counselor",
			department: "Germany Desk",
			status: "Active",
			lastActive: iso(now - 24e5),
			joinedAt: iso(now - 432e8),
			avatarHue: 320
		},
		{
			id: "EMP-004",
			name: "Bharathi",
			email: "bharathi@meridian.edu",
			phone: "+91 98480 11004",
			role: "employee",
			title: "Counselor",
			department: "UK Desk",
			status: "Active",
			lastActive: iso(now - 54e5),
			joinedAt: iso(now - 37152e6),
			avatarHue: 12
		},
		{
			id: "EMP-005",
			name: "Sony",
			email: "sony@meridian.edu",
			phone: "+91 98480 11005",
			role: "employee",
			title: "Counselor",
			department: "USA Desk",
			status: "Active",
			lastActive: iso(now - 15e5),
			joinedAt: iso(now - 32832e6),
			avatarHue: 145
		},
		{
			id: "EMP-006",
			name: "Nagamani",
			email: "nagamani@meridian.edu",
			phone: "+91 98480 11006",
			role: "employee",
			title: "Lead Coordinator",
			department: "Admissions",
			status: "Active",
			lastActive: iso(now - 66e5),
			joinedAt: iso(now - 2592e7),
			avatarHue: 265
		},
		{
			id: "EMP-007",
			name: "Chaitanya",
			email: "chaitanya@meridian.edu",
			phone: "+91 98480 11007",
			role: "employee",
			title: "Counselor",
			department: "Germany Desk",
			status: "Active",
			lastActive: iso(now - 108e5),
			joinedAt: iso(now - 24192e6),
			avatarHue: 28
		},
		{
			id: "EMP-008",
			name: "Swaroopa",
			email: "swaroopa@meridian.edu",
			phone: "+91 98480 11008",
			role: "employee",
			title: "Documentation Lead",
			department: "Operations",
			status: "Active",
			lastActive: iso(now - 18e6),
			joinedAt: iso(now - 19008e6),
			avatarHue: 198
		},
		{
			id: "EMP-009",
			name: "Anil",
			email: "anil@meridian.edu",
			phone: "+91 98480 11009",
			role: "employee",
			title: "Counselor",
			department: "UK Desk",
			status: "Active",
			lastActive: iso(now - 936e5),
			joinedAt: iso(now - 1728e7),
			avatarHue: 88
		},
		{
			id: "EMP-010",
			name: "Sravya",
			email: "sravya@meridian.edu",
			phone: "+91 98480 11010",
			role: "employee",
			title: "Counselor",
			department: "USA Desk",
			status: "Active",
			lastActive: iso(now - 144e5),
			joinedAt: iso(now - 13824e6),
			avatarHue: 340
		},
		{
			id: "EMP-011",
			name: "Nikhila",
			email: "nikhila@meridian.edu",
			phone: "+91 98480 11011",
			role: "employee",
			title: "Counselor",
			department: "Germany Desk",
			status: "Active",
			lastActive: iso(now - 3e6),
			joinedAt: iso(now - 10368e6),
			avatarHue: 55
		},
		{
			id: "EMP-012",
			name: "Deepak",
			email: "deepak@meridian.edu",
			phone: "+91 98480 11012",
			role: "employee",
			title: "Finance Associate",
			department: "Finance",
			status: "Active",
			lastActive: iso(now - 288e5),
			joinedAt: iso(now - 7776e6),
			avatarHue: 170
		},
		{
			id: "EMP-013",
			name: "Lakshmi",
			email: "lakshmi@meridian.edu",
			phone: "+91 98480 11013",
			role: "employee",
			title: "Counselor",
			department: "Admissions",
			status: "Active",
			lastActive: iso(now - 1728e5),
			joinedAt: iso(now - 6048e6),
			avatarHue: 300
		},
		{
			id: "EMP-014",
			name: "Ramesh",
			email: "ramesh@meridian.edu",
			phone: "+91 98480 11014",
			role: "employee",
			title: "University Relations",
			department: "Partnerships",
			status: "Inactive",
			lastActive: iso(now - 15552e5),
			joinedAt: iso(now - 3456e7),
			avatarHue: 40
		},
		{
			id: "EMP-015",
			name: "Kavitha",
			email: "kavitha@meridian.edu",
			phone: "+91 98480 11015",
			role: "employee",
			title: "Counselor",
			department: "UK Desk",
			status: "Active",
			lastActive: iso(now - 216e5),
			joinedAt: iso(now - 3888e6),
			avatarHue: 220
		},
		{
			id: "EMP-016",
			name: "Praveen",
			email: "praveen@meridian.edu",
			phone: "+91 98480 11016",
			role: "employee",
			title: "Junior Counselor",
			department: "Admissions",
			status: "Active",
			lastActive: iso(now - 48e5),
			joinedAt: iso(now - 1728e6),
			avatarHue: 130
		}
	];
	const counselors = employees.filter((e) => e.role === "employee" && e.status === "Active");
	const universities = [];
	const uniRows = [
		...UNI_DE.map(([n, l]) => [
			n,
			l,
			"Germany"
		]),
		...UNI_UK.map(([n, l]) => [
			n,
			l,
			"UK"
		]),
		...UNI_US.map(([n, l]) => [
			n,
			l,
			"USA"
		])
	];
	uniRows.forEach(([name, location, country], i) => {
		const branch = name.includes("Munich") ? "Computer Science" : BRANCHES[i % BRANCHES.length];
		const course = name.includes("Munich") ? "M.Sc. Computer Science" : pick(r, COURSES[branch] ?? ["M.Sc. Engineering"]);
		const intake = pick(r, INTAKES);
		universities.push({
			id: `UNI-${pad(i + 1)}`,
			name,
			location,
			country,
			course,
			branch,
			intake,
			ielts: country === "Germany" ? pick(r, [
				6,
				6.5,
				7
			]) : pick(r, [
				6.5,
				7,
				7.5
			]),
			toefl: country === "USA" ? pick(r, [
				80,
				90,
				100
			]) : pick(r, [
				72,
				79,
				88,
				94
			]),
			germanLanguage: country === "Germany" ? pick(r, [
				"A2",
				"B1",
				"B2"
			]) : "None",
			gre: country === "USA" ? pick(r, [
				"Optional",
				"300+",
				"310+",
				"Not required"
			]) : "Not required",
			germanGrade: country === "Germany" ? Number((1.8 + r() * 1.4).toFixed(1)) : 2.5,
			applicationVia: country === "Germany" ? pick(r, [
				"Uni-Assist",
				"Direct",
				"Hochschulstart"
			]) : country === "UK" ? "UCAS / Direct" : "University portal",
			applicationFee: country === "Germany" ? pick(r, [
				0,
				75,
				100
			]) : country === "UK" ? pick(r, [
				0,
				28,
				60
			]) : pick(r, [
				50,
				75,
				85,
				125
			]),
			deadline: iso(now + (20 + Math.floor(r() * 140)) * 864e5),
			tuitionFees: country === "Germany" ? pick(r, [
				0,
				3e3,
				4500,
				12e3,
				18e3
			]) * 90 : country === "UK" ? pick(r, [
				18e3,
				22e3,
				26500,
				31e3
			]) * 105 : pick(r, [
				28e3,
				34e3,
				42e3,
				52e3
			]) * 83,
			moi: r() > .35,
			documentsCourier: country === "Germany" ? pick(r, [
				"Required",
				"Not required",
				"After offer"
			]) : "Not required",
			aptitudeTest: country === "USA" ? pick(r, ["GRE optional", "None"]) : country === "Germany" ? pick(r, ["None", "TestAS optional"]) : "None",
			archived: i === uniRows.length - 1
		});
	});
	const featured = [
		"Rahul Kumar",
		"Priya Sharma",
		"Ananya Reddy",
		"Vikram Singh",
		"Sneha Patel",
		"Arjun Nair"
	];
	const names = [...featured];
	const used = new Set(featured);
	while (names.length < 72) {
		const n = `${pick(r, FIRST)} ${pick(r, LAST)}`;
		if (!used.has(n)) {
			used.add(n);
			names.push(n);
		}
	}
	const counters = { W26: 1 };
	const students = names.map((name, i) => {
		const country = i === 0 ? "Germany" : i % 10 < 5 ? "Germany" : i % 10 < 8 ? "UK" : "USA";
		const intake = i === 0 ? "Winter 2026" : pick(r, INTAKES);
		const prefix = intakePrefix(intake);
		let id;
		if (i === 0) id = "W26_001";
		else {
			counters[prefix] = (counters[prefix] ?? 0) + 1;
			id = `${prefix}_${pad(counters[prefix])}`;
		}
		const status = i < 6 ? [
			"Applications Started",
			"Offered",
			"Got Visa",
			"Waiting",
			"Shortlisting Sent",
			"Applications Started"
		][i] : weightedStatus(r);
		const branch = pick(r, BRANCHES);
		const totalFee = pick(r, [
			75e3,
			85e3,
			1e5,
			12e4,
			15e4
		]);
		const discount = r() > .7 ? pick(r, [
			5e3,
			8e3,
			1e4,
			15e3
		]) : 0;
		const paidRatio = status === "Dropped" ? r() * .2 : .2 + r() * .8;
		const paidAmount = Math.min(totalFee - discount, Math.round(totalFee * paidRatio / 1e3) * 1e3);
		const employee = i < 12 ? counselors[1 % counselors.length] : pick(r, counselors);
		const assigned = i < 12 ? employees.find((e) => e.id === "EMP-002") : employee;
		const createdAt = now - Math.floor((20 + r() * 250) * 864e5);
		const updatedAt = now - Math.floor(r() * 12 * 864e5);
		const slug = name.toLowerCase().replaceAll(" ", ".");
		const germany = country === "Germany";
		return {
			id,
			name,
			email: `${slug}@gmail.com`,
			phone1: phone(r),
			phone2: r() > .55 ? phone(r) : "",
			country,
			intake,
			branch,
			college: pick(r, COLLEGES),
			employeeId: assigned.id,
			status,
			paymentStatus: paymentFromAmounts(totalFee, paidAmount, discount),
			createdAt: iso(createdAt),
			updatedAt: iso(Math.max(createdAt, updatedAt)),
			cgpa: Number((6.8 + r() * 2.6).toFixed(2)),
			ielts: r() > .15 ? Number((6 + r() * 2.5).toFixed(1)) : void 0,
			toefl: country === "USA" || r() > .7 ? Math.round(78 + r() * 30) : void 0,
			duolingo: r() > .8 ? Math.round(105 + r() * 40) : void 0,
			germanGrade: germany ? Number((1.6 + r() * 1.8).toFixed(1)) : void 0,
			gre: country === "USA" && r() > .4 ? Math.round(300 + r() * 28) : void 0,
			germanLanguage: germany ? pick(r, [
				"A1",
				"A2",
				"B1",
				"B2"
			]) : "None",
			gmailId: `${slug}@gmail.com`,
			gmailPassword: `Meridian!${pad(i + 11, 2)}`,
			recoveryNumber: phone(r),
			device: pick(r, DEVICES),
			twoStep: r() > .35,
			apsUsername: germany ? `aps.${slug.split(".")[0]}` : void 0,
			apsPassword: germany ? `Aps#${pad(i + 21, 2)}` : void 0,
			uniAssistId: germany ? `UA${8e5 + i}` : void 0,
			uniAssistPassword: germany ? `Ua@${pad(i + 31, 2)}` : void 0,
			uniAssistDocuments: germany ? r() > .4 ? "Uploaded" : "Not Uploaded" : void 0,
			blockedAccount: germany ? r() > .55 ? "Applied" : "Not Applied" : void 0,
			enrollment: germany ? status === "Got Visa" || r() > .75 ? "Applied" : "Not Applied" : void 0,
			studentDorm: germany ? r() > .7 ? "Applied" : "Not Applied" : void 0,
			totalFee,
			paidAmount,
			discount,
			leadType: r() > .78 ? "B2B" : "Direct",
			b2bOrg: void 0,
			notes: "",
			avatarHue: hue(r)
		};
	});
	const rahul = students[0];
	if (rahul) {
		const clash = students.findIndex((s, i) => i !== 0 && s.id === "W26_001");
		if (clash >= 0) students[clash].id = `W26_${pad(90 + clash)}`;
		Object.assign(rahul, {
			id: "W26_001",
			name: "Rahul Kumar",
			email: "rahul.kumar@gmail.com",
			gmailId: "rahul.kumar@gmail.com",
			country: "Germany",
			intake: "Winter 2026",
			branch: "Computer Science",
			employeeId: "EMP-002",
			status: "Applications Started"
		});
	}
	students.forEach((s) => {
		if (s.leadType === "B2B") s.b2bOrg = pick(r, [
			"EdVista Partners",
			"Global Path Academy",
			"Horizon Overseas",
			"Brightway Consultants",
			"Aarambh Education"
		]);
	});
	const applications = [];
	let appN = 1;
	students.forEach((s) => {
		const pool = universities.filter((u) => u.country === s.country && !u.archived);
		const tum = universities.find((u) => u.name.includes("Munich"));
		const count = 1 + Math.floor(r() * 3);
		let chosen = pickN(r, pool, Math.min(count, pool.length));
		if (s.id === "W26_001" && tum) chosen = [tum, ...chosen.filter((u) => u.id !== tum.id)].slice(0, Math.max(2, chosen.length));
		chosen.forEach((u, idx) => {
			const submitted = s.status !== "Shortlisting Sent" && s.status !== "Still Thinking";
			applications.push({
				id: `APP-${pad(appN++, 4)}`,
				studentId: s.id,
				universityId: u.id,
				course: u.course,
				country: u.country,
				status: idx === 0 ? s.status : pick(r, APPLICATION_STATUSES),
				submittedAt: submitted ? iso(now - Math.floor(r() * 60) * 864e5) : void 0,
				offerReceived: s.status === "Offered" || s.status === "Got Visa" || s.status === "Waiting" ? idx === 0 : r() > .85,
				deadline: u.deadline,
				employeeId: s.employeeId,
				createdAt: s.createdAt
			});
		});
	});
	const payments = students.map((s, i) => ({
		id: `PAY-${pad(i + 1, 3)}`,
		studentId: s.id,
		totalFee: s.totalFee,
		initialPayment: Math.min(s.paidAmount, Math.round(s.totalFee * .4)),
		remaining: Math.max(0, s.totalFee - s.discount - s.paidAmount),
		discount: s.discount,
		status: s.paymentStatus,
		lastPayment: s.paidAmount > 0 ? s.updatedAt : void 0,
		method: s.paidAmount > 0 ? pick(r, [
			"UPI",
			"NEFT",
			"Card",
			"Cash"
		]) : void 0
	}));
	const leads = Array.from({ length: 32 }, (_, i) => {
		const name = `${pick(r, FIRST)} ${pick(r, LAST)}`;
		const pipeline = pick(r, PIPELINES);
		const type = r() > .7 ? "B2B" : "Direct";
		const created = now - Math.floor(r() * 40) * 864e5;
		return {
			id: `LD-${pad(i + 1, 3)}`,
			name,
			email: `${name.toLowerCase().replaceAll(" ", ".")}@gmail.com`,
			phone: phone(r),
			country: pick(r, [
				"Germany",
				"UK",
				"USA"
			]),
			intake: pick(r, INTAKES),
			employeeId: i < 6 ? "EMP-002" : pick(r, counselors).id,
			type,
			b2bOrg: type === "B2B" ? pick(r, [
				"EdVista Partners",
				"Global Path Academy",
				"Horizon Overseas",
				"Brightway Consultants"
			]) : void 0,
			pipeline,
			status: pipeline,
			createdAt: iso(created),
			updatedAt: iso(created + Math.floor(r() * 8) * 864e5),
			notes: ""
		};
	});
	const documents = [];
	const documentVersions = [];
	const documentActivities = [];
	const portals = [];
	const portalAccessLogs = [];
	let docN = 1;
	let verN = 1;
	let actN = 1;
	const tum = universities.find((u) => u.name.includes("Munich")) ?? universities.find((u) => u.country === "Germany");
	function pushActivity(documentId, studentId, actor, actorRole, action, timestamp, detail) {
		documentActivities.push({
			id: `DA-${pad(actN++, 4)}`,
			documentId,
			studentId,
			actor,
			actorRole,
			action,
			detail,
			timestamp
		});
	}
	students.forEach((s, si) => {
		buildRequirementDocs(s, s.id === "W26_001" && tum ? [{
			type: "SOP",
			required: true,
			universityId: tum.id,
			universityName: tum.name,
			course: tum.course
		}] : s.country === "Germany" && tum && r() > .72 ? [{
			type: "SOP",
			required: true,
			universityId: tum.id,
			universityName: tum.name,
			course: tum.course
		}] : [], iso(now)).forEach((req, ri) => {
			const id = `DOC-${pad(docN++, 4)}`;
			let status = "pending";
			let uploadedBy;
			let uploadedByRole;
			let uploadedAt;
			let fileName;
			let fileType;
			let fileSize;
			let version = 0;
			const due = ri % 4 === 1 ? iso(now + (3 + Math.floor(r() * 18)) * 864e5) : ri % 7 === 0 ? iso(now - 1728e5) : void 0;
			if (s.id === "W26_001") {
				const row = [
					{
						status: "verified",
						by: "Nagaraju",
						role: "employee",
						days: 0
					},
					{
						status: "under_review",
						by: "Rahul Kumar",
						role: "student",
						days: 0
					},
					{
						status: "verified",
						by: "Nagaraju",
						role: "employee",
						days: 1
					},
					{
						status: "pending",
						by: "Nagaraju",
						role: "employee",
						days: 0
					},
					{
						status: "uploaded",
						by: "Nagaraju",
						role: "employee",
						days: 2
					},
					{
						status: "under_review",
						by: "Rahul Kumar",
						role: "student",
						days: 0
					},
					{
						status: "verified",
						by: "Nagaraju",
						role: "employee",
						days: 3
					},
					{
						status: "verified",
						by: "Nagaraju",
						role: "employee",
						days: 4
					},
					{
						status: "pending",
						by: "Nagaraju",
						role: "employee",
						days: 0
					},
					{
						status: "verified",
						by: "Nagaraju",
						role: "employee",
						days: 5
					},
					{
						status: "verified",
						by: "Nagaraju",
						role: "employee",
						days: 6
					},
					{
						status: "uploaded",
						by: "Rahul Kumar",
						role: "student",
						days: 0
					},
					{
						status: "pending",
						by: "Nagaraju",
						role: "employee",
						days: 0
					}
				][ri] ?? {
					status: "pending",
					by: "Nagaraju",
					role: "employee",
					days: 0
				};
				status = row.status;
				if (status !== "pending") {
					uploadedBy = row.by;
					uploadedByRole = row.role;
					uploadedAt = iso(now - row.days * 864e5 - 54e5);
					fileName = `${req.type.replaceAll(" ", "-")}.pdf`;
					fileType = "application/pdf";
					fileSize = `${(.6 + r() * 2.4).toFixed(1)} MB`;
					version = req.type === "Passport" ? 2 : 1;
				}
			} else {
				const roll = r();
				if (roll > .22) {
					status = roll > .72 ? "verified" : roll > .5 ? "under_review" : roll > .38 ? "uploaded" : roll > .3 ? "rejected" : "uploaded";
					uploadedBy = r() > .55 ? s.name : employees.find((e) => e.id === s.employeeId)?.name ?? "Nagaraju";
					uploadedByRole = uploadedBy === s.name ? "student" : "employee";
					uploadedAt = iso(now - Math.floor(r() * 40) * 864e5);
					fileName = `${req.type.replaceAll(" ", "-")}.${r() > .85 ? "jpg" : "pdf"}`;
					fileType = fileName.endsWith(".jpg") ? "image/jpeg" : "application/pdf";
					fileSize = `${(.4 + r() * 3.6).toFixed(1)} MB`;
					version = 1;
				} else if (r() > .92) status = "expired";
			}
			const doc = {
				...req,
				id,
				status,
				uploadedBy,
				uploadedByRole,
				uploadedAt,
				fileName,
				fileType,
				fileSize,
				version,
				dueDate: due,
				rejectReason: status === "rejected" ? "Document unclear" : void 0,
				updatedAt: uploadedAt ?? req.updatedAt
			};
			documents.push(doc);
			if (version > 0 && fileName) {
				for (let v = 1; v <= version; v++) documentVersions.push({
					id: `VER-${pad(verN++, 4)}`,
					documentId: id,
					studentId: s.id,
					version: v,
					fileName,
					fileType: fileType ?? "application/pdf",
					fileSize: fileSize ?? "1.0 MB",
					uploadedBy: v === version ? uploadedBy ?? "Nagaraju" : "Nagaraju",
					uploadedByRole: v === version ? uploadedByRole ?? "employee" : "employee",
					uploadedAt: iso((uploadedAt ? new Date(uploadedAt).getTime() : now) - (version - v) * 864e5)
				});
				pushActivity(id, s.id, uploadedBy ?? "Nagaraju", uploadedByRole ?? "employee", "uploaded document", uploadedAt ?? iso(now), fileName);
				if (status === "verified") pushActivity(id, s.id, "Nagaraju", "employee", "verified document", iso(now - 27e5));
				if (status === "rejected") pushActivity(id, s.id, "Nagaraju", "employee", "rejected document", iso(now - 12e5), "Document unclear");
			}
		});
		if (s.id === "W26_001" || si < 10 && r() > .35) {
			const token = s.id === "W26_001" ? "Ab92Xk7Pq82Lm" : `Tk${pad(si, 3)}${Math.floor(r() * 9e4 + 1e4)}`;
			const portal = {
				id: `PRT-${pad(si + 1, 3)}`,
				studentId: s.id,
				accessMethod: s.id === "W26_001" ? "email_and_link" : r() > .5 ? "link_only" : "email_and_link",
				email: s.email,
				token,
				status: "active",
				expiresAt: iso(now + 6048e5),
				permissions: { ...DEFAULT_PORTAL_PERMISSIONS },
				createdAt: iso(now - 1728e5),
				lastAccessedAt: s.id === "W26_001" ? iso(now - 168e4) : void 0
			};
			portals.push(portal);
			if (s.id === "W26_001") portalAccessLogs.push({
				id: "PAL-001",
				portalId: portal.id,
				studentId: s.id,
				actor: s.name,
				action: "accessed portal",
				timestamp: iso(now - 168e4)
			}, {
				id: "PAL-002",
				portalId: portal.id,
				studentId: s.id,
				actor: s.name,
				action: "uploaded Transcript.pdf",
				timestamp: iso(now - 156e4)
			}, {
				id: "PAL-003",
				portalId: portal.id,
				studentId: s.id,
				actor: s.name,
				action: "uploaded Passport.pdf",
				timestamp: iso(now - 138e4)
			});
		}
	});
	const workItems = [];
	students.filter((s) => s.employeeId === "EMP-002").slice(0, 8).forEach((s, i) => {
		workItems.push({
			id: `WQ-${pad(i + 1, 3)}`,
			studentId: s.id,
			studentName: s.name,
			task: TASKS[i % TASKS.length],
			priority: i < 3 ? "High" : i < 6 ? "Medium" : "Low",
			deadline: iso(now + (i - 1) * 864e5),
			status: i === 2 ? "In Progress" : "Pending",
			employeeId: "EMP-002"
		});
	});
	students.filter((s) => s.employeeId !== "EMP-002").slice(0, 10).forEach((s, i) => {
		workItems.push({
			id: `WQ-${pad(i + 20, 3)}`,
			studentId: s.id,
			studentName: s.name,
			task: pick(r, TASKS),
			priority: pick(r, [
				"High",
				"Medium",
				"Low"
			]),
			deadline: iso(now + Math.floor(r() * 10 - 2) * 864e5),
			status: "Pending",
			employeeId: s.employeeId
		});
	});
	const auditEvents = [];
	const modules = [
		"Students",
		"Applications",
		"Payments",
		"Universities",
		"Employees",
		"Leads",
		"Reports"
	];
	const actions = [
		{
			action: "CREATE",
			severity: "SUCCESS",
			details: "Created student"
		},
		{
			action: "STATUS_CHANGE",
			severity: "WARNING",
			details: "Updated application status"
		},
		{
			action: "PAYMENT_UPDATE",
			severity: "WARNING",
			details: "Recorded payment"
		},
		{
			action: "UPDATE",
			severity: "INFO",
			details: "Updated student profile"
		},
		{
			action: "UNIVERSITY_UPDATE",
			severity: "INFO",
			details: "Updated university record"
		},
		{
			action: "EMPLOYEE_ASSIGN",
			severity: "INFO",
			details: "Reassigned counselor"
		},
		{
			action: "LOGIN",
			severity: "INFO",
			details: "Signed in"
		},
		{
			action: "EXPORT",
			severity: "INFO",
			details: "Exported report"
		},
		{
			action: "DELETE",
			severity: "CRITICAL",
			details: "Deleted draft record"
		},
		{
			action: "VIEW",
			severity: "INFO",
			details: "Viewed student credentials"
		}
	];
	for (let i = 0; i < 220; i++) {
		const actor = i % 17 === 0 ? employees[0] : pick(r, counselors);
		const student = pick(r, students);
		const spec = pick(r, actions);
		const ts = now - Math.floor(r() * (i < 48 ? 16 : 720) * 36e5);
		const before = spec.action === "STATUS_CHANGE" ? pick(r, APPLICATION_STATUSES) : spec.action === "PAYMENT_UPDATE" ? "Pending" : void 0;
		const after = spec.action === "STATUS_CHANGE" ? student.status : spec.action === "PAYMENT_UPDATE" ? student.paymentStatus : void 0;
		auditEvents.push({
			id: `AUD-${8e5 + i}`,
			timestamp: iso(ts),
			user: actor.name,
			userId: actor.id,
			role: actor.role,
			action: spec.action,
			module: spec.action === "LOGIN" ? "Auth" : spec.action === "UNIVERSITY_UPDATE" ? "Universities" : spec.action === "EXPORT" ? "Reports" : pick(r, modules),
			recordId: spec.action === "LOGIN" ? actor.id : student.id,
			before,
			after,
			details: spec.details,
			severity: spec.severity,
			ip: pick(r, IPS),
			userAgent: pick(r, AGENTS)
		});
	}
	auditEvents.sort((a, b) => a.timestamp < b.timestamp ? 1 : -1);
	auditEvents.unshift({
		id: "AUD-DOC-1",
		timestamp: iso(now - 138e4),
		user: "Rahul Kumar",
		userId: "W26_001",
		role: "student",
		action: "STUDENT_UPLOADED_DOCUMENT",
		module: "Documents",
		recordId: "W26_001",
		details: "Uploaded document Transcript.pdf",
		after: "under_review",
		severity: "SUCCESS",
		ip: "49.37.8.122",
		userAgent: "Chrome / Android"
	}, {
		id: "AUD-DOC-2",
		timestamp: iso(now - 9e5),
		user: "Nagaraju",
		userId: "EMP-002",
		role: "employee",
		action: "PORTAL_CREATED",
		module: "Documents",
		recordId: "W26_001",
		details: "Created student upload portal · Access: Email + Link",
		after: "email_and_link",
		severity: "SUCCESS",
		ip: "192.168.14.22",
		userAgent: "Chrome / Android"
	}, {
		id: "AUD-DOC-3",
		timestamp: iso(now - 27e5),
		user: "Nagaraju",
		userId: "EMP-002",
		role: "employee",
		action: "DOCUMENT_VERIFIED",
		module: "Documents",
		recordId: "W26_001",
		details: "Verified Passport.pdf",
		before: "under_review",
		after: "verified",
		severity: "SUCCESS",
		ip: "192.168.14.22",
		userAgent: "Chrome / Android"
	}, {
		id: "AUD-DOC-4",
		timestamp: iso(now - 42e5),
		user: "Priya Sharma",
		userId: students[1].id,
		role: "student",
		action: "STUDENT_REPLACED_DOCUMENT",
		module: "Documents",
		recordId: students[1].id,
		details: "Replaced Passport.pdf",
		before: "rejected",
		after: "under_review",
		severity: "INFO",
		ip: "103.210.44.18",
		userAgent: "Chrome / Windows"
	}, {
		id: "AUD-829182",
		timestamp: iso(now - 9e5),
		user: "Nagaraju",
		userId: "EMP-002",
		role: "employee",
		action: "STATUS_CHANGE",
		module: "Students",
		recordId: students[0].id,
		before: "Applications Started",
		after: "Offered",
		details: "Updated student status",
		severity: "WARNING",
		ip: "192.168.14.22",
		userAgent: "Chrome / Android"
	}, {
		id: "AUD-829183",
		timestamp: iso(now - 174e4),
		user: "Priya Sharma",
		userId: "EMP-003",
		role: "employee",
		action: "CREATE",
		module: "Students",
		recordId: students[1].id,
		details: "Registered a new student",
		severity: "SUCCESS",
		ip: "103.210.44.18",
		userAgent: "Chrome / Windows"
	}, {
		id: "AUD-829184",
		timestamp: iso(now - 378e4),
		user: "Hari",
		userId: "EMP-001",
		role: "admin",
		action: "UNIVERSITY_UPDATE",
		module: "Universities",
		recordId: universities[0].id,
		details: "Updated university eligibility data",
		severity: "INFO",
		ip: "192.168.8.41",
		userAgent: "Chrome / macOS"
	});
	return {
		employees,
		students,
		universities,
		applications,
		payments,
		leads,
		documents,
		documentVersions,
		documentActivities,
		portals,
		portalAccessLogs,
		workItems,
		auditEvents,
		notifications: [
			{
				id: "NT-1",
				title: "New student registered",
				body: `${students[1].name} was added to Winter 2026.`,
				timestamp: iso(now - 108e4),
				read: false,
				href: `/admin/students/${students[1].id}`,
				kind: "student"
			},
			{
				id: "NT-2",
				title: "Payment pending",
				body: `Balance remaining for ${students[0].name}.`,
				timestamp: iso(now - 252e4),
				read: false,
				href: `/admin/payments`,
				kind: "payment"
			},
			{
				id: "NT-3",
				title: "Application deadline approaching",
				body: `${universities[2].name} deadline is in 6 days.`,
				timestamp: iso(now - 72e5),
				read: false,
				href: `/admin/universities`,
				kind: "application"
			},
			{
				id: "NT-4",
				title: "Offer received",
				body: `${students[0].name} received an offer.`,
				timestamp: iso(now - 18e6),
				read: false,
				href: `/admin/students/${students[0].id}`,
				kind: "application"
			},
			{
				id: "NT-5",
				title: "Status changed",
				body: `Nagaraju updated ${students[0].id} to Offered.`,
				timestamp: iso(now - 9e5),
				read: false,
				href: `/admin/audit`,
				kind: "student"
			},
			{
				id: "NT-6",
				title: "Visa received",
				body: `${students[2].name} received a visa.`,
				timestamp: iso(now - 936e5),
				read: false,
				href: `/admin/students/${students[2].id}`,
				kind: "application"
			},
			{
				id: "NT-7",
				title: "Overdue payment",
				body: `A student payment marked overdue needs review.`,
				timestamp: iso(now - 108e6),
				read: false,
				href: `/admin/payments`,
				kind: "payment"
			},
			{
				id: "NT-8",
				title: "University data updated",
				body: "TUM eligibility thresholds were revised.",
				timestamp: iso(now - 1728e5),
				read: true,
				href: `/admin/universities`,
				kind: "system"
			},
			{
				id: "NT-9",
				title: "Weekly report ready",
				body: "Employee performance report is available to export.",
				timestamp: iso(now - 2592e5),
				read: true,
				href: `/admin/reports`,
				kind: "system"
			},
			{
				id: "NT-10",
				title: "Rahul uploaded Transcript.pdf",
				body: "A student upload is waiting for review.",
				timestamp: iso(now - 156e4),
				read: false,
				href: `/admin/students/W26_001`,
				kind: "document"
			},
			{
				id: "NT-11",
				title: "Priya replaced Passport.pdf",
				body: "A replacement file was submitted.",
				timestamp: iso(now - 42e5),
				read: false,
				href: `/admin/students/${students[1].id}`,
				kind: "document"
			},
			{
				id: "NT-12",
				title: "A document request is overdue",
				body: "SOP for Rahul Kumar is past its due date.",
				timestamp: iso(now - 108e5),
				read: false,
				href: `/admin/documents`,
				kind: "document"
			},
			{
				id: "NT-13",
				title: "Student portal expires tomorrow",
				body: "Rahul Kumar’s upload portal expires in 24 hours.",
				timestamp: iso(now - 18e6),
				read: false,
				href: `/admin/students/W26_001`,
				kind: "document"
			},
			{
				id: "NT-14",
				title: "Student completed document submission",
				body: `${students[2].name} submitted all requested documents.`,
				timestamp: iso(now - 324e5),
				read: false,
				href: `/admin/students/${students[2].id}`,
				kind: "document"
			},
			{
				id: "NT-15",
				title: "Document rejected by Nagaraju",
				body: "A document was rejected and a replacement was requested.",
				timestamp: iso(now - 396e5),
				read: false,
				href: `/admin/documents`,
				kind: "document"
			}
		],
		settings: {
			name: "Meridian",
			legalName: "Meridian Education Pvt. Ltd.",
			timezone: "Asia/Kolkata",
			currency: "INR",
			twoFactor: false,
			sessionTimeout: 30,
			loginNotifications: true,
			emailAlerts: true,
			slackAlerts: false,
			auditRetentionDays: 90,
			defaultIntake: "Winter 2026"
		}
	};
}
var cache = /* @__PURE__ */ new Map();
function setFileData(id, dataUrl) {
	cache.set(id, dataUrl);
}
function getFileData(id) {
	return cache.get(id);
}
function copyFileData(fromId, toId) {
	const data = cache.get(fromId);
	if (data) cache.set(toId, data);
}
function removeFileData(id) {
	cache.delete(id);
}
var seed = createSeed();
function uid(prefix) {
	return `${prefix}-${Math.floor(1e5 + Math.random() * 9e5)}`;
}
function nextStudentId(students, intake) {
	const prefix = intake.startsWith("Winter") ? `W${intake.slice(-2)}` : intake.startsWith("Summer") ? `S${intake.slice(-2)}` : intake.startsWith("January") ? "JAN" : `SP${intake.slice(-2)}`;
	const nums = students.filter((s) => s.id.startsWith(prefix + "_")).map((s) => Number(s.id.split("_")[1])).filter((n) => !Number.isNaN(n));
	const next = (nums.length ? Math.max(...nums) : 0) + 1;
	return `${prefix}_${String(next).padStart(3, "0")}`;
}
function actorSnapshot(state) {
	const user = state.currentUser;
	return {
		user: user?.name ?? "System",
		userId: user?.id ?? "system",
		role: user?.role ?? "admin",
		ip: "192.168.14.22",
		userAgent: typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 48) : "Meridian Web"
	};
}
function makeAudit(state, partial) {
	const { severity, user, userId, role, ...rest } = partial;
	const snap = actorSnapshot(state);
	return {
		id: uid("AUD"),
		timestamp: (/* @__PURE__ */ new Date()).toISOString(),
		...snap,
		...rest,
		user: user ?? snap.user,
		userId: userId ?? snap.userId,
		role: role ?? snap.role,
		severity: severity ?? "INFO"
	};
}
function notice(title, body, href, kind = "document") {
	return {
		id: uid("NT"),
		title,
		body,
		timestamp: (/* @__PURE__ */ new Date()).toISOString(),
		read: false,
		href,
		kind
	};
}
function workspaceHref(state, studentId) {
	return `/${state.currentUser?.role === "employee" ? "employee" : "admin"}/students/${studentId}`;
}
function activity(documentId, studentId, actor, actorRole, action, detail) {
	return {
		id: uid("DA"),
		documentId,
		studentId,
		actor,
		actorRole,
		action,
		detail,
		timestamp: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function touchShortlist(list, studentId, mutator) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	if (!list.find((s) => s.studentId === studentId)) return [mutator({
		studentId,
		universityIds: [],
		studentMessage: "",
		createdAt: now,
		updatedAt: now
	}), ...list];
	return list.map((s) => s.studentId === studentId ? {
		...mutator(s),
		updatedAt: now
	} : s);
}
function extrasForStudent(s, studentId) {
	return s.applications.filter((a) => a.studentId === studentId).slice(0, 1).map((a) => {
		const uni = s.universities.find((u) => u.id === a.universityId);
		return uni ? {
			type: "SOP",
			required: true,
			universityId: uni.id,
			universityName: uni.name,
			course: uni.course
		} : void 0;
	}).filter(Boolean);
}
var useAppStore = create()(persist((set, get) => ({
	hydrated: false,
	currentUser: null,
	theme: "system",
	sidebarCollapsed: false,
	students: seed.students,
	employees: seed.employees,
	universities: seed.universities,
	applications: seed.applications,
	payments: seed.payments,
	leads: seed.leads,
	documents: seed.documents,
	documentVersions: seed.documentVersions,
	documentActivities: seed.documentActivities,
	portals: seed.portals,
	portalAccessLogs: seed.portalAccessLogs,
	workItems: seed.workItems,
	shortlists: [],
	auditEvents: seed.auditEvents,
	notifications: seed.notifications,
	settings: seed.settings,
	setHydrated: (v) => set({ hydrated: v }),
	setTheme: (theme) => set({ theme }),
	setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
	login: (email, _password) => {
		const normalized = email.trim().toLowerCase();
		const user = get().employees.find((e) => e.email.toLowerCase() === normalized);
		if (!user) return {
			ok: false,
			error: "We couldn't find a workspace for that email."
		};
		if (user.status === "Inactive") return {
			ok: false,
			error: "This account is inactive."
		};
		set((s) => ({
			currentUser: user,
			auditEvents: [makeAudit(s, {
				action: "LOGIN",
				module: "Auth",
				recordId: user.id,
				details: `${user.name} signed in`,
				severity: "INFO"
			}), ...s.auditEvents]
		}));
		return {
			ok: true,
			user
		};
	},
	logout: () => {
		const user = get().currentUser;
		set((s) => ({
			currentUser: null,
			auditEvents: user ? [makeAudit({ currentUser: user }, {
				action: "LOGOUT",
				module: "Auth",
				recordId: user.id,
				details: `${user.name} signed out`,
				severity: "INFO"
			}), ...s.auditEvents] : s.auditEvents
		}));
	},
	appendAudit: (partial) => set((s) => ({ auditEvents: [makeAudit(s, partial), ...s.auditEvents] })),
	createStudent: (data) => {
		const id = data.id?.trim() || nextStudentId(get().students, data.intake);
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const paymentStatus = (data.paidAmount ?? 0) >= data.totalFee - (data.discount ?? 0) ? "Paid" : (data.paidAmount ?? 0) > 0 ? "Partially Paid" : "Pending";
		const student = {
			...data,
			id,
			createdAt: now,
			updatedAt: now,
			avatarHue: Math.floor(Math.random() * 360),
			paymentStatus,
			phone2: data.phone2 ?? "",
			notes: data.notes ?? ""
		};
		const seeded = buildRequirementDocs(student, extrasForStudent(get(), id), now).map((d) => ({
			...d,
			id: uid("DOC")
		}));
		set((s) => ({
			students: [student, ...s.students],
			documents: [...seeded, ...s.documents],
			payments: [{
				id: uid("PAY"),
				studentId: id,
				totalFee: student.totalFee,
				initialPayment: student.paidAmount,
				remaining: Math.max(0, student.totalFee - student.discount - student.paidAmount),
				discount: student.discount,
				status: paymentStatus,
				lastPayment: student.paidAmount > 0 ? now : void 0,
				method: student.paidAmount > 0 ? "UPI" : void 0
			}, ...s.payments],
			notifications: [notice("New student registered", `${student.name} (${student.id}) was added.`, `/${s.currentUser?.role === "employee" ? "employee" : "admin"}/students/${student.id}`, "student"), ...s.notifications],
			auditEvents: [makeAudit(s, {
				action: "CREATE",
				module: "Students",
				recordId: id,
				details: `Created student ${student.name}`,
				after: student.status,
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return student;
	},
	updateStudent: (id, patch) => set((s) => ({
		students: s.students.map((st) => st.id === id ? {
			...st,
			...patch,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : st),
		auditEvents: [makeAudit(s, {
			action: "UPDATE",
			module: "Students",
			recordId: id,
			details: `Updated student ${id}`,
			severity: "INFO"
		}), ...s.auditEvents]
	})),
	deleteStudent: (id) => set((s) => ({
		students: s.students.filter((st) => st.id !== id),
		applications: s.applications.filter((a) => a.studentId !== id),
		payments: s.payments.filter((p) => p.studentId !== id),
		documents: s.documents.filter((d) => d.studentId !== id),
		documentVersions: s.documentVersions.filter((d) => d.studentId !== id),
		documentActivities: s.documentActivities.filter((d) => d.studentId !== id),
		portals: s.portals.filter((p) => p.studentId !== id),
		portalAccessLogs: s.portalAccessLogs.filter((p) => p.studentId !== id),
		workItems: s.workItems.filter((w) => w.studentId !== id),
		auditEvents: [makeAudit(s, {
			action: "DELETE",
			module: "Students",
			recordId: id,
			details: `Deleted student ${id}`,
			severity: "CRITICAL"
		}), ...s.auditEvents]
	})),
	changeStudentStatus: (id, status) => set((s) => {
		const prev = s.students.find((st) => st.id === id)?.status;
		return {
			students: s.students.map((st) => st.id === id ? {
				...st,
				status,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : st),
			auditEvents: [makeAudit(s, {
				action: "STATUS_CHANGE",
				module: "Students",
				recordId: id,
				before: prev,
				after: status,
				details: `Status ${prev} → ${status}`,
				severity: "WARNING"
			}), ...s.auditEvents],
			notifications: [notice("Employee changed student status", `${s.currentUser?.name ?? "Someone"} moved ${id} to ${status}.`, workspaceHref(s, id), "student"), ...s.notifications]
		};
	}),
	assignEmployee: (studentId, employeeId) => set((s) => {
		const prev = s.students.find((st) => st.id === studentId)?.employeeId;
		return {
			students: s.students.map((st) => st.id === studentId ? {
				...st,
				employeeId,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : st),
			auditEvents: [makeAudit(s, {
				action: "EMPLOYEE_ASSIGN",
				module: "Students",
				recordId: studentId,
				before: prev,
				after: employeeId,
				details: `Assigned counselor ${employeeId}`,
				severity: "INFO"
			}), ...s.auditEvents]
		};
	}),
	updatePayment: (studentId, patch) => set((s) => {
		const student = s.students.find((st) => st.id === studentId);
		const paidAmount = patch.paidAmount ?? student?.paidAmount ?? 0;
		const totalFee = patch.totalFee ?? student?.totalFee ?? 0;
		const discount = patch.discount ?? student?.discount ?? 0;
		const remaining = Math.max(0, totalFee - discount - paidAmount);
		const status = patch.status ?? (paidAmount >= totalFee - discount ? "Paid" : paidAmount > 0 ? "Partially Paid" : "Pending");
		const now = (/* @__PURE__ */ new Date()).toISOString();
		return {
			students: s.students.map((st) => st.id === studentId ? {
				...st,
				paidAmount,
				totalFee,
				discount,
				paymentStatus: status,
				updatedAt: now
			} : st),
			payments: s.payments.map((p) => p.studentId === studentId ? {
				...p,
				...patch,
				totalFee,
				discount,
				remaining,
				status,
				lastPayment: now,
				initialPayment: p.initialPayment || paidAmount
			} : p),
			auditEvents: [makeAudit(s, {
				action: "PAYMENT_UPDATE",
				module: "Payments",
				recordId: studentId,
				before: student?.paymentStatus,
				after: status,
				details: `Payment updated for ${studentId}`,
				severity: "WARNING"
			}), ...s.auditEvents]
		};
	}),
	upsertUniversity: (data) => set((s) => {
		const exists = s.universities.some((u) => u.id === data.id);
		return {
			universities: exists ? s.universities.map((u) => u.id === data.id ? data : u) : [data, ...s.universities],
			auditEvents: [makeAudit(s, {
				action: exists ? "UNIVERSITY_UPDATE" : "CREATE",
				module: "Universities",
				recordId: data.id,
				details: exists ? `Updated ${data.name}` : `Added ${data.name}`,
				severity: exists ? "INFO" : "SUCCESS"
			}), ...s.auditEvents]
		};
	}),
	archiveUniversity: (id) => set((s) => ({
		universities: s.universities.map((u) => u.id === id ? {
			...u,
			archived: true
		} : u),
		auditEvents: [makeAudit(s, {
			action: "UNIVERSITY_UPDATE",
			module: "Universities",
			recordId: id,
			details: `Archived university ${id}`,
			severity: "WARNING"
		}), ...s.auditEvents]
	})),
	duplicateUniversity: (id) => {
		const src = get().universities.find((u) => u.id === id);
		if (!src) return null;
		const copy = {
			...src,
			id: uid("UNI"),
			name: `${src.name} (Copy)`,
			archived: false
		};
		set((s) => ({
			universities: [copy, ...s.universities],
			auditEvents: [makeAudit(s, {
				action: "CREATE",
				module: "Universities",
				recordId: copy.id,
				details: `Duplicated ${src.name}`,
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return copy;
	},
	deleteUniversity: (id) => set((s) => ({
		universities: s.universities.filter((u) => u.id !== id),
		auditEvents: [makeAudit(s, {
			action: "DELETE",
			module: "Universities",
			recordId: id,
			details: `Deleted university ${id}`,
			severity: "CRITICAL"
		}), ...s.auditEvents]
	})),
	toggleShortlist: (studentId, universityId) => set((s) => {
		const current = s.shortlists.find((x) => x.studentId === studentId)?.universityIds ?? [];
		const has = current.includes(universityId);
		const universityIds = has ? current.filter((id) => id !== universityId) : [...current, universityId];
		const uni = s.universities.find((u) => u.id === universityId);
		const student = s.students.find((st) => st.id === studentId);
		return {
			shortlists: touchShortlist(s.shortlists, studentId, (entry) => ({
				...entry,
				universityIds
			})),
			auditEvents: [makeAudit(s, {
				action: "SHORTLIST",
				module: "Universities",
				recordId: studentId,
				details: has ? `Removed ${uni?.name ?? universityId} from ${student?.name ?? studentId} shortlist` : `Shortlisted ${uni?.name ?? universityId} for ${student?.name ?? studentId}`,
				after: universityIds.join(", "),
				severity: "INFO"
			}), ...s.auditEvents]
		};
	}),
	setShortlist: (studentId, universityIds) => set((s) => {
		const student = s.students.find((st) => st.id === studentId);
		return {
			shortlists: touchShortlist(s.shortlists, studentId, (entry) => ({
				...entry,
				universityIds
			})),
			auditEvents: [makeAudit(s, {
				action: "SHORTLIST",
				module: "Universities",
				recordId: studentId,
				details: `Set shortlist of ${universityIds.length} universities for ${student?.name ?? studentId}`,
				after: universityIds.join(", "),
				severity: "SUCCESS"
			}), ...s.auditEvents]
		};
	}),
	setShortlistMessage: (studentId, studentMessage) => set((s) => ({ shortlists: touchShortlist(s.shortlists, studentId, (entry) => ({
		...entry,
		studentMessage
	})) })),
	clearShortlist: (studentId) => set((s) => ({
		shortlists: s.shortlists.filter((x) => x.studentId !== studentId),
		auditEvents: [makeAudit(s, {
			action: "SHORTLIST",
			module: "Universities",
			recordId: studentId,
			details: `Cleared university shortlist for ${studentId}`,
			severity: "WARNING"
		}), ...s.auditEvents]
	})),
	createApplicationsFromShortlist: (studentId, universityIds) => {
		const state = get();
		const student = state.students.find((st) => st.id === studentId);
		if (!student) return {
			created: 0,
			skipped: 0
		};
		const existing = new Set(state.applications.filter((a) => a.studentId === studentId).map((a) => a.universityId));
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const created = [];
		for (const universityId of universityIds) {
			if (existing.has(universityId)) continue;
			const uni = state.universities.find((u) => u.id === universityId);
			if (!uni) continue;
			created.push({
				id: uid("APP"),
				studentId,
				universityId,
				course: uni.course,
				country: uni.country,
				status: "Shortlisting Sent",
				offerReceived: false,
				deadline: uni.deadline,
				employeeId: student.employeeId,
				createdAt: now
			});
		}
		const nextStatus = (/* @__PURE__ */ new Set([
			"Applications Started",
			"Applications on Hold",
			"Offered",
			"Waiting",
			"Got Visa",
			"Private Registered",
			"Private Shifted"
		])).has(student.status) ? student.status : "Shortlisting Sent";
		set((s) => ({
			applications: [...created, ...s.applications],
			students: s.students.map((st) => st.id === studentId ? {
				...st,
				status: nextStatus,
				updatedAt: now
			} : st),
			auditEvents: [makeAudit(s, {
				action: "CREATE",
				module: "Applications",
				recordId: studentId,
				details: `Created ${created.length} applications from shortlist for ${student.name}`,
				after: nextStatus,
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return {
			created: created.length,
			skipped: universityIds.length - created.length
		};
	},
	upsertLead: (data) => set((s) => {
		const exists = s.leads.some((l) => l.id === data.id);
		return {
			leads: exists ? s.leads.map((l) => l.id === data.id ? data : l) : [data, ...s.leads],
			auditEvents: [makeAudit(s, {
				action: exists ? "UPDATE" : "CREATE",
				module: "Leads",
				recordId: data.id,
				details: exists ? `Updated lead ${data.name}` : `Created lead ${data.name}`,
				severity: exists ? "INFO" : "SUCCESS"
			}), ...s.auditEvents]
		};
	}),
	deleteLead: (id) => set((s) => ({
		leads: s.leads.filter((l) => l.id !== id),
		auditEvents: [makeAudit(s, {
			action: "DELETE",
			module: "Leads",
			recordId: id,
			details: `Deleted lead ${id}`,
			severity: "CRITICAL"
		}), ...s.auditEvents]
	})),
	upsertApplication: (data) => set((s) => {
		const exists = s.applications.some((a) => a.id === data.id);
		return {
			applications: exists ? s.applications.map((a) => a.id === data.id ? data : a) : [data, ...s.applications],
			auditEvents: [makeAudit(s, {
				action: exists ? "UPDATE" : "CREATE",
				module: "Applications",
				recordId: data.id,
				details: exists ? `Updated application ${data.id}` : `Created application ${data.id}`,
				severity: exists ? "INFO" : "SUCCESS"
			}), ...s.auditEvents]
		};
	}),
	updateEmployee: (id, patch) => set((s) => ({
		employees: s.employees.map((e) => e.id === id ? {
			...e,
			...patch
		} : e),
		currentUser: s.currentUser?.id === id ? {
			...s.currentUser,
			...patch
		} : s.currentUser,
		auditEvents: [makeAudit(s, {
			action: "UPDATE",
			module: "Employees",
			recordId: id,
			details: `Updated employee ${id}`,
			severity: "INFO"
		}), ...s.auditEvents]
	})),
	markNotificationRead: (id) => set((s) => ({ notifications: s.notifications.map((n) => n.id === id ? {
		...n,
		read: true
	} : n) })),
	markAllNotificationsRead: () => set((s) => ({ notifications: s.notifications.map((n) => ({
		...n,
		read: true
	})) })),
	addDocument: (doc) => {
		const created = {
			...doc,
			id: uid("DOC")
		};
		set((s) => ({
			documents: [created, ...s.documents],
			auditEvents: [makeAudit(s, {
				action: "DOCUMENT_UPLOADED",
				module: "Documents",
				recordId: doc.studentId,
				details: `Added ${doc.type}`,
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return created;
	},
	uploadDocumentFile: (input) => {
		const state = get();
		const student = state.students.find((st) => st.id === input.studentId);
		if (!student) return {
			ok: false,
			error: "Student not found."
		};
		const actorName = input.actorName ?? state.currentUser?.name ?? "Staff";
		const actorRole = input.actorRole ?? state.currentUser?.role ?? "employee";
		const fromStudent = Boolean(input.fromStudent) || actorRole === "student";
		const targetId = input.replaceExistingId ?? input.asNewVersionOf;
		const duplicate = !targetId && !input.forceNew && state.documents.find((d) => d.studentId === input.studentId && d.type === input.type && d.status !== "pending");
		if (duplicate) return {
			ok: false,
			error: `A ${input.type} document already exists.`,
			existing: duplicate
		};
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const nextStatus = fromStudent ? "under_review" : "uploaded";
		const existing = targetId ? state.documents.find((d) => d.id === targetId) : state.documents.find((d) => d.studentId === input.studentId && d.type === input.type && d.status === "pending");
		const id = existing?.id ?? uid("DOC");
		const version = (existing?.version ?? 0) + 1;
		const next = {
			id,
			studentId: input.studentId,
			name: input.name,
			type: input.type,
			category: existing?.category ?? (input.universityName ? "University" : categoryForType(input.type)),
			fileName: input.fileName,
			fileType: input.fileType,
			fileSize: input.fileSize,
			status: nextStatus,
			uploadedBy: actorName,
			uploadedByRole: actorRole,
			uploadedAt: now,
			updatedAt: now,
			required: input.required ?? existing?.required ?? true,
			priority: existing?.priority ?? "normal",
			version,
			internalNote: input.internalNote ?? existing?.internalNote,
			studentInstruction: input.studentInstruction ?? existing?.studentInstruction,
			dueDate: input.dueDate ?? existing?.dueDate,
			universityId: input.universityId ?? existing?.universityId,
			universityName: input.universityName ?? existing?.universityName,
			course: input.course ?? existing?.course,
			rejectReason: void 0,
			rejectNote: void 0,
			replacementRequested: false,
			replacementMessage: void 0
		};
		const ver = {
			id: uid("VER"),
			documentId: id,
			studentId: input.studentId,
			version,
			fileName: input.fileName,
			fileType: input.fileType,
			fileSize: input.fileSize,
			uploadedBy: actorName,
			uploadedByRole: actorRole,
			uploadedAt: now
		};
		if (input.dataUrl) {
			if (existing) copyFileData(existing.id, `${existing.id}:v${existing.version}`);
			setFileData(id, input.dataUrl);
			setFileData(ver.id, input.dataUrl);
		}
		const action = fromStudent ? existing && existing.version > 0 ? "STUDENT_REPLACED_DOCUMENT" : "STUDENT_UPLOADED_DOCUMENT" : existing && existing.version > 0 ? "DOCUMENT_REPLACED" : "DOCUMENT_UPLOADED";
		set((s) => ({
			documents: existing ? s.documents.map((d) => d.id === id ? next : d) : [next, ...s.documents],
			documentVersions: [ver, ...s.documentVersions],
			documentActivities: [activity(id, input.studentId, actorName, actorRole, existing && existing.version > 0 ? "replaced document" : "uploaded document", input.fileName), ...s.documentActivities],
			auditEvents: [makeAudit(s, {
				action,
				module: "Documents",
				recordId: input.studentId,
				details: `${fromStudent ? "Student uploaded" : "Uploaded"} ${input.fileName}`,
				before: existing?.status,
				after: nextStatus,
				severity: "SUCCESS",
				user: actorName,
				userId: fromStudent ? student.id : s.currentUser?.id,
				role: fromStudent ? "student" : s.currentUser?.role
			}), ...s.auditEvents],
			notifications: fromStudent ? [notice(`${student.name} uploaded ${input.fileName}`, "A student upload is waiting for review.", workspaceHref(s, student.id)), ...s.notifications] : s.notifications
		}));
		return {
			ok: true,
			document: next
		};
	},
	verifyDocument: (id) => set((s) => {
		const doc = s.documents.find((d) => d.id === id);
		if (!doc) return s;
		const actor = s.currentUser?.name ?? "Staff";
		return {
			documents: s.documents.map((d) => d.id === id ? {
				...d,
				status: "verified",
				rejectReason: void 0,
				rejectNote: void 0,
				replacementRequested: false,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : d),
			documentActivities: [activity(id, doc.studentId, actor, s.currentUser?.role ?? "employee", "verified document"), ...s.documentActivities],
			auditEvents: [makeAudit(s, {
				action: "DOCUMENT_VERIFIED",
				module: "Documents",
				recordId: doc.studentId,
				details: `Verified ${doc.type}`,
				before: doc.status,
				after: "verified",
				severity: "SUCCESS"
			}), ...s.auditEvents]
		};
	}),
	rejectDocument: (id, reason, note) => set((s) => {
		const doc = s.documents.find((d) => d.id === id);
		if (!doc) return s;
		const actor = s.currentUser?.name ?? "Staff";
		const student = s.students.find((st) => st.id === doc.studentId);
		return {
			documents: s.documents.map((d) => d.id === id ? {
				...d,
				status: "rejected",
				rejectReason: reason,
				rejectNote: note,
				replacementRequested: true,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : d),
			documentActivities: [activity(id, doc.studentId, actor, s.currentUser?.role ?? "employee", "rejected document", reason), ...s.documentActivities],
			auditEvents: [makeAudit(s, {
				action: "DOCUMENT_REJECTED",
				module: "Documents",
				recordId: doc.studentId,
				details: `Rejected ${doc.type}: ${reason}`,
				before: doc.status,
				after: "rejected",
				severity: "WARNING"
			}), ...s.auditEvents],
			notifications: [notice(`Document rejected by ${actor}`, `${doc.type} for ${student?.name ?? doc.studentId} was rejected.`, workspaceHref(s, doc.studentId)), ...s.notifications]
		};
	}),
	requestReplacement: (id, reason, message, dueDate) => set((s) => {
		const doc = s.documents.find((d) => d.id === id);
		if (!doc) return s;
		const actor = s.currentUser?.name ?? "Staff";
		return {
			documents: s.documents.map((d) => d.id === id ? {
				...d,
				replacementRequested: true,
				replacementMessage: message,
				studentInstruction: message,
				rejectReason: d.rejectReason ?? reason,
				dueDate: dueDate ?? d.dueDate,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : d),
			documentActivities: [activity(id, doc.studentId, actor, s.currentUser?.role ?? "employee", "requested replacement", reason), ...s.documentActivities],
			auditEvents: [makeAudit(s, {
				action: "DOCUMENT_REQUESTED",
				module: "Documents",
				recordId: doc.studentId,
				details: `Requested replacement for ${doc.type}`,
				severity: "WARNING"
			}), ...s.auditEvents]
		};
	}),
	requestDocument: (input) => {
		const student = get().students.find((st) => st.id === input.studentId);
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const created = {
			id: uid("DOC"),
			studentId: input.studentId,
			name: `${input.type} — ${student?.name ?? input.studentId}`,
			type: input.type,
			category: input.universityName ? "University" : categoryForType(input.type),
			status: "pending",
			required: input.required,
			priority: input.priority ?? (input.required ? "high" : "optional"),
			version: 0,
			updatedAt: now,
			dueDate: input.dueDate,
			studentInstruction: input.studentInstruction,
			universityId: input.universityId,
			universityName: input.universityName,
			course: input.course
		};
		set((s) => ({
			documents: [created, ...s.documents],
			documentActivities: [activity(created.id, input.studentId, s.currentUser?.name ?? "Staff", s.currentUser?.role ?? "employee", "requested document", input.type), ...s.documentActivities],
			auditEvents: [makeAudit(s, {
				action: "DOCUMENT_REQUESTED",
				module: "Documents",
				recordId: input.studentId,
				details: `Requested ${input.type}`,
				after: "pending",
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return created;
	},
	updateDocumentMeta: (id, patch) => set((s) => ({ documents: s.documents.map((d) => d.id === id ? {
		...d,
		...patch,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	} : d) })),
	deleteDocuments: (ids) => set((s) => {
		const setIds = new Set(ids);
		ids.forEach(removeFileData);
		const first = s.documents.find((d) => setIds.has(d.id));
		return {
			documents: s.documents.filter((d) => !setIds.has(d.id)),
			documentVersions: s.documentVersions.filter((v) => !setIds.has(v.documentId)),
			documentActivities: s.documentActivities.filter((a) => !setIds.has(a.documentId)),
			auditEvents: first ? [makeAudit(s, {
				action: "DOCUMENT_DELETED",
				module: "Documents",
				recordId: first.studentId,
				details: `Deleted ${ids.length} document${ids.length === 1 ? "" : "s"}`,
				severity: "CRITICAL"
			}), ...s.auditEvents] : s.auditEvents
		};
	}),
	recordDocumentView: (id) => {
		const doc = get().documents.find((d) => d.id === id);
		if (!doc) return;
		set((s) => ({ auditEvents: [makeAudit(s, {
			action: "DOCUMENT_VIEWED",
			module: "Documents",
			recordId: doc.studentId,
			details: `Viewed ${doc.fileName ?? doc.type}`,
			severity: "INFO"
		}), ...s.auditEvents] }));
	},
	recordDocumentDownload: (id) => {
		const doc = get().documents.find((d) => d.id === id);
		if (!doc) return;
		set((s) => ({ auditEvents: [makeAudit(s, {
			action: "DOCUMENT_DOWNLOADED",
			module: "Documents",
			recordId: doc.studentId,
			details: `Downloaded ${doc.fileName ?? doc.type}`,
			severity: "INFO"
		}), ...s.auditEvents] }));
	},
	seedStudentDocuments: (studentId) => {
		const s = get();
		const student = s.students.find((st) => st.id === studentId);
		if (!student) return;
		if (s.documents.some((d) => d.studentId === studentId)) return;
		set({ documents: [...buildRequirementDocs(student, extrasForStudent(s, studentId)).map((d) => ({
			...d,
			id: uid("DOC")
		})), ...s.documents] });
	},
	createPortal: (input) => {
		const student = get().students.find((st) => st.id === input.studentId);
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const portal = {
			id: uid("PRT"),
			studentId: input.studentId,
			accessMethod: input.accessMethod,
			email: input.email ?? student?.email,
			token: generatePortalToken(),
			status: "active",
			expiresAt: input.expiresAt,
			permissions: input.permissions ?? { ...DEFAULT_PORTAL_PERMISSIONS },
			createdAt: now
		};
		set((s) => ({
			portals: [portal, ...s.portals.map((p) => p.studentId === input.studentId && p.status === "active" ? {
				...p,
				status: "revoked"
			} : p)],
			auditEvents: [makeAudit(s, {
				action: "PORTAL_CREATED",
				module: "Documents",
				recordId: input.studentId,
				details: `Created student upload portal`,
				after: input.accessMethod,
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return portal;
	},
	updatePortal: (id, patch) => set((s) => ({ portals: s.portals.map((p) => p.id === id ? {
		...p,
		...patch
	} : p) })),
	revokePortal: (id) => set((s) => {
		const portal = s.portals.find((p) => p.id === id);
		return {
			portals: s.portals.map((p) => p.id === id ? {
				...p,
				status: "revoked"
			} : p),
			auditEvents: portal ? [makeAudit(s, {
				action: "PORTAL_REVOKED",
				module: "Documents",
				recordId: portal.studentId,
				details: "Revoked student upload portal",
				before: "active",
				after: "revoked",
				severity: "WARNING"
			}), ...s.auditEvents] : s.auditEvents
		};
	}),
	regeneratePortal: (id) => {
		const current = get().portals.find((p) => p.id === id);
		if (!current) return null;
		const next = {
			...current,
			id: uid("PRT"),
			token: generatePortalToken(),
			status: "active",
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			lastAccessedAt: void 0
		};
		set((s) => ({
			portals: [next, ...s.portals.map((p) => p.id === id ? {
				...p,
				status: "revoked"
			} : p)],
			auditEvents: [makeAudit(s, {
				action: "PORTAL_REGENERATED",
				module: "Documents",
				recordId: current.studentId,
				details: "Regenerated student upload portal",
				severity: "SUCCESS"
			}), ...s.auditEvents]
		}));
		return next;
	},
	logPortalAccess: (portalId, action, actor) => set((s) => {
		const portal = s.portals.find((p) => p.id === portalId);
		if (!portal) return s;
		const student = s.students.find((st) => st.id === portal.studentId);
		const log = {
			id: uid("PAL"),
			portalId,
			studentId: portal.studentId,
			actor: actor ?? student?.name ?? "Student",
			action,
			timestamp: (/* @__PURE__ */ new Date()).toISOString()
		};
		return {
			portalAccessLogs: [log, ...s.portalAccessLogs],
			portals: s.portals.map((p) => p.id === portalId ? {
				...p,
				lastAccessedAt: log.timestamp
			} : p)
		};
	}),
	touchPortalAccess: (token) => set((s) => {
		const portal = s.portals.find((p) => p.token === token);
		if (!portal) return s;
		const student = s.students.find((st) => st.id === portal.studentId);
		return {
			portals: s.portals.map((p) => p.token === token ? {
				...p,
				lastAccessedAt: (/* @__PURE__ */ new Date()).toISOString()
			} : p),
			portalAccessLogs: [{
				id: uid("PAL"),
				portalId: portal.id,
				studentId: portal.studentId,
				actor: student?.name ?? "Student",
				action: "accessed portal",
				timestamp: (/* @__PURE__ */ new Date()).toISOString()
			}, ...s.portalAccessLogs],
			auditEvents: [makeAudit(s, {
				action: "PORTAL_ACCESSED",
				module: "Documents",
				recordId: portal.studentId,
				details: `${student?.name ?? "Student"} accessed portal`,
				user: student?.name,
				userId: student?.id,
				role: "student",
				severity: "INFO"
			}), ...s.auditEvents]
		};
	}),
	updateWorkItem: (id, patch) => set((s) => ({ workItems: s.workItems.map((w) => w.id === id ? {
		...w,
		...patch
	} : w) })),
	updateSettings: (patch) => set((s) => ({
		settings: {
			...s.settings,
			...patch
		},
		auditEvents: [makeAudit(s, {
			action: "UPDATE",
			module: "Settings",
			recordId: "ORG",
			details: "Updated organization settings",
			severity: "WARNING"
		}), ...s.auditEvents]
	})),
	resetDemo: () => {
		const fresh = createSeed();
		const user = get().currentUser;
		set({
			...fresh,
			shortlists: [],
			currentUser: user ? fresh.employees.find((e) => e.email === user.email) ?? user : null,
			theme: get().theme
		});
	}
}), {
	name: "meridian-docs-v2",
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: () => null,
		setItem: () => void 0,
		removeItem: () => void 0
	} : localStorage),
	skipHydration: true,
	partialize: (s) => ({
		currentUser: s.currentUser,
		theme: s.theme,
		sidebarCollapsed: s.sidebarCollapsed,
		students: s.students,
		employees: s.employees,
		universities: s.universities,
		applications: s.applications,
		payments: s.payments,
		leads: s.leads,
		documents: s.documents,
		documentVersions: s.documentVersions,
		documentActivities: s.documentActivities,
		portals: s.portals,
		portalAccessLogs: s.portalAccessLogs,
		workItems: s.workItems,
		shortlists: s.shortlists,
		auditEvents: s.auditEvents,
		notifications: s.notifications,
		settings: s.settings
	}),
	onRehydrateStorage: () => (state) => {
		if (state) state.setHydrated(true);
		else useAppStore.setState({ hydrated: true });
	}
}));
function applyTheme(theme) {
	const dark = theme === "dark" || theme !== "light" && window.matchMedia("(prefers-color-scheme: dark)").matches;
	document.documentElement.classList.toggle("dark", dark);
}
function ThemeSync() {
	const theme = useAppStore((s) => s.theme);
	(0, import_react.useEffect)(() => {
		applyTheme(theme);
		const mq = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => applyTheme(theme);
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, [theme]);
	return null;
}
function StoreHydration() {
	(0, import_react.useEffect)(() => {
		useAppStore.persist.rehydrate();
		const t = window.setTimeout(() => {
			if (!useAppStore.getState().hydrated) useAppStore.getState().setHydrated(true);
		}, 800);
		return () => window.clearTimeout(t);
	}, []);
	return null;
}
var styles_default = "/assets/styles-C90FyaBK.css";
var APP_NAME = "Meridian";
var Route$33 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#2563EB"
			},
			{
				name: "description",
				content: "Meridian — student operations, applications, and payments in one workspace."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: RootComponent,
	errorComponent: AppErrorComponent,
	notFoundComponent: NotFound
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreHydration, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSync, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "bottom-right",
				closeButton: true,
				richColors: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-2 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted-foreground",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-semibold",
				children: "Page not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "This route doesn't exist in Meridian."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/",
				className: "mt-3 text-sm font-medium text-primary",
				children: "Back to workspace"
			})
		]
	});
}
var $$splitComponentImporter$30 = () => import("./routes-CaD8jHUD.mjs");
var Route$32 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$30, "component") });
var $$splitComponentImporter$29 = () => import("./admin-DsZNCGr1.mjs");
var Route$31 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$29, "component") });
var $$splitComponentImporter$28 = () => import("./employee-BatQ7GXx.mjs");
var Route$30 = createFileRoute("/employee")({ component: lazyRouteComponent($$splitComponentImporter$28, "component") });
var $$splitComponentImporter$27 = () => import("./login-CBItQrAY.mjs");
var Route$29 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$27, "component") });
var Route$28 = createFileRoute("/admin/")({ beforeLoad: () => {
	throw redirect({ to: "/admin/dashboard" });
} });
var $$splitComponentImporter$26 = () => import("./applications-QDl_3tmW.mjs");
var Route$27 = createFileRoute("/admin/applications")({ component: lazyRouteComponent($$splitComponentImporter$26, "component") });
var $$splitComponentImporter$25 = () => import("./audit-DCDv6RgJ.mjs");
var Route$26 = createFileRoute("/admin/audit")({ component: lazyRouteComponent($$splitComponentImporter$25, "component") });
var $$splitComponentImporter$24 = () => import("./dashboard-Brjx6V5K.mjs");
var Route$25 = createFileRoute("/admin/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$24, "component") });
var $$splitComponentImporter$23 = () => import("./documents-BlMIv4rQ.mjs");
var Route$24 = createFileRoute("/admin/documents")({ component: lazyRouteComponent($$splitComponentImporter$23, "component") });
var $$splitComponentImporter$22 = () => import("./leads-_tF3IDxT.mjs");
var Route$23 = createFileRoute("/admin/leads")({ component: lazyRouteComponent($$splitComponentImporter$22, "component") });
var $$splitComponentImporter$21 = () => import("./payments-_FkIgEPH.mjs");
var Route$22 = createFileRoute("/admin/payments")({ component: lazyRouteComponent($$splitComponentImporter$21, "component") });
var $$splitComponentImporter$20 = () => import("./reports-c0TW2LAn.mjs");
var Route$21 = createFileRoute("/admin/reports")({ component: lazyRouteComponent($$splitComponentImporter$20, "component") });
var $$splitComponentImporter$19 = () => import("./settings-D8LLYrGW.mjs");
var Route$20 = createFileRoute("/admin/settings")({ component: lazyRouteComponent($$splitComponentImporter$19, "component") });
var $$splitComponentImporter$18 = () => import("./universities-BGJOkO4Q.mjs");
var Route$19 = createFileRoute("/admin/universities")({ component: lazyRouteComponent($$splitComponentImporter$18, "component") });
var Route$18 = createFileRoute("/employee/")({ beforeLoad: () => {
	throw redirect({ to: "/employee/dashboard" });
} });
var $$splitComponentImporter$17 = () => import("./applications-DyaKDSlE.mjs");
var Route$17 = createFileRoute("/employee/applications")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("./dashboard-DXGmzeMy.mjs");
var Route$16 = createFileRoute("/employee/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./documents-BFnvLCyv.mjs");
var Route$15 = createFileRoute("/employee/documents")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./leads-Cncfaqzf.mjs");
var Route$14 = createFileRoute("/employee/leads")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./payments-DHG3cQZH.mjs");
var Route$13 = createFileRoute("/employee/payments")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./profile-rrEBiTZz.mjs");
var Route$12 = createFileRoute("/employee/profile")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./universities-xfMjIhzq.mjs");
var Route$11 = createFileRoute("/employee/universities")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./student-upload._token-BisRLmu6.mjs");
var Route$10 = createFileRoute("/student-upload/$token")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./employees-Ch7l0BUL.mjs");
var Route$9 = createFileRoute("/admin/employees/")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("../_id-C4djis_Q.mjs");
var Route$8 = createFileRoute("/admin/employees/$id")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./students-DIvPiDXu.mjs");
var Route$7 = createFileRoute("/admin/students/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("../_id-kZAN3eNX.mjs");
var Route$6 = createFileRoute("/admin/students/$id")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./new-BzuRCO2U.mjs");
var Route$5 = createFileRoute("/admin/students/new")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./students-gLmKA9Z2.mjs");
var Route$4 = createFileRoute("/employee/students/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("../_id-BkkC6gn5.mjs");
var Route$3 = createFileRoute("/employee/students/$id")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./new-DS1H3Mdb.mjs");
var Route$2 = createFileRoute("/employee/students/new")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("../_id.edit-CbfTOr87.mjs");
var Route$1 = createFileRoute("/admin/students/$id/edit")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("../_id.edit-BKSfjtAL.mjs");
var Route = createFileRoute("/employee/students/$id/edit")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$32.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$33
});
var AdminRoute = Route$31.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$33
});
var EmployeeRoute = Route$30.update({
	id: "/employee",
	path: "/employee",
	getParentRoute: () => Route$33
});
var LoginRoute = Route$29.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$33
});
var AdminIndexRoute = Route$28.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminApplicationsRoute = Route$27.update({
	id: "/applications",
	path: "/applications",
	getParentRoute: () => AdminRoute
});
var AdminAuditRoute = Route$26.update({
	id: "/audit",
	path: "/audit",
	getParentRoute: () => AdminRoute
});
var AdminDashboardRoute = Route$25.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AdminRoute
});
var AdminDocumentsRoute = Route$24.update({
	id: "/documents",
	path: "/documents",
	getParentRoute: () => AdminRoute
});
var AdminLeadsRoute = Route$23.update({
	id: "/leads",
	path: "/leads",
	getParentRoute: () => AdminRoute
});
var AdminPaymentsRoute = Route$22.update({
	id: "/payments",
	path: "/payments",
	getParentRoute: () => AdminRoute
});
var AdminReportsRoute = Route$21.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AdminRoute
});
var AdminSettingsRoute = Route$20.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AdminRoute
});
var AdminUniversitiesRoute = Route$19.update({
	id: "/universities",
	path: "/universities",
	getParentRoute: () => AdminRoute
});
var EmployeeIndexRoute = Route$18.update({
	id: "/",
	path: "/",
	getParentRoute: () => EmployeeRoute
});
var EmployeeApplicationsRoute = Route$17.update({
	id: "/applications",
	path: "/applications",
	getParentRoute: () => EmployeeRoute
});
var EmployeeDashboardRoute = Route$16.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => EmployeeRoute
});
var EmployeeDocumentsRoute = Route$15.update({
	id: "/documents",
	path: "/documents",
	getParentRoute: () => EmployeeRoute
});
var EmployeeLeadsRoute = Route$14.update({
	id: "/leads",
	path: "/leads",
	getParentRoute: () => EmployeeRoute
});
var EmployeePaymentsRoute = Route$13.update({
	id: "/payments",
	path: "/payments",
	getParentRoute: () => EmployeeRoute
});
var EmployeeProfileRoute = Route$12.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => EmployeeRoute
});
var EmployeeUniversitiesRoute = Route$11.update({
	id: "/universities",
	path: "/universities",
	getParentRoute: () => EmployeeRoute
});
var StudentUploadTokenRoute = Route$10.update({
	id: "/student-upload/$token",
	path: "/student-upload/$token",
	getParentRoute: () => Route$33
});
var AdminEmployeesIndexRoute = Route$9.update({
	id: "/employees/",
	path: "/employees/",
	getParentRoute: () => AdminRoute
});
var AdminEmployeesIdRoute = Route$8.update({
	id: "/employees/$id",
	path: "/employees/$id",
	getParentRoute: () => AdminRoute
});
var AdminStudentsIndexRoute = Route$7.update({
	id: "/students/",
	path: "/students/",
	getParentRoute: () => AdminRoute
});
var AdminStudentsIdRoute = Route$6.update({
	id: "/students/$id",
	path: "/students/$id",
	getParentRoute: () => AdminRoute
});
var AdminStudentsNewRoute = Route$5.update({
	id: "/students/new",
	path: "/students/new",
	getParentRoute: () => AdminRoute
});
var EmployeeStudentsIndexRoute = Route$4.update({
	id: "/students/",
	path: "/students/",
	getParentRoute: () => EmployeeRoute
});
var EmployeeStudentsIdRoute = Route$3.update({
	id: "/students/$id",
	path: "/students/$id",
	getParentRoute: () => EmployeeRoute
});
var EmployeeStudentsNewRoute = Route$2.update({
	id: "/students/new",
	path: "/students/new",
	getParentRoute: () => EmployeeRoute
});
var AdminStudentsIdEditRoute = Route$1.update({
	id: "/edit",
	path: "/edit",
	getParentRoute: () => AdminStudentsIdRoute
});
var EmployeeStudentsIdEditRoute = Route.update({
	id: "/edit",
	path: "/edit",
	getParentRoute: () => EmployeeStudentsIdRoute
});
var AdminStudentsIdRouteChildren = { AdminStudentsIdEditRoute };
var AdminRouteChildren = {
	AdminApplicationsRoute,
	AdminAuditRoute,
	AdminDashboardRoute,
	AdminDocumentsRoute,
	AdminLeadsRoute,
	AdminPaymentsRoute,
	AdminReportsRoute,
	AdminSettingsRoute,
	AdminUniversitiesRoute,
	AdminIndexRoute,
	AdminEmployeesIdRoute,
	AdminStudentsIdRoute: AdminStudentsIdRoute._addFileChildren(AdminStudentsIdRouteChildren),
	AdminStudentsNewRoute,
	AdminEmployeesIndexRoute,
	AdminStudentsIndexRoute
};
var AdminRouteWithChildren = AdminRoute._addFileChildren(AdminRouteChildren);
var EmployeeStudentsIdRouteChildren = { EmployeeStudentsIdEditRoute };
var EmployeeRouteChildren = {
	EmployeeApplicationsRoute,
	EmployeeDashboardRoute,
	EmployeeDocumentsRoute,
	EmployeeLeadsRoute,
	EmployeePaymentsRoute,
	EmployeeProfileRoute,
	EmployeeUniversitiesRoute,
	EmployeeIndexRoute,
	EmployeeStudentsIdRoute: EmployeeStudentsIdRoute._addFileChildren(EmployeeStudentsIdRouteChildren),
	EmployeeStudentsNewRoute,
	EmployeeStudentsIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRouteWithChildren,
	EmployeeRoute: EmployeeRoute._addFileChildren(EmployeeRouteChildren),
	LoginRoute,
	StudentUploadTokenRoute
};
var routeTree = Route$33._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { AUDIT_ACTIONS as A, isSubmitted as C, statusLabel as D, relativeShort as E, DOCUMENT_CATEGORIES as M, GERMAN_LEVELS as N, validateUploadFile as O, INTAKES as P, isOverdue as S, portalUrl as T, defaultDocumentName as _, Route$6 as a, formatBytes as b, useAppStore as c, DEFAULT_PORTAL_PERMISSIONS as d, DOCUMENT_TYPE_CATALOG as f, categoryForType as g, canPreview as h, Route$3 as i, BRANCHES as j, APPLICATION_STATUSES as k, getFileData as l, REJECT_REASONS as m, Route as n, Route$8 as o, FILE_RULES as p, Route$1 as r, Route$10 as s, router_exports as t, COUNTRY_DOCUMENT_RULES as u, documentStats as v, portalEffectiveStatus as w, groupedByCategory as x, expiryFromPreset as y };
