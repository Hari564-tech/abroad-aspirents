import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Badge } from "./badge-Caj8QGQQ.mjs";
import { a as severityTone, i as priorityTone, o as statusTone, r as paymentTone, t as TONE_BADGE } from "./status-BbxO-Ia2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-badge-CgLI5ccz.js
var import_jsx_runtime = require_jsx_runtime();
function ToneBadge({ tone, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "outline",
		className: cn("border-0 ring-1", TONE_BADGE[tone] ?? TONE_BADGE.muted, className),
		children
	});
}
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneBadge, {
		tone: statusTone(status),
		children: status
	});
}
function PaymentBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneBadge, {
		tone: paymentTone(status),
		children: status
	});
}
function SeverityBadge({ severity }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneBadge, {
		tone: severityTone(severity),
		children: severity
	});
}
function PriorityBadge({ priority }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneBadge, {
		tone: priorityTone(priority),
		children: priority
	});
}
//#endregion
export { StatusBadge as i, PriorityBadge as n, SeverityBadge as r, PaymentBadge as t };
