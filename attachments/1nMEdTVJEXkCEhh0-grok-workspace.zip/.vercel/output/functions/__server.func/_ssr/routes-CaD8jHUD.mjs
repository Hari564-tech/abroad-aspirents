import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as ShellSkeleton } from "./loading-state-DRw3a4Or.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CaD8jHUD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const hydrated = useAppStore((s) => s.hydrated);
	const user = useAppStore((s) => s.currentUser);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (!user) navigate({
			to: "/login",
			replace: true
		});
		else if (user.role === "admin") navigate({
			to: "/admin/dashboard",
			replace: true
		});
		else navigate({
			to: "/employee/dashboard",
			replace: true
		});
	}, [
		hydrated,
		user,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellSkeleton, {});
}
//#endregion
export { Home as component };
