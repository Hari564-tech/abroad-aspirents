import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate, _ as Outlet, p as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { C as PanelLeft, D as Menu, F as Keyboard, K as CreditCard, L as GraduationCap, P as LayoutDashboard, Q as ChevronUp, R as Files, T as Monitor, Y as CircleHelp, d as Sun, g as Search, h as Settings, i as UserRound, k as LogOut, lt as Activity, p as ShieldCheck, r as Users, rt as Building2, st as Bell, w as Moon, x as Plus, z as FileText } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { a as DropdownMenuSeparator, i as DropdownMenuItem, o as DropdownMenuTrigger, r as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-CuItBiKD.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { o as relativeTime } from "./format-DGBT4Fq1.mjs";
import { n as SheetContent, t as Sheet } from "./sheet-CY9M7c4U.mjs";
import { t as Logo } from "./logo-Db11eYx6.mjs";
import { a as CommandInput, c as CommandSeparator, i as CommandGroup, n as CommandDialog, o as CommandItem, r as CommandEmpty, s as CommandList } from "./command-8gviA0Rt.mjs";
import { a as Viewport, i as ScrollAreaThumb, n as Root, r as ScrollAreaScrollbar, t as Corner } from "../_libs/radix-ui__react-scroll-area.mjs";
import { t as Root$1 } from "../_libs/radix-ui__react-separator.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-IUwtpOi1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Corner, {})
	]
}));
ScrollArea.displayName = Root.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-px", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-px", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root$1.displayName;
function NavItem({ item, collapsed, onClick }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const active = pathname === item.to || pathname.startsWith(item.to + "/");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: item.to,
		onClick,
		className: cn("flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors", collapsed && "justify-center px-0", active ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"),
		"aria-current": active ? "page" : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4 shrink-0" }), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
	});
}
function Sidebar({ collapsed, onNavigate }) {
	const { role, base } = useWorkspace();
	const user = useAppStore((s) => s.currentUser);
	const setTheme = useAppStore((s) => s.setTheme);
	const logout = useAppStore((s) => s.logout);
	const navigate = useNavigate();
	const workspace = [
		{
			to: `${base}/dashboard`,
			label: "Overview",
			icon: LayoutDashboard
		},
		{
			to: `${base}/students`,
			label: "Students",
			icon: GraduationCap
		},
		{
			to: `${base}/documents`,
			label: "Documents",
			icon: Files
		},
		{
			to: `${base}/leads`,
			label: "Leads",
			icon: UserRound
		},
		{
			to: `${base}/applications`,
			label: "Applications",
			icon: FileText
		},
		{
			to: `${base}/payments`,
			label: "Payments",
			icon: CreditCard
		},
		{
			to: `${base}/universities`,
			label: "Universities",
			icon: Building2
		}
	];
	const management = role === "admin" ? [{
		to: "/admin/employees",
		label: "Employees",
		icon: Users
	}, {
		to: "/admin/reports",
		label: "Reports",
		icon: Activity
	}] : [{
		to: `${base}/profile`,
		label: "My profile",
		icon: UserRound
	}];
	const admin = role === "admin" ? [{
		to: "/admin/audit",
		label: "Audit Center",
		icon: ShieldCheck
	}, {
		to: "/admin/settings",
		label: "Settings",
		icon: Settings
	}] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-sidebar text-sidebar-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("flex h-14 items-center px-3", collapsed && "justify-center"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: base + "/dashboard",
					onClick: onNavigate,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { compact: collapsed })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScrollArea, {
				className: "flex-1 px-2 py-3",
				children: [
					!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1.5 px-2 text-micro font-medium uppercase tracking-wider text-muted-foreground",
						children: "Workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "grid gap-0.5",
						children: workspace.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
							item,
							collapsed,
							onClick: onNavigate
						}, item.to))
					}),
					management.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1.5 mt-5 px-2 text-micro font-medium uppercase tracking-wider text-muted-foreground",
						children: role === "admin" ? "Management" : "Account"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-2 grid gap-0.5",
						children: management.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
							item,
							collapsed,
							onClick: onNavigate
						}, item.to))
					})] }),
					admin.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1.5 mt-5 px-2 text-micro font-medium uppercase tracking-wider text-muted-foreground",
						children: "Admin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-2 grid gap-0.5",
						children: admin.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
							item,
							collapsed,
							onClick: onNavigate
						}, item.to))
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: cn("h-auto w-full justify-start gap-2.5 px-2 py-2", collapsed && "justify-center px-0"),
						children: [user && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
							name: user.name,
							hue: user.avatarHue,
							className: "size-8"
						}), !collapsed && user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium",
								children: user.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-micro text-muted-foreground",
								children: user.role === "admin" ? "Administrator" : user.title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4 text-muted-foreground" })] })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
					align: "start",
					side: "top",
					className: "w-56",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							onClick: () => void navigate({ to: role === "admin" ? "/admin/settings" : "/employee/profile" }),
							children: [role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), role === "admin" ? "Settings" : "Profile"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							onClick: () => setTheme("light"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }), " Light"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							onClick: () => setTheme("dark"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" }), " Dark"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							onClick: () => setTheme("system"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, { className: "size-4" }), " System"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							destructive: true,
							onClick: () => {
								logout();
								toast.message("Signed out");
								navigate({ to: "/login" });
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign out"]
						})
					]
				})] })
			})
		]
	});
}
var LABELS = {
	admin: "Admin",
	employee: "Employee",
	dashboard: "Overview",
	students: "Students",
	leads: "Leads",
	applications: "Applications",
	payments: "Payments",
	universities: "Universities",
	employees: "Employees",
	documents: "Documents",
	reports: "Reports",
	audit: "Audit Center",
	settings: "Settings",
	profile: "Profile",
	new: "New"
};
function Topbar({ onMenu, onSearch }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const collapsed = useAppStore((s) => s.sidebarCollapsed);
	const setCollapsed = useAppStore((s) => s.setSidebarCollapsed);
	const user = useAppStore((s) => s.currentUser);
	const notifications = useAppStore((s) => s.notifications);
	const markRead = useAppStore((s) => s.markNotificationRead);
	const markAll = useAppStore((s) => s.markAllNotificationsRead);
	const logout = useAppStore((s) => s.logout);
	const { role, base } = useWorkspace();
	const navigate = useNavigate();
	const crumbs = pathname.split("/").filter(Boolean);
	const unread = notifications.filter((n) => !n.read).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 flex h-14 items-center gap-3 border-b bg-card/90 px-3 backdrop-blur-sm sm:px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "lg:hidden",
				onClick: onMenu,
				"aria-label": "Open menu",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "hidden lg:inline-flex",
				onClick: () => setCollapsed(!collapsed),
				"aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Breadcrumb",
				className: "hidden min-w-0 items-center gap-1.5 text-sm md:flex",
				children: crumbs.map((c, i) => {
					const href = "/" + crumbs.slice(0, i + 1).join("/");
					const last = i === crumbs.length - 1;
					const label = LABELS[c] ?? c.replaceAll("_", " ");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [i > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "/"
						}), last ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-medium",
							children: label
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: href,
							className: "truncate text-muted-foreground hover:text-foreground",
							children: label
						})]
					}, href);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onSearch,
						className: "hidden h-9 items-center gap-2 rounded-md border bg-background px-3 text-sm text-muted-foreground transition-colors hover:bg-secondary md:inline-flex",
						"aria-label": "Search",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-28 text-left",
								children: "Search…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
								className: "rounded border bg-card px-1.5 py-0.5 font-mono text-micro",
								children: "⌘K"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "md:hidden",
						onClick: onSearch,
						"aria-label": "Search",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							size: "icon",
							className: "relative",
							"aria-label": "Notifications",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute right-1.5 top-1.5 flex size-4 items-center justify-center rounded-full bg-primary text-[10px] font-semibold text-primary-foreground",
								children: unread > 9 ? "9+" : unread
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "w-80 p-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between px-3 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: "Notifications"
								}), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-micro font-medium text-primary",
									onClick: () => markAll(),
									children: "Mark all read"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-h-80 overflow-y-auto",
								children: notifications.slice(0, 8).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: cn("flex w-full flex-col items-start gap-0.5 px-3 py-2.5 text-left hover:bg-secondary", !n.read && "bg-accent/40"),
									onClick: () => {
										markRead(n.id);
										navigate({ to: n.href.replace("/admin/", `${base}/`).replace("/employee/", `${base}/`) });
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-medium",
											children: n.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: n.body
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-micro text-muted-foreground",
											children: relativeTime(n.timestamp)
										})
									]
								}, n.id))
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Help",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, { className: "size-4" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "w-64",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-2 py-1.5 text-xs font-medium text-muted-foreground",
								children: "Shortcuts"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								disabled: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-4" }), " Search · ⌘K"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								onClick: () => toast.message("This is a frontend prototype — help docs are simulated."),
								children: "Documentation"
							})
						]
					})] }),
					user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Account",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
								name: user.name,
								hue: user.avatarHue,
								className: "size-7"
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "w-56",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "px-2 py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: user.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: user.email
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onClick: () => void navigate({ to: role === "admin" ? "/admin/settings" : "/employee/profile" }),
								children: [role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), role === "admin" ? "Settings" : "Profile"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								destructive: true,
								onClick: () => {
									logout();
									toast.message("Signed out");
									navigate({ to: "/login" });
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign out"]
							})
						]
					})] })
				]
			})
		]
	});
}
function CommandPalette({ open, onOpenChange }) {
	const navigate = useNavigate();
	const { base, role } = useWorkspace();
	const students = useAppStore((s) => s.students);
	const employees = useAppStore((s) => s.employees);
	const universities = useAppStore((s) => s.universities);
	const applications = useAppStore((s) => s.applications);
	const [q, setQ] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				onOpenChange(!open);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onOpenChange]);
	const query = q.trim().toLowerCase();
	const matchedStudents = (0, import_react.useMemo)(() => students.filter((s) => !query || `${s.name} ${s.id} ${s.country} ${s.status}`.toLowerCase().includes(query)).slice(0, 6), [students, query]);
	const matchedUnis = (0, import_react.useMemo)(() => universities.filter((u) => !query || `${u.name} ${u.course} ${u.country}`.toLowerCase().includes(query)).slice(0, 5), [universities, query]);
	const matchedEmps = (0, import_react.useMemo)(() => role === "admin" ? employees.filter((e) => !query || `${e.name} ${e.email} ${e.department}`.toLowerCase().includes(query)).slice(0, 5) : [], [
		employees,
		query,
		role
	]);
	const matchedApps = (0, import_react.useMemo)(() => applications.filter((a) => !query || `${a.id} ${a.course} ${a.status}`.toLowerCase().includes(query)).slice(0, 5), [applications, query]);
	const go = (to) => {
		onOpenChange(false);
		navigate({ to });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandDialog, {
		open,
		onOpenChange,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
			placeholder: "Search anything…",
			value: q,
			onValueChange: setQ
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No matches. Try a student ID or university." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandGroup, {
				heading: "Actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
						onSelect: () => go(`${base}/dashboard`),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4 text-muted-foreground" }), "Go to overview"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
						onSelect: () => go(`${base}/students/new`),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 text-muted-foreground" }), "Add student"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
						onSelect: () => go(`${base}/documents`),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Files, { className: "size-4 text-muted-foreground" }), "Documents"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
				heading: "Students",
				children: matchedStudents.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: `${s.name} ${s.id}`,
					onSelect: () => go(`${base}/students/${s.id}`),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: s.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-micro text-muted-foreground",
							children: [
								s.id,
								" · ",
								s.country,
								" · ",
								s.status
							]
						})]
					})]
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
				heading: "Universities",
				children: matchedUnis.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: u.name,
					onSelect: () => go(`${base}/universities?u=${u.id}`),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: u.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-micro text-muted-foreground",
							children: [
								u.course,
								" · ",
								u.country
							]
						})]
					})]
				}, u.id))
			}),
			matchedEmps.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
				heading: "Employees",
				children: matchedEmps.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: e.name,
					onSelect: () => go(`/admin/employees/${e.id}`),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium",
						children: e.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-micro text-muted-foreground",
						children: [
							e.title,
							" · ",
							e.department
						]
					})] })]
				}, e.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
				heading: "Applications",
				children: matchedApps.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
					value: a.id,
					onSelect: () => go(`${base}/applications`),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium",
						children: a.id
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-micro text-muted-foreground",
						children: [
							a.course,
							" · ",
							a.status
						]
					})] })
				}, a.id))
			})
		] })]
	});
}
function AppShell() {
	const collapsed = useAppStore((s) => s.sidebarCollapsed);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: cn("sticky top-0 hidden h-dvh shrink-0 border-r border-sidebar-border lg:flex", collapsed ? "w-[68px]" : "w-60"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, { collapsed })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: mobileOpen,
				onOpenChange: setMobileOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					side: "left",
					className: "w-64 max-w-[85vw] p-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
						collapsed: false,
						onNavigate: () => setMobileOpen(false)
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Topbar, {
					onMenu: () => setMobileOpen(true),
					onSearch: () => setSearchOpen(true)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-[1400px] flex-1 px-4 py-5 sm:px-6 lg:px-8 lg:py-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandPalette, {
				open: searchOpen,
				onOpenChange: setSearchOpen
			})
		]
	});
}
//#endregion
export { AppShell as t };
