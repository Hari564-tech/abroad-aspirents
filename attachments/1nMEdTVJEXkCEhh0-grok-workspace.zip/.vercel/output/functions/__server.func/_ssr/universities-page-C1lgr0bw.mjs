import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as LoaderCircle, E as Minus, G as Download, L as GraduationCap, W as Ellipsis, X as CircleAlert, Z as ChevronsUpDown, at as BookmarkPlus, b as Printer, ct as Archive, it as Bookmark, j as ListChecks, nt as Check, ot as BookmarkCheck, q as Copy, t as X, x as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { P as INTAKES, c as useAppStore, j as BRANCHES } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { i as DropdownMenuItem, o as DropdownMenuTrigger, r as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-CuItBiKD.mjs";
import { a as formatShortDate, r as formatINR, s as toCsv, t as downloadText } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as Badge } from "./badge-Caj8QGQQ.mjs";
import { r as useScopedIds } from "./scoped-BYNid1DS.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-B8yEom4G.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, r as SheetDescription, t as Sheet } from "./sheet-CY9M7c4U.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as Switch } from "./switch-95CbCe8f.mjs";
import { t as FormField } from "./form-field-LURrrOeP.mjs";
import { t as Textarea } from "./textarea-CMcQQGlC.mjs";
import { a as CommandInput, i as CommandGroup, o as CommandItem, r as CommandEmpty, s as CommandList, t as Command$1 } from "./command-8gviA0Rt.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
import { t as FilterSelect } from "./filter-select-DRpDDDny.mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/radix-ui__react-popover.mjs";
import { a as Trigger$1, i as Root3, n as Portal$1, r as Provider, t as Content2$1 } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/universities-page-C1lgr0bw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Popover = Root2;
var PopoverTrigger = Trigger;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-lg bg-popover p-3 text-popover-foreground shadow-popover outline-none", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}) }));
PopoverContent.displayName = Content2.displayName;
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger$1;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-foreground px-2 py-1 text-xs text-background shadow-sm", "animate-in fade-in-0 zoom-in-95", className),
	...props
}) }));
TooltipContent.displayName = Content2$1.displayName;
var LANG_RANK = {
	None: 0,
	A1: 1,
	A2: 2,
	B1: 3,
	B2: 4,
	C1: 5,
	C2: 6
};
var RELATED_BRANCHES = {
	"Computer Science": ["Data Science"],
	"Data Science": ["Computer Science"],
	"Electrical Engineering": ["Electronics & Communication"],
	"Electronics & Communication": ["Electrical Engineering"],
	"Business Administration": ["Finance"],
	Finance: ["Business Administration"]
};
function langRank(level) {
	if (!level) return 0;
	return LANG_RANK[level] ?? 0;
}
function langLabel(level) {
	if (!level || level === "None") return "Not required";
	return level;
}
function cgpaToGermanGrade(cgpa, scale = 10) {
	const nmin = 4;
	const nmax = scale;
	return Number((1 + 3 * (nmax - Math.min(nmax, Math.max(nmin, cgpa))) / (nmax - nmin)).toFixed(1));
}
function studentGermanGrade(student) {
	if (typeof student.germanGrade === "number") return student.germanGrade;
	return cgpaToGermanGrade(student.cgpa);
}
function greFloor(value) {
	const normalized = value.toLowerCase();
	if (normalized.includes("not required") || normalized.includes("optional")) return null;
	const m = value.match(/(\d{3})/);
	return m ? Number(m[1]) : null;
}
function formatEnglishProfile(student) {
	const parts = [];
	if (typeof student.ielts === "number") parts.push(`IELTS ${student.ielts}`);
	if (typeof student.toefl === "number") parts.push(`TOEFL ${student.toefl}`);
	if (typeof student.duolingo === "number") parts.push(`Duolingo ${student.duolingo}`);
	return parts.join(" · ") || "Not submitted";
}
function check(partial) {
	return {
		hard: false,
		...partial
	};
}
function matchStudentToUniversity(student, university) {
	const checks = [];
	const reasons = [];
	const gaps = [];
	const nextSteps = [];
	let score = 0;
	const countryOk = student.country === university.country;
	checks.push(check({
		id: "country",
		label: "Destination",
		required: university.country,
		actual: student.country,
		status: countryOk ? "met" : "missing",
		detail: countryOk ? `Applying to ${university.country}, matching this programme.` : `Student is targeting ${student.country}; this university is in ${university.country}.`,
		hard: true
	}));
	if (countryOk) {
		score += 22;
		reasons.push(`Destination matches (${university.country}).`);
	} else gaps.push(`Country mismatch — student is targeting ${student.country}.`);
	const branchExact = student.branch === university.branch;
	const branchRelated = RELATED_BRANCHES[student.branch]?.includes(university.branch) ?? false;
	checks.push(check({
		id: "branch",
		label: "Field of study",
		required: university.branch,
		actual: student.branch,
		status: branchExact ? "met" : branchRelated ? "close" : "missing",
		detail: branchExact ? "Programme is in the student's declared branch." : branchRelated ? `${university.branch} is closely related to ${student.branch}.` : `Student's branch is ${student.branch}.`,
		hard: !branchRelated
	}));
	if (branchExact) {
		score += 16;
		reasons.push(`Branch aligned (${student.branch}).`);
	} else if (branchRelated) {
		score += 9;
		reasons.push(`Related field: ${university.branch} ↔ ${student.branch}.`);
		nextSteps.push(`Confirm the student is comfortable shifting from ${student.branch} to ${university.branch}.`);
	} else gaps.push(`Field mismatch — ${student.branch} vs ${university.branch}.`);
	const intakeOk = student.intake === university.intake;
	checks.push(check({
		id: "intake",
		label: "Intake",
		required: university.intake,
		actual: student.intake,
		status: intakeOk ? "met" : "close",
		detail: intakeOk ? "Intake matches the student's plan." : `Student is targeting ${student.intake}; this course opens ${university.intake}.`
	}));
	if (intakeOk) {
		score += 6;
		reasons.push(`Intake ${university.intake} matches.`);
	} else {
		score += 3;
		nextSteps.push(`Discuss moving the student to ${university.intake} if this programme is a priority.`);
	}
	const ieltsOk = typeof student.ielts === "number" && student.ielts >= university.ielts;
	const ieltsClose = typeof student.ielts === "number" && student.ielts >= university.ielts - .5 && student.ielts < university.ielts;
	const toeflOk = typeof student.toefl === "number" && student.toefl >= university.toefl;
	const toeflClose = typeof student.toefl === "number" && student.toefl >= university.toefl - 7 && student.toefl < university.toefl;
	const duolingoClose = university.country === "USA" && typeof student.duolingo === "number" && student.duolingo >= 120;
	const englishTestOk = ieltsOk || toeflOk;
	const englishClose = !englishTestOk && (ieltsClose || toeflClose || duolingoClose);
	const moiCovers = university.moi && !englishTestOk;
	let englishStatus = "missing";
	let englishDetail = "No recognised English score on file.";
	if (englishTestOk) {
		englishStatus = "met";
		englishDetail = ieltsOk ? `IELTS ${student.ielts} meets the ${university.ielts} minimum.` : `TOEFL ${student.toefl} meets the ${university.toefl} minimum.`;
		score += 20;
		reasons.push(englishDetail);
	} else if (moiCovers) {
		englishStatus = "met";
		englishDetail = "University accepts Medium of Instruction (MOI) in place of IELTS/TOEFL.";
		score += 15;
		reasons.push("MOI accepted — English test can be waived.");
		nextSteps.push("Collect an official MOI letter from the student's college.");
	} else if (englishClose) {
		englishStatus = "close";
		englishDetail = ieltsClose ? `IELTS ${student.ielts} is 0.5 below the ${university.ielts} cut-off.` : toeflClose ? `TOEFL ${student.toefl} is just below the ${university.toefl} cut-off.` : `Duolingo ${student.duolingo} may be considered; confirm if this university accepts it.`;
		score += 10;
		gaps.push(englishDetail);
		nextSteps.push(ieltsClose || toeflClose ? "Plan a re-test, or shortlist MOI-friendly universities as backup." : "Confirm Duolingo acceptance with the admissions office.");
	} else {
		englishDetail = `Requires IELTS ${university.ielts} or TOEFL ${university.toefl}. Student has ${formatEnglishProfile(student)}.`;
		gaps.push("English score does not meet the published requirement.");
		nextSteps.push(university.moi ? "Submit MOI, or book IELTS/TOEFL." : `Book IELTS (target ${university.ielts}+) or TOEFL (target ${university.toefl}+).`);
	}
	checks.push(check({
		id: "english",
		label: "English proficiency",
		required: `IELTS ${university.ielts} / TOEFL ${university.toefl}${university.moi ? " / MOI" : ""}`,
		actual: formatEnglishProfile(student),
		status: englishStatus,
		detail: englishDetail,
		hard: true
	}));
	const studentGrade = studentGermanGrade(student);
	const gradeDelta = studentGrade - university.germanGrade;
	let gradeStatus = "missing";
	let gradeDetail = "";
	if (studentGrade <= university.germanGrade) {
		gradeStatus = "met";
		gradeDetail = `Academic grade ${studentGrade.toFixed(1)} is within the ${university.germanGrade.toFixed(1)} cap.`;
		score += 18;
		reasons.push(gradeDetail);
	} else if (gradeDelta <= .3) {
		gradeStatus = "close";
		gradeDetail = `Grade ${studentGrade.toFixed(1)} is slightly above the ${university.germanGrade.toFixed(1)} cap.`;
		score += 10;
		gaps.push(gradeDetail);
		nextSteps.push("Check if a grade conversion letter or subject-wise evaluation can improve the German grade.");
	} else {
		gradeStatus = "missing";
		gradeDetail = `Grade ${studentGrade.toFixed(1)} is above the ${university.germanGrade.toFixed(1)} maximum.`;
		gaps.push(gradeDetail);
		nextSteps.push("Prioritise universities with a more flexible grade cap.");
	}
	checks.push(check({
		id: "grade",
		label: "Academic grade",
		required: `≤ ${university.germanGrade.toFixed(1)} (German scale)`,
		actual: `${studentGrade.toFixed(1)} · CGPA ${student.cgpa.toFixed(2)}`,
		status: gradeStatus,
		detail: gradeDetail,
		hard: true
	}));
	if (university.country === "Germany" && university.germanLanguage !== "None") {
		const have = langRank(student.germanLanguage);
		const need = langRank(university.germanLanguage);
		const langOk = have >= need;
		const langClose = !langOk && have === need - 1;
		checks.push(check({
			id: "german",
			label: "German language",
			required: langLabel(university.germanLanguage),
			actual: student.germanLanguage === "None" ? "None" : student.germanLanguage,
			status: langOk ? "met" : langClose ? "close" : "missing",
			detail: langOk ? `${student.germanLanguage} meets the ${university.germanLanguage} requirement.` : langClose ? `${student.germanLanguage || "None"} is one level below ${university.germanLanguage}.` : `Requires ${university.germanLanguage}; student is at ${student.germanLanguage || "None"}.`,
			hard: !langClose
		}));
		if (langOk) {
			score += 12;
			reasons.push(`German ${student.germanLanguage} meets ${university.germanLanguage}.`);
		} else if (langClose) {
			score += 6;
			gaps.push(`German language is one level short of ${university.germanLanguage}.`);
			nextSteps.push(`Enrol the student in ${university.germanLanguage} and target completion before the visa stage.`);
		} else {
			gaps.push(`German language gap: needs ${university.germanLanguage}.`);
			nextSteps.push(`Start ${university.germanLanguage} classes immediately.`);
		}
	} else {
		checks.push(check({
			id: "german",
			label: "German language",
			required: "Not required",
			actual: student.germanLanguage === "None" ? "Not studying German" : student.germanLanguage,
			status: "na",
			detail: "This programme is taught without a German-language minimum."
		}));
		score += 12;
	}
	const greNeed = greFloor(university.gre);
	if (greNeed == null) {
		checks.push(check({
			id: "gre",
			label: "GRE",
			required: university.gre,
			actual: student.gre ? String(student.gre) : "Not taken",
			status: "na",
			detail: "GRE is not a hard requirement for this programme."
		}));
		score += 6;
	} else if (typeof student.gre === "number" && student.gre >= greNeed) {
		checks.push(check({
			id: "gre",
			label: "GRE",
			required: university.gre,
			actual: String(student.gre),
			status: "met",
			detail: `GRE ${student.gre} meets ${university.gre}.`
		}));
		score += 6;
		reasons.push(`GRE ${student.gre} meets the ${greNeed}+ bar.`);
	} else if (typeof student.gre === "number" && student.gre >= greNeed - 8) {
		checks.push(check({
			id: "gre",
			label: "GRE",
			required: university.gre,
			actual: String(student.gre),
			status: "close",
			detail: `GRE ${student.gre} is just under ${greNeed}.`
		}));
		score += 3;
		gaps.push(`GRE is slightly below ${greNeed}.`);
	} else {
		checks.push(check({
			id: "gre",
			label: "GRE",
			required: university.gre,
			actual: student.gre ? String(student.gre) : "Not taken",
			status: "missing",
			detail: `Programme lists ${university.gre}.`,
			hard: true
		}));
		gaps.push(`GRE ${university.gre} is not yet met.`);
		nextSteps.push("Schedule GRE, or move this university to a stretch list.");
	}
	const deadline = new Date(university.deadline).getTime();
	const daysLeft = Math.ceil((deadline - Date.now()) / 864e5);
	if (daysLeft < 0) {
		checks.push(check({
			id: "deadline",
			label: "Deadline",
			required: "Open",
			actual: "Closed",
			status: "missing",
			detail: "The published deadline has passed.",
			hard: true
		}));
		gaps.push("Application deadline has passed.");
		score -= 8;
	} else if (daysLeft <= 21) {
		checks.push(check({
			id: "deadline",
			label: "Deadline",
			required: "Open",
			actual: `${daysLeft} days left`,
			status: "close",
			detail: "Deadline is within three weeks — documents must move immediately."
		}));
		nextSteps.push("Deadline is close — lock documents and application portal access this week.");
	} else checks.push(check({
		id: "deadline",
		label: "Deadline",
		required: "Open",
		actual: `${daysLeft} days left`,
		status: "met",
		detail: "Enough time remains to file a complete application."
	}));
	if (university.moi && englishTestOk) reasons.push("MOI is also accepted, which keeps a fallback if a re-test is needed.");
	score = Math.max(0, Math.min(100, Math.round(score)));
	const hardFails = checks.filter((c) => c.hard && c.status === "missing").length;
	let verdict;
	if (!countryOk || hardFails >= 3) verdict = "ineligible";
	else if (hardFails === 0 && score >= 78) verdict = "eligible";
	else if (hardFails <= 1 && score >= 52) verdict = "close";
	else verdict = "ineligible";
	if (verdict === "eligible" && nextSteps.length === 0) nextSteps.push("Ready to shortlist — confirm documents and portal credentials.");
	return {
		universityId: university.id,
		score,
		verdict,
		checks,
		reasons,
		gaps,
		nextSteps: [...new Set(nextSteps)]
	};
}
function matchAllUniversities(student, universities) {
	return universities.filter((u) => !u.archived).map((u) => matchStudentToUniversity(student, u)).sort((a, b) => b.score - a.score || a.universityId.localeCompare(b.universityId));
}
function summarizeMatches(matches) {
	let eligible = 0;
	let close = 0;
	let ineligible = 0;
	for (const m of matches) if (m.verdict === "eligible") eligible += 1;
	else if (m.verdict === "close") close += 1;
	else ineligible += 1;
	return {
		eligible,
		close,
		ineligible,
		total: matches.length
	};
}
function suggestedShortlist(matches, limit = 5) {
	const eligible = matches.filter((m) => m.verdict === "eligible");
	const close = matches.filter((m) => m.verdict === "close");
	return [...eligible, ...close].slice(0, limit).map((m) => m.universityId);
}
function verdictLabel(verdict) {
	if (verdict === "eligible") return "Eligible";
	if (verdict === "close") return "Close match";
	return "Not eligible";
}
function StudentPicker({ students, value, onChange, disabled }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const selected = students.find((s) => s.id === value) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				role: "combobox",
				"aria-expanded": open,
				disabled,
				className: "h-10 min-w-0 flex-1 justify-between px-3 font-normal sm:min-w-72",
				children: [selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
						name: selected.name,
						hue: selected.avatarHue,
						className: "size-6"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: selected.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-mono text-xs text-muted-foreground",
							children: selected.id
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Select a student…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "size-4 shrink-0 text-muted-foreground" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			align: "start",
			className: "w-[min(28rem,calc(100vw-2rem))] p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, {
				className: "rounded-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: "Search name, ID, email, college…" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No matching students." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, { children: students.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: `${s.name} ${s.id} ${s.email} ${s.college} ${s.country} ${s.branch}`,
					onSelect: () => {
						onChange(s.id);
						setOpen(false);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
							name: s.name,
							hue: s.avatarHue,
							className: "size-7"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-medium",
									children: s.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-micro text-muted-foreground",
									children: s.id
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-micro text-muted-foreground",
								children: [
									s.country,
									" · ",
									s.intake,
									" · ",
									s.branch
								]
							})]
						}),
						value === s.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-primary" })
					]
				}, s.id)) })] })]
			})
		})]
	});
}
function MatchBadge({ verdict, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: verdict === "eligible" ? "success" : verdict === "close" ? "warning" : "danger",
		className,
		children: verdictLabel(verdict)
	});
}
function ScoreMeter({ score, verdict }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-20 items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1.5 w-16 overflow-hidden rounded-full bg-secondary",
			"aria-hidden": true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("h-full rounded-full", verdict === "eligible" ? "bg-success" : verdict === "close" ? "bg-warning" : "bg-destructive"),
				style: { width: `${Math.max(4, score)}%` }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "tabular-nums text-xs font-medium",
			children: [score, "%"]
		})]
	});
}
function statusIcon(status) {
	if (status === "met") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-success" });
	if (status === "close") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5 text-warning" });
	if (status === "na") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5 text-muted-foreground" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5 text-destructive" });
}
function RequirementList({ checks, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: cn("grid gap-1.5", compact ? "gap-1" : "gap-1.5"),
			children: checks.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-secondary",
						children: statusIcon(c.status)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-wrap items-baseline justify-between gap-x-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: c.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-micro text-muted-foreground",
								children: [
									"Need ",
									c.required,
									c.status !== "na" ? ` · have ${c.actual}` : ""
								]
							})]
						}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs text-muted-foreground",
							children: c.detail
						})]
					}),
					compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-0.5 text-muted-foreground",
							"aria-label": c.detail,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
						className: "max-w-xs",
						children: c.detail
					})] })
				]
			}, c.id))
		})
	});
}
function EligibilityToolbar({ students, pickedId, onPick, activeStudent, analyzing, onAnalyze, onClear, summary, verdictFilter, onVerdictFilter, shortlistedCount, onShortlistTop }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-4 shadow-card sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Check student eligibility"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 max-w-xl text-sm text-muted-foreground",
					children: "Select a student to see which universities match their academics — and why."
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full min-w-0 flex-col gap-2 sm:flex-row sm:items-center lg:w-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentPicker, {
					students,
					value: pickedId,
					onChange: onPick,
					disabled: analyzing
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onAnalyze,
					disabled: !pickedId || analyzing,
					className: "shrink-0",
					children: [analyzing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "size-4" }), analyzing ? "Analyzing…" : "Check eligibility"]
				})]
			})]
		}), activeStudent && summary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-4 border-t border-border pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
						name: activeStudent.name,
						hue: activeStudent.avatarHue,
						className: "size-10"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate font-medium",
							children: [activeStudent.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 font-mono text-xs font-normal text-muted-foreground",
								children: activeStudent.id
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: [
								activeStudent.country,
								" · ",
								activeStudent.intake,
								" · ",
								activeStudent.branch,
								" · ",
								activeStudent.college
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
							label: "CGPA",
							value: activeStudent.cgpa.toFixed(2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
							label: "Grade",
							value: studentGermanGrade(activeStudent).toFixed(1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
							label: "English",
							value: formatEnglishProfile(activeStudent)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
							label: "German",
							value: activeStudent.germanLanguage === "None" ? "—" : activeStudent.germanLanguage
						}),
						typeof activeStudent.gre === "number" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
							label: "GRE",
							value: String(activeStudent.gre)
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryPill, {
							tone: "success",
							label: "Eligible",
							count: summary.eligible
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryPill, {
							tone: "warning",
							label: "Close match",
							count: summary.close
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryPill, {
							tone: "danger",
							label: "Not eligible",
							count: summary.ineligible
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryPill, {
							tone: "primary",
							label: "Shortlisted",
							count: shortlistedCount
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex rounded-lg bg-secondary p-1",
							children: [
								["all", "All"],
								["eligible", "Eligible"],
								["close", "Close"],
								["ineligible", "Not eligible"],
								["shortlisted", "Shortlisted"]
							].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onVerdictFilter(key),
								className: cn("rounded-md px-2.5 py-1 text-xs font-medium transition-colors", verdictFilter === key ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"),
								children: label
							}, key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: onShortlistTop,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkPlus, { className: "size-3.5" }), "Shortlist top matches"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: onClear,
							children: "Clear"
						})
					]
				})]
			})]
		})]
	});
}
function StatChip({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 rounded-md bg-secondary px-2 py-1 text-micro",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium text-foreground",
			children: value
		})]
	});
}
function SummaryPill({ tone, label, count }) {
	const cls = {
		success: "bg-success/10 text-success",
		warning: "bg-warning/10 text-warning",
		danger: "bg-destructive/10 text-destructive",
		primary: "bg-primary/10 text-primary"
	}[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium", cls),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: count
		}), label]
	});
}
function ShortlistToggle({ active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		size: "icon",
		variant: "ghost",
		className: "size-8",
		"aria-label": active ? "Remove from shortlist" : "Add to shortlist",
		"aria-pressed": active,
		onClick: (e) => {
			e.stopPropagation();
			onClick();
		},
		children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4 text-muted-foreground" })
	});
}
function ShortlistDock({ student, count, onReview, onReport, onCreateApps, onClear }) {
	if (count === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sticky bottom-3 z-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 rounded-xl border border-border bg-card/95 p-3 shadow-popover backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums font-semibold",
						children: count
					}),
					" ",
					count === 1 ? "university" : "universities",
					" shortlisted for",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: student.name
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: onClear,
						children: "Clear"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: onReview,
						children: "Review shortlist"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: onCreateApps,
						children: "Create applications"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: onReport,
						children: "Generate report"
					})
				]
			})]
		})
	});
}
function EligibilityReportDialog({ open, onOpenChange, student, counselor, settings, universities, matches, shortlistedIds, studentMessage, onMessageChange }) {
	const uniMap = (0, import_react.useMemo)(() => Object.fromEntries(universities.map((u) => [u.id, u])), [universities]);
	const matchMap = (0, import_react.useMemo)(() => Object.fromEntries(matches.map((m) => [m.universityId, m])), [matches]);
	const rows = shortlistedIds.map((id) => {
		const university = uniMap[id];
		const match = matchMap[id];
		if (!university || !match) return null;
		return {
			university,
			match
		};
	}).filter((row) => row !== null);
	const print = () => {
		const html = buildReportHtml({
			student,
			counselor,
			settings,
			rows,
			studentMessage
		});
		const w = window.open("", "_blank", "noopener,noreferrer,width=920,height=1200");
		if (!w) {
			downloadText(reportFilename(student, "html"), html, "text/html;charset=utf-8");
			toast.message("Pop-up blocked — downloaded the report instead. Open it and print to PDF.");
			return;
		}
		w.document.write(html);
		w.document.close();
		w.focus();
		window.setTimeout(() => w.print(), 400);
	};
	const downloadHtml = () => {
		downloadText(reportFilename(student, "html"), buildReportHtml({
			student,
			counselor,
			settings,
			rows,
			studentMessage
		}), "text/html;charset=utf-8");
		toast.success("Report downloaded");
	};
	const copySummary = async () => {
		const text = buildWhatsAppSummary({
			student,
			counselor,
			rows,
			studentMessage
		});
		try {
			await navigator.clipboard.writeText(text);
			toast.success("Student summary copied");
		} catch {
			toast.error("Could not copy — download the report instead.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "flex max-h-[90vh] max-w-3xl flex-col gap-0 overflow-hidden p-0 sm:max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-border p-6 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "University eligibility & shortlist report" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						"Student-facing document for ",
						student.name,
						". Print or save as PDF from the browser dialog."
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-y-auto p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "student-message",
							className: "mb-1.5 block text-xs font-medium text-muted-foreground",
							children: "Note to student (appears on the report)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "student-message",
							value: studentMessage,
							onChange: (e) => onMessageChange(e.target.value),
							placeholder: "e.g. Rahul, these five programmes are the strongest fit for Winter 2026. Let’s lock documents this week.",
							className: "min-h-20"
						})]
					}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-secondary px-3 py-6 text-center text-sm text-muted-foreground",
						children: "Shortlist at least one university to generate a report."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: rows.map(({ university, match }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl border border-border p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: university.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										university.course,
										" · ",
										university.location,
										", ",
										university.country,
										" · ",
										university.intake
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums text-xs font-medium text-muted-foreground",
										children: [match.score, "%"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchBadge, { verdict: match.verdict })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequirementList, {
									checks: match.checks,
									compact: true
								})
							})]
						}, university.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2 border-t border-border p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: copySummary,
							disabled: rows.length === 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copy summary"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: downloadHtml,
							disabled: rows.length === 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download HTML"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: print,
							disabled: rows.length === 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print / Save PDF"]
						})
					]
				})
			]
		})
	});
}
function reportFilename(student, ext) {
	return `Meridian_Shortlist_${student.name.replaceAll(/\s+/g, "_")}_${student.id}.${ext}`;
}
function reportId(student) {
	const d = /* @__PURE__ */ new Date();
	const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
	return `RPT-${student.id}-${stamp}`;
}
function escapeHtml(value) {
	return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;");
}
function buildReportHtml({ student, counselor, settings, rows, studentMessage }) {
	const generated = (/* @__PURE__ */ new Date()).toLocaleString("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	});
	const cards = rows.map(({ university, match }, i) => {
		const checks = match.checks.filter((c) => c.status !== "na").map((c) => {
			const mark = c.status === "met" ? "Met" : c.status === "close" ? "Close" : "Gap";
			const color = c.status === "met" ? "#16a34a" : c.status === "close" ? "#d97706" : "#dc2626";
			return `<tr>
            <td>${escapeHtml(c.label)}</td>
            <td>${escapeHtml(c.required)}</td>
            <td>${escapeHtml(c.actual)}</td>
            <td style="color:${color};font-weight:600">${mark}</td>
          </tr>`;
		}).join("");
		const why = match.reasons.length > 0 ? `<p class="why"><strong>Why this fits:</strong> ${escapeHtml(match.reasons.join(" "))}</p>` : "";
		const gaps = match.gaps.length > 0 ? `<p class="gap"><strong>What to strengthen:</strong> ${escapeHtml(match.gaps.join(" "))}</p>` : "";
		const steps = match.nextSteps.length > 0 ? `<ul class="steps">${match.nextSteps.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ul>` : "";
		const tone = match.verdict === "eligible" ? "#16a34a" : match.verdict === "close" ? "#d97706" : "#dc2626";
		return `<article class="card">
        <header>
          <div>
            <div class="kicker">Option ${i + 1}</div>
            <h2>${escapeHtml(university.name)}</h2>
            <p class="meta">${escapeHtml(university.course)} · ${escapeHtml(university.location)}, ${escapeHtml(university.country)}</p>
          </div>
          <div class="pill" style="color:${tone};border-color:${tone}33;background:${tone}14">${escapeHtml(verdictLabel(match.verdict))} · ${match.score}%</div>
        </header>
        <dl class="facts">
          <div><dt>Intake</dt><dd>${escapeHtml(university.intake)}</dd></div>
          <div><dt>Apply via</dt><dd>${escapeHtml(university.applicationVia)}</dd></div>
          <div><dt>Deadline</dt><dd>${escapeHtml(formatShortDate(university.deadline))}</dd></div>
          <div><dt>Application fee</dt><dd>${escapeHtml(formatINR(university.applicationFee))}</dd></div>
          <div><dt>Tuition</dt><dd>${escapeHtml(university.tuitionFees === 0 ? "No tuition / semester fee" : formatINR(university.tuitionFees))}</dd></div>
          <div><dt>MOI accepted</dt><dd>${university.moi ? "Yes" : "No"}</dd></div>
        </dl>
        <table>
          <thead><tr><th>Requirement</th><th>University needs</th><th>Your profile</th><th>Status</th></tr></thead>
          <tbody>${checks}</tbody>
        </table>
        ${why}${gaps}${steps}
      </article>`;
	}).join("");
	const note = studentMessage.trim() ? `<section class="note"><h3>Message from your counselor</h3><p>${escapeHtml(studentMessage.trim())}</p></section>` : "";
	return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>University shortlist — ${escapeHtml(student.name)}</title>
  <style>
    :root { color-scheme: light; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Inter, ui-sans-serif, system-ui, sans-serif; color: #111827; background: #fff; font-size: 13px; line-height: 1.5; }
    .page { max-width: 820px; margin: 0 auto; padding: 36px 40px 56px; }
    header.top { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; border-bottom: 1px solid #e5e7eb; padding-bottom: 20px; margin-bottom: 24px; }
    .brand { display: flex; gap: 10px; align-items: center; }
    .mark { width: 32px; height: 32px; border-radius: 8px; background: #2563eb; color: #fff; display: grid; place-items: center; font-weight: 700; }
    .brand strong { display: block; font-size: 15px; }
    .brand span { color: #6b7280; font-size: 12px; }
    .docid { text-align: right; color: #6b7280; font-size: 12px; }
    h1 { font-size: 22px; margin: 0 0 6px; letter-spacing: -0.02em; }
    .lede { color: #6b7280; margin: 0 0 20px; }
    .profile { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 22px; }
    .profile div { background: #f7f8fa; border: 1px solid #e5e7eb; border-radius: 10px; padding: 10px 12px; }
    .profile dt { font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.04em; }
    .profile dd { margin: 2px 0 0; font-weight: 600; }
    .note { background: #eef2ff; border: 1px solid #c7d2fe; border-radius: 12px; padding: 14px 16px; margin-bottom: 22px; }
    .note h3 { margin: 0 0 6px; font-size: 12px; color: #1d4ed8; }
    .note p { margin: 0; }
    .card { border: 1px solid #e5e7eb; border-radius: 14px; padding: 16px 18px 18px; margin-bottom: 16px; break-inside: avoid; }
    .card header { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
    .kicker { font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.06em; }
    .card h2 { margin: 2px 0 4px; font-size: 16px; }
    .meta { margin: 0; color: #6b7280; }
    .pill { font-size: 11px; font-weight: 600; border: 1px solid; border-radius: 999px; padding: 4px 10px; white-space: nowrap; }
    .facts { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 14px 0; }
    .facts div { background: #f9fafb; border-radius: 8px; padding: 8px 10px; }
    .facts dt { font-size: 11px; color: #6b7280; }
    .facts dd { margin: 0; font-weight: 600; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th { text-align: left; color: #6b7280; font-weight: 500; border-bottom: 1px solid #e5e7eb; padding: 6px 8px; }
    td { border-bottom: 1px solid #f3f4f6; padding: 7px 8px; vertical-align: top; }
    .why, .gap { margin: 12px 0 0; }
    .steps { margin: 8px 0 0; padding-left: 18px; }
    footer { margin-top: 28px; padding-top: 14px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 11px; }
    @media print {
      body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
      .page { padding: 0; }
      .card { break-inside: avoid; }
    }
    @media (max-width: 640px) {
      .profile, .facts { grid-template-columns: 1fr 1fr; }
      .page { padding: 20px; }
    }
  </style>
</head>
<body>
  <div class="page">
    <header class="top">
      <div class="brand">
        <div class="mark">M</div>
        <div>
          <strong>${escapeHtml(settings.name || "Meridian")}</strong>
          <span>Student operations</span>
        </div>
      </div>
      <div class="docid">
        <div>${escapeHtml(reportId(student))}</div>
        <div>Generated ${escapeHtml(generated)}</div>
      </div>
    </header>
    <h1>University Eligibility & Shortlist Report</h1>
    <p class="lede">Prepared for ${escapeHtml(student.name)} · ${escapeHtml(student.id)}${counselor ? ` · Counselor ${escapeHtml(counselor.name)}` : ""}</p>
    <dl class="profile">
      <div><dt>Destination</dt><dd>${escapeHtml(student.country)}</dd></div>
      <div><dt>Intake</dt><dd>${escapeHtml(student.intake)}</dd></div>
      <div><dt>Branch</dt><dd>${escapeHtml(student.branch)}</dd></div>
      <div><dt>College</dt><dd>${escapeHtml(student.college)}</dd></div>
      <div><dt>CGPA</dt><dd>${student.cgpa.toFixed(2)}</dd></div>
      <div><dt>German grade</dt><dd>${studentGermanGrade(student).toFixed(1)}</dd></div>
      <div><dt>English</dt><dd>${escapeHtml(formatEnglishProfile(student))}</dd></div>
      <div><dt>German language</dt><dd>${escapeHtml(student.germanLanguage === "None" ? "—" : student.germanLanguage)}</dd></div>
    </dl>
    ${note}
    ${cards}
    <footer>
      This report is an internal eligibility assessment based on the student's current academic profile and published university requirements.
      Final admission decisions rest with the university. Requirements can change — always reconfirm on the official portal before applying.
      ${settings.legalName ? escapeHtml(settings.legalName) + "." : ""}
    </footer>
  </div>
</body>
</html>`;
}
function buildWhatsAppSummary({ student, counselor, rows, studentMessage }) {
	const lines = [
		`University shortlist for ${student.name} (${student.id})`,
		`${student.country} · ${student.intake} · ${student.branch}`,
		`CGPA ${student.cgpa.toFixed(2)} · ${formatEnglishProfile(student)} · German ${student.germanLanguage}`,
		""
	];
	if (studentMessage.trim()) lines.push(studentMessage.trim(), "");
	rows.forEach(({ university, match }, i) => {
		lines.push(`${i + 1}. ${university.name} — ${university.course}`, `   ${verdictLabel(match.verdict)} (${match.score}%) · ${university.intake} · apply via ${university.applicationVia}`);
		if (match.gaps[0]) lines.push(`   Next: ${match.gaps[0]}`);
	});
	if (counselor) lines.push("", `Prepared by ${counselor.name}, Meridian`);
	return lines.join("\n");
}
function blankUni() {
	return {
		id: `UNI-${Math.floor(100 + Math.random() * 900)}`,
		name: "",
		location: "",
		country: "Germany",
		course: "",
		branch: "Computer Science",
		intake: "Winter 2026",
		ielts: 6.5,
		toefl: 80,
		germanLanguage: "B1",
		gre: "Not required",
		germanGrade: 2.5,
		applicationVia: "Uni-Assist",
		applicationFee: 75,
		deadline: new Date(Date.now() + 5184e6).toISOString(),
		tuitionFees: 0,
		moi: false,
		documentsCourier: "Required",
		aptitudeTest: "None",
		archived: false
	};
}
function UniversitiesPage() {
	const universities = useAppStore((s) => s.universities);
	const upsert = useAppStore((s) => s.upsertUniversity);
	const archive = useAppStore((s) => s.archiveUniversity);
	const duplicate = useAppStore((s) => s.duplicateUniversity);
	const appendAudit = useAppStore((s) => s.appendAudit);
	const shortlists = useAppStore((s) => s.shortlists);
	const toggleShortlist = useAppStore((s) => s.toggleShortlist);
	const setShortlist = useAppStore((s) => s.setShortlist);
	const setShortlistMessage = useAppStore((s) => s.setShortlistMessage);
	const clearShortlist = useAppStore((s) => s.clearShortlist);
	const createApplicationsFromShortlist = useAppStore((s) => s.createApplicationsFromShortlist);
	const currentUser = useAppStore((s) => s.currentUser);
	const settings = useAppStore((s) => s.settings);
	const employees = useAppStore((s) => s.employees);
	const { students } = useScopedIds();
	const searchStr = useRouterState({ select: (s) => s.location.searchStr });
	const searchParams = new URLSearchParams(searchStr.startsWith("?") ? searchStr.slice(1) : searchStr);
	const initialId = searchParams.get("u");
	const initialStudent = searchParams.get("student");
	const [q, setQ] = (0, import_react.useState)("");
	const [branch, setBranch] = (0, import_react.useState)("all");
	const [intake, setIntake] = (0, import_react.useState)("all");
	const [country, setCountry] = (0, import_react.useState)("all");
	const [ielts, setIelts] = (0, import_react.useState)("all");
	const [toefl, setToefl] = (0, import_react.useState)("all");
	const [course, setCourse] = (0, import_react.useState)("all");
	const [selected, setSelected] = (0, import_react.useState)(() => universities.find((u) => u.id === initialId) ?? null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [pickedId, setPickedId] = (0, import_react.useState)(initialStudent);
	const [activeStudentId, setActiveStudentId] = (0, import_react.useState)(null);
	const [analyzing, setAnalyzing] = (0, import_react.useState)(false);
	const [verdictFilter, setVerdictFilter] = (0, import_react.useState)("all");
	const [reportOpen, setReportOpen] = (0, import_react.useState)(false);
	const activeStudent = students.find((s) => s.id === activeStudentId) ?? null;
	const counselor = employees.find((e) => e.id === (activeStudent?.employeeId ?? currentUser?.id)) ?? currentUser;
	const shortlist = shortlists.find((s) => s.studentId === activeStudentId);
	const shortlistedIds = shortlist?.universityIds ?? [];
	const shortlistedSet = (0, import_react.useMemo)(() => new Set(shortlistedIds), [shortlistedIds]);
	const matches = (0, import_react.useMemo)(() => activeStudent ? matchAllUniversities(activeStudent, universities) : null, [activeStudent, universities]);
	const matchById = (0, import_react.useMemo)(() => matches ? Object.fromEntries(matches.map((m) => [m.universityId, m])) : null, [matches]);
	const summary = (0, import_react.useMemo)(() => matches ? summarizeMatches(matches) : null, [matches]);
	const courses = (0, import_react.useMemo)(() => [...new Set(universities.map((u) => u.course))].sort(), [universities]);
	const filtered = (0, import_react.useMemo)(() => {
		const rows = universities.filter((u) => {
			if (u.archived) return false;
			if (branch !== "all" && u.branch !== branch) return false;
			if (intake !== "all" && u.intake !== intake) return false;
			if (country !== "all" && u.country !== country) return false;
			if (course !== "all" && u.course !== course) return false;
			if (ielts !== "all" && u.ielts < Number(ielts)) return false;
			if (toefl !== "all" && u.toefl < Number(toefl)) return false;
			if (q && !`${u.name} ${u.course} ${u.country} ${u.branch}`.toLowerCase().includes(q.toLowerCase())) return false;
			if (matchById) {
				const match = matchById[u.id];
				if (!match) return false;
				if (verdictFilter === "shortlisted" && !shortlistedSet.has(u.id)) return false;
				if (verdictFilter !== "all" && verdictFilter !== "shortlisted" && match.verdict !== verdictFilter) return false;
			}
			return true;
		});
		if (!matchById) return rows;
		return [...rows].sort((a, b) => (matchById[b.id]?.score ?? 0) - (matchById[a.id]?.score ?? 0));
	}, [
		universities,
		branch,
		intake,
		country,
		course,
		ielts,
		toefl,
		q,
		matchById,
		verdictFilter,
		shortlistedSet
	]);
	const resetFilters = () => {
		setQ("");
		setBranch("all");
		setIntake("all");
		setCountry("all");
		setCourse("all");
		setIelts("all");
		setToefl("all");
		setVerdictFilter("all");
	};
	const runEligibility = () => {
		if (!pickedId) {
			toast.error("Select a student first");
			return;
		}
		const student = students.find((s) => s.id === pickedId);
		if (!student) {
			toast.error("Student not found");
			return;
		}
		setAnalyzing(true);
		window.setTimeout(() => {
			const stats = summarizeMatches(matchAllUniversities(student, universities));
			setActiveStudentId(student.id);
			setVerdictFilter("all");
			setAnalyzing(false);
			appendAudit({
				action: "VIEW",
				module: "Universities",
				recordId: student.id,
				details: `Eligibility check for ${student.name}: ${stats.eligible} eligible, ${stats.close} close, ${stats.ineligible} not eligible`,
				severity: "INFO"
			});
			toast.success(`${stats.eligible} eligible · ${stats.close} close matches for ${student.name.split(" ")[0]}`);
		}, 420);
	};
	const columns = (0, import_react.useMemo)(() => {
		const base = [{
			id: "sno",
			header: "S.No",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-muted-foreground",
				children: row.index + 1
			})
		}];
		if (matchById) base.push({
			id: "shortlist",
			header: "",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortlistToggle, {
				active: shortlistedSet.has(row.original.id),
				onClick: () => activeStudent && toggleShortlist(activeStudent.id, row.original.id)
			})
		}, {
			id: "match",
			header: "Match",
			cell: ({ row }) => {
				const match = matchById[row.original.id];
				if (!match) return "—";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreMeter, {
					score: match.score,
					verdict: match.verdict
				});
			}
		}, {
			id: "verdict",
			header: "Eligibility",
			cell: ({ row }) => {
				const match = matchById[row.original.id];
				return match ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchBadge, { verdict: match.verdict }) : "—";
			}
		});
		base.push({
			accessorKey: "name",
			header: "University"
		}, {
			accessorKey: "course",
			header: "Course"
		}, {
			accessorKey: "branch",
			header: "Branch"
		}, {
			accessorKey: "intake",
			header: "Intake"
		}, {
			accessorKey: "ielts",
			header: "IELTS"
		}, {
			accessorKey: "toefl",
			header: "TOEFL"
		}, {
			accessorKey: "germanLanguage",
			header: "German language"
		}, {
			accessorKey: "gre",
			header: "GRE"
		}, {
			accessorKey: "germanGrade",
			header: "German grade"
		}, {
			accessorKey: "applicationVia",
			header: "Application via"
		}, {
			accessorKey: "applicationFee",
			header: "Application fee",
			cell: ({ row }) => formatINR(row.original.applicationFee)
		}, {
			accessorKey: "deadline",
			header: "Deadline",
			cell: ({ row }) => formatShortDate(row.original.deadline)
		}, {
			accessorKey: "tuitionFees",
			header: "Tuition fees",
			cell: ({ row }) => formatINR(row.original.tuitionFees)
		}, {
			id: "moi",
			header: "MOI",
			cell: ({ row }) => row.original.moi ? "Yes" : "No"
		}, {
			id: "act",
			header: "",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					className: "size-8",
					onClick: (e) => e.stopPropagation(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				onClick: (e) => e.stopPropagation(),
				children: [
					activeStudent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onClick: () => toggleShortlist(activeStudent.id, row.original.id),
						children: shortlistedSet.has(row.original.id) ? "Remove from shortlist" : "Add to shortlist"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						onClick: () => setEditing(row.original),
						children: "Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => {
							duplicate(row.original.id);
							toast.success("University duplicated");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), " Duplicate"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => {
							archive(row.original.id);
							toast.message("University archived");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-4" }), " Archive"]
					})
				]
			})] })
		});
		return base;
	}, [
		archive,
		duplicate,
		matchById,
		shortlistedSet,
		activeStudent,
		toggleShortlist
	]);
	const selectedMatch = selected && matchById ? matchById[selected.id] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "University database",
				description: "Search and compare universities based on student eligibility.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => {
						const rows = filtered.map((u) => {
							const match = matchById?.[u.id];
							return {
								name: u.name,
								course: u.course,
								country: u.country,
								ielts: u.ielts,
								deadline: u.deadline,
								...match ? {
									match: match.score,
									eligibility: match.verdict,
									gaps: match.gaps.join("; ")
								} : {}
							};
						});
						downloadText("universities.csv", toCsv(rows));
						appendAudit({
							action: "EXPORT",
							module: "Universities",
							recordId: activeStudent?.id ?? "LIST",
							details: activeStudent ? `Exported eligibility results for ${activeStudent.name}` : "Exported university database",
							severity: "INFO"
						});
						toast.success("Universities exported");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Export"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setEditing(blankUni()),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add university"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EligibilityToolbar, {
				students,
				pickedId,
				onPick: setPickedId,
				activeStudent,
				analyzing,
				onAnalyze: runEligibility,
				onClear: () => {
					setActiveStudentId(null);
					setPickedId(null);
					setVerdictFilter("all");
				},
				summary,
				verdictFilter,
				onVerdictFilter: setVerdictFilter,
				shortlistedCount: shortlistedIds.length,
				onShortlistTop: () => {
					if (!activeStudent || !matches) return;
					const ids = suggestedShortlist(matches);
					setShortlist(activeStudent.id, ids);
					setVerdictFilter("shortlisted");
					toast.success(`Shortlisted ${ids.length} top matches`);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: filtered,
				columns,
				getRowId: (u) => u.id,
				getRowClassName: (u) => {
					const verdict = matchById?.[u.id]?.verdict;
					if (verdict === "eligible") return "bg-success/5";
					if (verdict === "close") return "bg-warning/5";
				},
				searchPlaceholder: "Search university…",
				globalFilter: q,
				onGlobalFilterChange: setQ,
				extraFilters: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: branch,
						onChange: setBranch,
						placeholder: "Branch",
						options: BRANCHES
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: intake,
						onChange: setIntake,
						placeholder: "Intake",
						options: INTAKES
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: country,
						onChange: setCountry,
						placeholder: "Country",
						options: [
							"Germany",
							"UK",
							"USA"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: course,
						onChange: setCourse,
						placeholder: "Course",
						options: courses
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: ielts,
						onChange: setIelts,
						placeholder: "IELTS",
						options: [
							{
								value: "6",
								label: "IELTS 6+"
							},
							{
								value: "6.5",
								label: "IELTS 6.5+"
							},
							{
								value: "7",
								label: "IELTS 7+"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: toefl,
						onChange: setToefl,
						placeholder: "TOEFL",
						options: [
							{
								value: "80",
								label: "TOEFL 80+"
							},
							{
								value: "90",
								label: "TOEFL 90+"
							},
							{
								value: "100",
								label: "TOEFL 100+"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: resetFilters,
						children: "Reset"
					})
				] }),
				onRowClick: (u) => setSelected(u),
				emptyTitle: "No universities found",
				onClearFilters: resetFilters,
				pageSize: 12,
				renderMobileCard: (u) => {
					const match = matchById?.[u.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: u.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								u.course,
								" · ",
								u.country
							]
						})] }), match && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchBadge, { verdict: match.verdict })]
					});
				}
			}),
			activeStudent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortlistDock, {
				student: activeStudent,
				count: shortlistedIds.length,
				onReview: () => setVerdictFilter("shortlisted"),
				onReport: () => {
					if (shortlistedIds.length === 0) {
						toast.error("Shortlist at least one university");
						return;
					}
					setReportOpen(true);
				},
				onCreateApps: () => {
					if (shortlistedIds.length === 0) {
						toast.error("Shortlist at least one university");
						return;
					}
					const result = createApplicationsFromShortlist(activeStudent.id, shortlistedIds);
					if (result.created === 0) toast.message("Applications already exist for this shortlist");
					else toast.success(result.skipped ? `Created ${result.created} applications (${result.skipped} already existed)` : `Created ${result.created} applications`);
				},
				onClear: () => {
					clearShortlist(activeStudent.id);
					toast.message("Shortlist cleared");
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!selected,
				onOpenChange: (v) => !v && setSelected(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					className: "w-full overflow-y-auto p-0 sm:max-w-md",
					children: selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: selected.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
						selected.location,
						" · ",
						selected.country
					] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 p-6",
						children: [
							selectedMatch && activeStudent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border border-border p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-3 flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
											children: ["Match for ", activeStudent.name]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm font-medium",
											children: ["Why this ", selectedMatch.verdict === "eligible" ? "fits" : "result"]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "tabular-nums text-xs font-medium",
												children: [selectedMatch.score, "%"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchBadge, { verdict: selectedMatch.verdict })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequirementList, { checks: selectedMatch.checks }),
									selectedMatch.reasons.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-xs text-muted-foreground",
										children: selectedMatch.reasons[0]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "mt-4 w-full",
										variant: shortlistedSet.has(selected.id) ? "outline" : "default",
										onClick: () => toggleShortlist(activeStudent.id, selected.id),
										children: shortlistedSet.has(selected.id) ? "Remove from shortlist" : "Add to shortlist"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
								title: "Program",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Course",
										v: selected.course
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Branch",
										v: selected.branch
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Intake",
										v: selected.intake
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
								title: "Eligibility",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "IELTS",
										v: String(selected.ielts)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "TOEFL",
										v: String(selected.toefl)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "German language",
										v: selected.germanLanguage
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "GRE",
										v: selected.gre
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "German grade",
										v: String(selected.germanGrade)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
								title: "Application",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Via",
										v: selected.applicationVia
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Fee",
										v: formatINR(selected.applicationFee)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Deadline",
										v: formatShortDate(selected.deadline)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Documents courier",
										v: selected.documentsCourier
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										k: "Aptitude test",
										v: selected.aptitudeTest
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
								title: "Financial",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Tuition",
									v: formatINR(selected.tuitionFees)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "MOI based",
									v: selected.moi ? "Yes" : "No"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "flex-1",
										onClick: () => {
											setEditing(selected);
											setSelected(null);
										},
										children: "Edit"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										onClick: () => {
											duplicate(selected.id);
											toast.success("Duplicated");
										},
										children: "Duplicate"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										onClick: () => {
											archive(selected.id);
											setSelected(null);
											toast.message("Archived");
										},
										children: "Archive"
									})
								]
							})
						]
					})] })
				})
			}),
			activeStudent && matches && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EligibilityReportDialog, {
				open: reportOpen,
				onOpenChange: setReportOpen,
				student: activeStudent,
				counselor,
				settings,
				universities,
				matches,
				shortlistedIds,
				studentMessage: shortlist?.studentMessage ?? "",
				onMessageChange: (v) => setShortlistMessage(activeStudent.id, v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UniversityEditor, {
				value: editing,
				onClose: () => setEditing(null),
				onSave: (u) => {
					upsert(u);
					toast.success("University updated");
					setEditing(null);
				}
			})
		]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children
	})] });
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: v
		})]
	});
}
function UniversityEditor({ value, onClose, onSave }) {
	const [draft, setDraft] = (0, import_react.useState)(blankUni());
	(0, import_react.useEffect)(() => {
		if (value) setDraft(value);
	}, [value]);
	const patch = (p) => setDraft((d) => ({
		...d,
		...p
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!value,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[85vh] overflow-y-auto sm:max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: value?.name ? "Edit university" : "Add university" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "University name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.name,
							onChange: (e) => patch({ name: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Location",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.location,
							onChange: (e) => patch({ location: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Country",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: draft.country,
							onValueChange: (v) => patch({ country: v }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
								"Germany",
								"UK",
								"USA"
							].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c,
								children: c
							}, c)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Course",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.course,
							onChange: (e) => patch({ course: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Branch",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: draft.branch,
							onValueChange: (v) => patch({ branch: v }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: BRANCHES.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: b,
								children: b
							}, b)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Intake",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: draft.intake,
							onValueChange: (v) => patch({ intake: v }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: INTAKES.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: i,
								children: i
							}, i)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "IELTS",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.5",
									value: draft.ielts,
									onChange: (e) => patch({ ielts: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "TOEFL",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.toefl,
									onChange: (e) => patch({ toefl: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "German grade",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.1",
									value: draft.germanGrade,
									onChange: (e) => patch({ germanGrade: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Application fee",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.applicationFee,
									onChange: (e) => patch({ applicationFee: Number(e.target.value) })
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Application via",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.applicationVia,
							onChange: (e) => patch({ applicationVia: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Tuition fees (₹)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: draft.tuitionFees,
							onChange: (e) => patch({ tuitionFees: Number(e.target.value) })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between text-sm",
						children: ["MOI based", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: draft.moi,
							onCheckedChange: (v) => patch({ moi: !!v })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (!draft.name.trim()) {
								toast.error("Name is required");
								return;
							}
							onSave(draft);
						},
						children: "Save university"
					})
				]
			})]
		})
	});
}
//#endregion
export { UniversitiesPage as t };
