import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Download, L as GraduationCap, f as Stamp, n as Wallet, r as Users, z as FileText } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useAppStore, k as APPLICATION_STATUSES } from "./router-z_xU0oK5.mjs";
import { t as PersonAvatar } from "./avatar-sLvn2RL6.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { i as formatLakhs, o as relativeTime, s as toCsv, t as downloadText } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B_I_naJs.mjs";
import { i as StatusBadge } from "./status-badge-CgLI5ccz.mjs";
import { n as useEmployeeMap, t as greetingName } from "./scoped-BYNid1DS.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DocumentsAttentionWidget } from "./documents-attention-widget-CxC1aue4.mjs";
import { a as XAxis, c as Bar, d as ResponsiveContainer, f as Tooltip, i as YAxis, l as Pie, n as PieChart, o as Area, r as BarChart, s as CartesianGrid, t as AreaChart, u as Cell } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-Brjx6V5K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PIE_COLORS = [
	"var(--color-chart-1)",
	"var(--color-chart-2)",
	"var(--color-chart-3)",
	"var(--color-chart-4)",
	"var(--color-chart-5)",
	"#64748b",
	"#94a3b8",
	"#0f766e"
];
function AdminDashboardPage() {
	const user = useAppStore((s) => s.currentUser);
	const students = useAppStore((s) => s.students);
	const applications = useAppStore((s) => s.applications);
	const payments = useAppStore((s) => s.payments);
	const employees = useAppStore((s) => s.employees);
	const audit = useAppStore((s) => s.auditEvents);
	useEmployeeMap();
	const navigate = useNavigate();
	const [range, setRange] = (0, import_react.useState)("30");
	const appendAudit = useAppStore((s) => s.appendAudit);
	const kpis = (0, import_react.useMemo)(() => {
		const activeApps = applications.filter((a) => a.status !== "Dropped").length;
		const offers = students.filter((s) => s.status === "Offered" || s.status === "Got Visa" || s.status === "Waiting").length;
		const visas = students.filter((s) => s.status === "Got Visa").length;
		const pendingPay = payments.filter((p) => p.status === "Pending" || p.status === "Partially Paid" || p.status === "Overdue");
		const pendingAmt = pendingPay.reduce((n, p) => n + p.remaining, 0);
		const activeEmps = employees.filter((e) => e.status === "Active" && e.role === "employee").length;
		return {
			activeApps,
			offers,
			visas,
			pendingPay: pendingPay.length,
			pendingAmt,
			activeEmps
		};
	}, [
		students,
		applications,
		payments,
		employees
	]);
	const trend = (0, import_react.useMemo)(() => {
		const buckets = [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		].map((m) => ({
			month: m,
			students: 0
		}));
		students.forEach((s) => {
			const d = new Date(s.createdAt);
			buckets[d.getMonth()].students += 1;
		});
		return buckets.slice(0, 9);
	}, [students]);
	const statusPie = (0, import_react.useMemo)(() => APPLICATION_STATUSES.map((st) => ({
		name: st,
		value: students.filter((s) => s.status === st).length
	})).filter((d) => d.value > 0), [students]);
	const byCountry = (0, import_react.useMemo)(() => {
		const m = {
			Germany: 0,
			UK: 0,
			USA: 0
		};
		students.forEach((s) => {
			m[s.country] = (m[s.country] ?? 0) + 1;
		});
		return Object.entries(m).map(([country, count]) => ({
			country,
			count
		}));
	}, [students]);
	const performance = (0, import_react.useMemo)(() => {
		return employees.filter((e) => e.role === "employee" && e.status === "Active").map((e) => {
			const mine = students.filter((s) => s.employeeId === e.id);
			const apps = applications.filter((a) => a.employeeId === e.id);
			return {
				id: e.id,
				name: e.name,
				hue: e.avatarHue,
				students: mine.length,
				applications: apps.length,
				offers: mine.filter((s) => s.status === "Offered" || s.status === "Got Visa").length,
				visas: mine.filter((s) => s.status === "Got Visa").length,
				pending: mine.filter((s) => s.paymentStatus !== "Paid").length
			};
		}).sort((a, b) => b.students - a.students).slice(0, 8);
	}, [
		employees,
		students,
		applications
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: greetingName(user?.name ?? "Admin"),
				description: "Here's what's happening across your organization.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: range,
					onValueChange: setRange,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-[140px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "7",
							children: "Last 7 days"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "30",
							children: "Last 30 days"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "90",
							children: "Last 90 days"
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => {
						downloadText("meridian-overview.csv", toCsv([{
							students: students.length,
							applications: kpis.activeApps,
							offers: kpis.offers,
							visas: kpis.visas
						}]));
						appendAudit({
							action: "EXPORT",
							module: "Reports",
							recordId: "DASH",
							details: "Exported overview report",
							severity: "INFO"
						});
						toast.success("Report exported");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Export report"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total students",
						value: students.length,
						delta: 12.4,
						icon: GraduationCap
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active applications",
						value: kpis.activeApps,
						delta: 8.2,
						icon: FileText
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Offers received",
						value: kpis.offers,
						delta: 14.6,
						icon: Stamp
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Visas received",
						value: kpis.visas,
						delta: 9.8,
						icon: Stamp
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending payments",
						value: kpis.pendingPay,
						hint: formatLakhs(kpis.pendingAmt),
						icon: Wallet
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active employees",
						value: kpis.activeEmps,
						icon: Users
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentsAttentionWidget, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 xl:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "xl:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Student registration trend" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: trend,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "fillStudents",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "var(--color-primary)",
											stopOpacity: .25
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "var(--color-primary)",
											stopOpacity: 0
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										strokeDasharray: "3 3",
										stroke: "var(--color-border)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "month",
										tick: { fontSize: 12 },
										stroke: "var(--color-muted-foreground)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tick: { fontSize: 12 },
										stroke: "var(--color-muted-foreground)",
										allowDecimals: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "students",
										stroke: "var(--color-primary)",
										fill: "url(#fillStudents)",
										strokeWidth: 2
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "xl:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Application status" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
								data: statusPie,
								dataKey: "value",
								nameKey: "name",
								innerRadius: 52,
								outerRadius: 80,
								paddingAngle: 2,
								children: statusPie.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: PIE_COLORS[i % PIE_COLORS.length] }, i))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {})] })
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 xl:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "xl:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Students by country" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "h-56",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: byCountry,
								layout: "vertical",
								margin: { left: 16 },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										strokeDasharray: "3 3",
										stroke: "var(--color-border)",
										horizontal: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										type: "number",
										tick: { fontSize: 12 },
										allowDecimals: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										type: "category",
										dataKey: "country",
										tick: { fontSize: 12 },
										width: 70
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "count",
										fill: "var(--color-primary)",
										radius: [
											0,
											6,
											6,
											0
										],
										barSize: 16
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "xl:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
						className: "flex-row items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Employee performance" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "overflow-x-auto p-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-table",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-left text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b",
									children: [
										"Employee",
										"Students",
										"Apps",
										"Offers",
										"Visas",
										"Pending"
									].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-5 py-2 font-medium",
										children: h
									}, h))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: performance.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "cursor-pointer border-b last:border-0 hover:bg-secondary/60",
								onClick: () => void navigate({ to: `/admin/employees/${row.id}` }),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
												name: row.name,
												hue: row.hue,
												className: "size-6"
											}), row.name]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2.5 tabular-nums",
										children: row.students
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2.5 tabular-nums",
										children: row.applications
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2.5 tabular-nums",
										children: row.offers
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2.5 tabular-nums",
										children: row.visas
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2.5 tabular-nums",
										children: row.pending
									})
								]
							}, row.id)) })]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Recent activity" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-4",
				children: audit.slice(0, 6).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-20 shrink-0 text-micro text-muted-foreground",
							children: new Date(e.timestamp).toLocaleTimeString([], {
								hour: "numeric",
								minute: "2-digit"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: e.user
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: e.details.toLowerCase()
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs",
											children: e.recordId
										})
									]
								}),
								e.before && e.after && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 flex items-center gap-2 text-xs text-muted-foreground",
									children: [
										e.before,
										" → ",
										e.after
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-micro text-muted-foreground",
									children: relativeTime(e.timestamp)
								})
							]
						}),
						APPLICATION_STATUSES.includes(e.after) && e.after && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ml-auto hidden sm:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: e.after })
						})
					]
				}, e.id))
			})] })
		]
	});
}
var SplitComponent = AdminDashboardPage;
//#endregion
export { SplitComponent as component };
