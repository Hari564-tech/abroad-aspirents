import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate, m as useBlocker } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { N as GERMAN_LEVELS, P as INTAKES, c as useAppStore, g as categoryForType, j as BRANCHES, k as APPLICATION_STATUSES, u as COUNTRY_DOCUMENT_RULES } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as Card } from "./card-B_I_naJs.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-CnGpc8qo.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as Switch } from "./switch-95CbCe8f.mjs";
import { t as FormField } from "./form-field-LURrrOeP.mjs";
import { n as PasswordField, r as PortalShareDrawer, t as DocumentWorkspace } from "./document-workspace-hBhufopM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student-form-D4fthVCH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	"Personal",
	"Academic",
	"Account",
	"Application",
	"Payment",
	"Documents",
	"Review"
];
var DRAFT_KEY = "meridian-student-editor-draft";
function emptyDraft(employeeId, intake) {
	return {
		id: "",
		name: "",
		email: "",
		phone1: "",
		phone2: "",
		country: "Germany",
		intake,
		branch: "Computer Science",
		college: "",
		employeeId,
		status: "Shortlisting Sent",
		cgpa: 0,
		germanLanguage: "None",
		gmailId: "",
		gmailPassword: "",
		recoveryNumber: "",
		device: "",
		twoStep: false,
		uniAssistDocuments: "Not Uploaded",
		blockedAccount: "Not Applied",
		enrollment: "Not Applied",
		studentDorm: "Not Applied",
		totalFee: 1e5,
		paidAmount: 0,
		discount: 0,
		leadType: "Direct",
		notes: ""
	};
}
function StudentFormPage({ studentId }) {
	const existing = useAppStore((s) => s.students.find((st) => st.id === studentId));
	const employees = useAppStore((s) => s.employees);
	const currentUser = useAppStore((s) => s.currentUser);
	const settings = useAppStore((s) => s.settings);
	const createStudent = useAppStore((s) => s.createStudent);
	const updateStudent = useAppStore((s) => s.updateStudent);
	const { base, role } = useWorkspace();
	const navigate = useNavigate();
	const defaultEmp = role === "employee" ? currentUser?.id ?? "" : employees.find((e) => e.role === "employee")?.id ?? "";
	const [step, setStep] = (0, import_react.useState)(0);
	const [draft, setDraft] = (0, import_react.useState)(() => existing ? { ...existing } : emptyDraft(defaultEmp, settings.defaultIntake));
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saveState, setSaveState] = (0, import_react.useState)("idle");
	const [leaveOpen, setLeaveOpen] = (0, import_react.useState)(false);
	const [portalStudent, setPortalStudent] = (0, import_react.useState)(null);
	const [savedId, setSavedId] = (0, import_react.useState)(studentId);
	const lastSaved = (0, import_react.useRef)(JSON.stringify(draft));
	const createPortal = useAppStore((s) => s.createPortal);
	const seedDocs = useAppStore((s) => s.seedStudentDocuments);
	const liveStudent = useAppStore((s) => s.students.find((st) => st.id === (existing?.id ?? savedId)));
	const blocker = useBlocker({
		shouldBlockFn: () => JSON.stringify(draft) !== lastSaved.current,
		withResolver: true,
		enableBeforeUnload: true
	});
	const patch = (p) => {
		setDraft((d) => ({
			...d,
			...p
		}));
		setSaveState("unsaved");
	};
	(0, import_react.useEffect)(() => {
		if (existing) return;
		try {
			const raw = localStorage.getItem(DRAFT_KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (parsed?.name !== void 0) {
				setDraft((d) => ({
					...d,
					...parsed
				}));
				lastSaved.current = JSON.stringify({
					...emptyDraft(defaultEmp, settings.defaultIntake),
					...parsed
				});
				setSaveState("saved");
			}
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
				e.preventDefault();
				saveDraft();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	(0, import_react.useEffect)(() => {
		if (blocker.status === "blocked") setLeaveOpen(true);
	}, [blocker.status]);
	const germany = draft.country === "Germany";
	function validate(at = step) {
		const e = {};
		if (at === 0) {
			if (!draft.name.trim()) e.name = "Name is required";
			if (!draft.phone1.trim()) e.phone1 = "Phone is required";
			if (!draft.college.trim()) e.college = "College is required";
		}
		if (at === 1 && (!draft.cgpa || draft.cgpa < 0)) e.cgpa = "Enter CGPA";
		if (at === 4 && draft.totalFee <= 0) e.totalFee = "Enter a fee";
		setErrors(e);
		return Object.keys(e).length === 0;
	}
	function next() {
		if (!validate()) return;
		if (step === 4 || step === 5) {
			if (!validate(0) || !validate(1) || !validate(4)) {
				setStep(0);
				return;
			}
			persistStudent();
		}
		setStep((s) => Math.min(STEPS.length - 1, s + 1));
	}
	function persistLocal() {
		if (existing) return;
		localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
	}
	function saveDraft() {
		setSaveState("saving");
		persistLocal();
		if (existing) updateStudent(existing.id, draft);
		lastSaved.current = JSON.stringify(draft);
		window.setTimeout(() => setSaveState("saved"), 280);
		toast.success("Draft saved");
	}
	function persistStudent() {
		if (existing || savedId) {
			const id = existing?.id ?? savedId;
			updateStudent(id, draft);
			seedDocs(id);
			lastSaved.current = JSON.stringify(draft);
			setSaveState("saved");
			return useAppStore.getState().students.find((s) => s.id === id);
		}
		const created = createStudent(draft);
		setSavedId(created.id);
		lastSaved.current = JSON.stringify(draft);
		setSaveState("saved");
		localStorage.removeItem(DRAFT_KEY);
		return created;
	}
	function save() {
		if (!validate(0) || !validate(1) || !validate(4)) {
			setStep(0);
			return;
		}
		const created = persistStudent();
		lastSaved.current = JSON.stringify(draft);
		toast.success(existing ? "Student updated" : "Student created successfully");
		navigate({ to: `${base}/students/${created.id}` });
	}
	function saveAndPortal() {
		if (!validate(0) || !validate(1) || !validate(4)) {
			setStep(0);
			return;
		}
		const created = persistStudent();
		createPortal({
			studentId: created.id,
			accessMethod: "email_and_link",
			email: created.email || created.gmailId
		});
		setPortalStudent(created);
		toast.success("Portal created");
	}
	const counselors = (0, import_react.useMemo)(() => employees.filter((e) => e.role === "employee" && e.status === "Active"), [employees]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: existing ? `Edit ${existing.name}` : "Add student",
				description: "Capture personal, academic and application details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-micro text-muted-foreground",
				"aria-live": "polite",
				children: [
					saveState === "saving" && "Saving…",
					saveState === "saved" && "Saved just now",
					saveState === "unsaved" && "Unsaved changes"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-wrap gap-2",
				children: STEPS.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						if (i >= 5 && !existing && !savedId) {
							if (!validate(0) || !validate(1) || !validate(4)) return;
							persistStudent();
						}
						setStep(i);
					},
					className: cn("rounded-full px-3 py-1 text-xs font-medium", i === step ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: [
						String(i + 1).padStart(2, "0"),
						" ",
						label
					]
				}) }, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Student ID",
								hint: "Leave blank to auto-generate (W26_001)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.id,
									onChange: (e) => patch({ id: e.target.value }),
									placeholder: "W26_001"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Intake",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.intake,
									onValueChange: (v) => patch({ intake: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: INTAKES.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: i,
										children: i
									}, i)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Country",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.country,
									onValueChange: (v) => patch({ country: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
										"Germany",
										"UK",
										"USA"
									].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: c,
										children: c
									}, c)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Name",
								required: true,
								error: errors.name,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.name,
									onChange: (e) => patch({ name: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Phone 1",
								required: true,
								error: errors.phone1,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.phone1,
									onChange: (e) => patch({ phone1: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Phone 2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.phone2,
									onChange: (e) => patch({ phone2: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Branch",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.branch,
									onValueChange: (v) => patch({ branch: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: BRANCHES.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: b,
										children: b
									}, b)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "College / University",
								required: true,
								error: errors.college,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.college,
									onChange: (e) => patch({ college: e.target.value })
								})
							}),
							role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Assigned employee",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.employeeId,
									onValueChange: (v) => patch({ employeeId: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: counselors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: e.id,
										children: e.name
									}, e.id)) })]
								})
							})
						]
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "CGPA",
								required: true,
								error: errors.cgpa,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									value: draft.cgpa || "",
									onChange: (e) => patch({ cgpa: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "IELTS",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.5",
									value: draft.ielts ?? "",
									onChange: (e) => patch({ ielts: e.target.value ? Number(e.target.value) : void 0 })
								})
							}),
							(draft.country === "USA" || draft.country === "UK") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "TOEFL",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.toefl ?? "",
									onChange: (e) => patch({ toefl: e.target.value ? Number(e.target.value) : void 0 })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Duolingo",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.duolingo ?? "",
									onChange: (e) => patch({ duolingo: e.target.value ? Number(e.target.value) : void 0 })
								})
							}),
							germany && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "German grade",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.1",
									value: draft.germanGrade ?? "",
									onChange: (e) => patch({ germanGrade: e.target.value ? Number(e.target.value) : void 0 })
								})
							}),
							draft.country === "USA" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "GRE",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.gre ?? "",
									onChange: (e) => patch({ gre: e.target.value ? Number(e.target.value) : void 0 })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "German language",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.germanLanguage,
									onValueChange: (v) => patch({ germanLanguage: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: GERMAN_LEVELS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: g,
										children: g
									}, g)) })]
								})
							})
						]
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-lg bg-warning/10 px-3 py-2 text-sm text-warning",
								children: "Sensitive information. Handle account credentials carefully. This is a frontend prototype and does not provide production-grade credential security."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Gmail ID",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.gmailId,
									onChange: (e) => patch({
										gmailId: e.target.value,
										email: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
								label: "Gmail password",
								value: draft.gmailPassword,
								onChange: (v) => patch({ gmailPassword: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Recovery number",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.recoveryNumber,
									onChange: (e) => patch({ recoveryNumber: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Device",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.device,
									onChange: (e) => patch({ device: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center justify-between rounded-lg border px-3 py-2 text-sm",
								children: ["2-step verification", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: draft.twoStep,
									onCheckedChange: (v) => patch({ twoStep: !!v })
								})]
							}),
							germany && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
										label: "APS username",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: draft.apsUsername ?? "",
											onChange: (e) => patch({ apsUsername: e.target.value })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
										label: "APS password",
										value: draft.apsPassword ?? "",
										onChange: (v) => patch({ apsPassword: v })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
										label: "Uni-Assist ID",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: draft.uniAssistId ?? "",
											onChange: (e) => patch({ uniAssistId: e.target.value })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordField, {
										label: "Uni-Assist password",
										value: draft.uniAssistPassword ?? "",
										onChange: (v) => patch({ uniAssistPassword: v })
									})
								]
							})
						]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Application status",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.status,
									onValueChange: (v) => patch({ status: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: APPLICATION_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s,
										children: s
									}, s)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Lead type",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.leadType,
									onValueChange: (v) => patch({ leadType: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Direct",
										children: "Direct"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "B2B",
										children: "B2B"
									})] })]
								})
							}),
							draft.leadType === "B2B" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "B2B organization",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.b2bOrg ?? "",
									onChange: (e) => patch({ b2bOrg: e.target.value })
								})
							}),
							germany && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
									label: "Uni-Assist documents",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: draft.uniAssistDocuments ?? "Not Uploaded",
										onValueChange: (v) => patch({ uniAssistDocuments: v }),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Uploaded",
											children: "Uploaded"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Not Uploaded",
											children: "Not Uploaded"
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
									label: "Blocked account",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: draft.blockedAccount ?? "Not Applied",
										onValueChange: (v) => patch({ blockedAccount: v }),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Applied",
											children: "Applied"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Not Applied",
											children: "Not Applied"
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
									label: "Enrollment",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: draft.enrollment ?? "Not Applied",
										onValueChange: (v) => patch({ enrollment: v }),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Applied",
											children: "Applied"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Not Applied",
											children: "Not Applied"
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
									label: "Student dorm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: draft.studentDorm ?? "Not Applied",
										onValueChange: (v) => patch({ studentDorm: v }),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Applied",
											children: "Applied"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "Not Applied",
											children: "Not Applied"
										})] })]
									})
								})
							] })
						]
					}),
					step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Total fee (₹)",
								required: true,
								error: errors.totalFee,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.totalFee,
									onChange: (e) => patch({ totalFee: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Initial payment (₹)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.paidAmount,
									onChange: (e) => patch({ paidAmount: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "Discount (₹)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: draft.discount,
									onChange: (e) => patch({ discount: Number(e.target.value) })
								})
							})
						]
					}),
					step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentsStep, {
						draft,
						student: existing ?? liveStudent,
						onUploadPortal: () => saveAndPortal()
					}),
					step === 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid gap-3 text-sm sm:grid-cols-2",
						children: [
							["Name", draft.name],
							["Intake", draft.intake],
							["Country", draft.country],
							["College", draft.college],
							["Status", draft.status],
							["Fee", `₹${draft.totalFee.toLocaleString("en-IN")}`]
						].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted-foreground",
							children: k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium",
							children: v
						})] }, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							disabled: step === 0,
							onClick: () => setStep((s) => s - 1),
							children: "Back"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: saveDraft,
									children: "Save draft"
								}),
								step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: saveAndPortal,
									children: "Save & create upload portal"
								}),
								step < STEPS.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: next,
									children: step === 5 ? "Save & continue" : "Continue"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: save,
									children: existing ? "Save changes" : "Create student"
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: leaveOpen,
				onOpenChange: (v) => {
					setLeaveOpen(v);
					if (!v && blocker.status === "blocked") blocker.reset();
				},
				title: "You have unsaved changes.",
				description: "Leave this student without saving?",
				confirmLabel: "Leave without saving",
				cancelLabel: "Stay",
				destructive: true,
				onConfirm: () => {
					lastSaved.current = JSON.stringify(draft);
					setLeaveOpen(false);
					if (blocker.status === "blocked") blocker.proceed();
					else navigate({ to: `${base}/students` });
				}
			}),
			portalStudent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShareDrawer, {
				open: !!portalStudent,
				onOpenChange: (v) => {
					if (!v) {
						const id = portalStudent.id;
						setPortalStudent(null);
						navigate({ to: `${base}/students/${id}` });
					}
				},
				student: portalStudent,
				startCreated: true
			})
		]
	});
}
function DocumentsStep({ draft, student, onUploadPortal }) {
	const rules = COUNTRY_DOCUMENT_RULES[draft.country];
	if (student) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "-mx-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentWorkspace, {
			student,
			compactHeader: true,
			showPortalBanner: true,
			onCreatePortal: onUploadPortal
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: "Documents"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Upload, manage and collect documents for this student."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Requirements below are configured for ",
					draft.country,
					". They are business rules for this destination, not universal requirements. Saving this student creates the checklist. Use Save & create upload portal to generate a student link."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y rounded-xl border",
				children: rules.map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between px-3 py-2.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: rule.type
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-micro text-muted-foreground",
						children: categoryForType(rule.type)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-micro text-muted-foreground",
						children: rule.required ? "Required" : "Optional"
					})]
				}, rule.type))
			})
		]
	});
}
//#endregion
export { StudentFormPage as t };
