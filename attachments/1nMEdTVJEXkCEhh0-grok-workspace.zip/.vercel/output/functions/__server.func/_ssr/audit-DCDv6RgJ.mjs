import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as AUDIT_ACTIONS, c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as isToday } from "../_libs/date-fns.mjs";
import { n as formatDateTime } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { r as SeverityBadge } from "./status-badge-CgLI5ccz.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, t as Sheet } from "./sheet-CY9M7c4U.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
import { t as FilterSelect } from "./filter-select-DRpDDDny.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-DCDv6RgJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditPage() {
	const events = useAppStore((s) => s.auditEvents);
	const [user, setUser] = (0, import_react.useState)("all");
	const [role, setRole] = (0, import_react.useState)("all");
	const [action, setAction] = (0, import_react.useState)("all");
	const [module, setModule] = (0, import_react.useState)("all");
	const [severity, setSeverity] = (0, import_react.useState)("all");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const users = (0, import_react.useMemo)(() => [...new Set(events.map((e) => e.user))], [events]);
	const modules = (0, import_react.useMemo)(() => [...new Set(events.map((e) => e.module))], [events]);
	const filtered = (0, import_react.useMemo)(() => events.filter((e) => {
		if (user !== "all" && e.user !== user) return false;
		if (role !== "all" && e.role !== role) return false;
		if (action !== "all" && e.action !== action) return false;
		if (module !== "all" && e.module !== module) return false;
		if (severity !== "all" && e.severity !== severity) return false;
		return true;
	}), [
		events,
		user,
		role,
		action,
		module,
		severity
	]);
	const kpis = (0, import_react.useMemo)(() => {
		return {
			today: events.filter((e) => isToday(new Date(e.timestamp))).length,
			critical: events.filter((e) => e.severity === "CRITICAL").length,
			admin: events.filter((e) => e.role === "admin").length,
			failed: events.filter((e) => e.action === "DELETE" || e.severity === "CRITICAL").length
		};
	}, [events]);
	const columns = (0, import_react.useMemo)(() => [
		{
			accessorKey: "timestamp",
			header: "Timestamp",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "whitespace-nowrap",
				children: formatDateTime(row.original.timestamp)
			})
		},
		{
			accessorKey: "user",
			header: "User"
		},
		{
			accessorKey: "role",
			header: "Role",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "capitalize",
				children: row.original.role
			})
		},
		{
			accessorKey: "action",
			header: "Action"
		},
		{
			accessorKey: "module",
			header: "Module"
		},
		{
			accessorKey: "recordId",
			header: "Record",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: row.original.recordId
			})
		},
		{
			id: "changes",
			header: "Changes",
			cell: ({ row }) => row.original.before && row.original.after ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs",
				children: [
					row.original.before,
					" → ",
					row.original.after
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: row.original.details
			})
		},
		{
			accessorKey: "severity",
			header: "Severity",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: row.original.severity })
		},
		{
			accessorKey: "ip",
			header: "IP",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: row.original.ip
			})
		}
	], []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Audit Center",
				description: "Track every important action performed across the platform."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Today's events",
						value: kpis.today.toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Critical events",
						value: kpis.critical
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Admin actions",
						value: kpis.admin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Failed actions",
						value: kpis.failed
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: filtered,
				columns,
				getRowId: (e) => e.id,
				searchPlaceholder: "Search audit events…",
				extraFilters: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: user,
						onChange: setUser,
						placeholder: "User",
						options: users
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: role,
						onChange: setRole,
						placeholder: "Role",
						options: [
							"admin",
							"employee",
							"student"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: action,
						onChange: setAction,
						placeholder: "Action",
						options: AUDIT_ACTIONS
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: module,
						onChange: setModule,
						placeholder: "Module",
						options: modules
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: severity,
						onChange: setSeverity,
						placeholder: "Severity",
						options: [
							"INFO",
							"SUCCESS",
							"WARNING",
							"CRITICAL"
						]
					})
				] }),
				onRowClick: (e) => setSelected(e),
				emptyTitle: "No audit events",
				onClearFilters: () => {
					setUser("all");
					setRole("all");
					setAction("all");
					setModule("all");
					setSeverity("all");
				},
				pageSize: 15,
				renderMobileCard: (e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: e.user
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: e.severity })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: e.details
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-micro",
						children: e.recordId
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!selected,
				onOpenChange: (v) => !v && setSelected(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					className: "overflow-y-auto p-0 sm:max-w-md",
					children: selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Event details" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 p-6 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Who",
								v: selected.user
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Role",
								v: selected.role
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "What",
								v: selected.details
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Action",
								v: selected.action
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "When",
								v: formatDateTime(selected.timestamp)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Student / record",
								v: selected.recordId,
								mono: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Module",
								v: selected.module
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "IP address",
								v: selected.ip,
								mono: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "User agent",
								v: selected.userAgent
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground",
								children: "Changes"
							}), selected.before || selected.after ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "overflow-hidden rounded-lg border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 bg-secondary px-3 py-1.5 text-micro font-medium",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Field" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Previous state" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "New state" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 px-3 py-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: selected.before ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: selected.after ?? "—"
										})
									]
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: selected.details
							})] })
						]
					})] })
				})
			})
		]
	});
}
function Row({ k, v, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: mono ? "font-mono text-xs" : "font-medium",
		children: v
	})] });
}
var SplitComponent = AuditPage;
//#endregion
export { SplitComponent as component };
