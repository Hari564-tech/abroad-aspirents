import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Label } from "./label-BKnlZqNF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/form-field-LURrrOeP.js
var import_jsx_runtime = require_jsx_runtime();
function FormField({ label, htmlFor, required, hint, error, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid gap-1.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				htmlFor,
				children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-0.5 text-destructive",
					children: "*"
				})]
			}),
			children,
			hint && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-muted-foreground",
				children: hint
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-destructive",
				children: error
			})
		]
	});
}
//#endregion
export { FormField as t };
