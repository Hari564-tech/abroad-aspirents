import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useAppStore } from "./router-z_xU0oK5.mjs";
import { t as WorkspaceContext } from "./workspace-NrHasYwb.mjs";
import { t as AppShell } from "./app-shell-IUwtpOi1.mjs";
import { t as ShellSkeleton } from "./loading-state-DRw3a4Or.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employee-BatQ7GXx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EmployeeLayout() {
	const hydrated = useAppStore((s) => s.hydrated);
	const user = useAppStore((s) => s.currentUser);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (!user) navigate({
			to: "/login",
			replace: true
		});
		else if (user.role !== "employee") navigate({
			to: "/admin/dashboard",
			replace: true
		});
	}, [
		hydrated,
		user,
		navigate
	]);
	if (!hydrated || !user || user.role !== "employee") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellSkeleton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceContext.Provider, {
		value: {
			role: "employee",
			base: "/employee"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {})
	});
}
//#endregion
export { EmployeeLayout as component };
