import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as initials, t as cn } from "./utils-Bcse6IW9.mjs";
import { n as AvatarFallback$1, r as AvatarImage$1, t as Avatar$1 } from "../_libs/radix-ui__react-avatar.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/avatar-sLvn2RL6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Avatar = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar$1, {
	ref,
	className: cn("relative flex size-8 shrink-0 overflow-hidden rounded-full", className),
	...props
}));
Avatar.displayName = Avatar$1.displayName;
var AvatarImage = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage$1, {
	ref,
	className: cn("aspect-square size-full", className),
	...props
}));
AvatarImage.displayName = AvatarImage$1.displayName;
var AvatarFallback = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback$1, {
	ref,
	className: cn("flex size-full items-center justify-center rounded-full bg-secondary text-micro font-medium text-muted-foreground", className),
	...props
}));
AvatarFallback.displayName = AvatarFallback$1.displayName;
function PersonAvatar({ name, hue, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarFallback, {
			className: hue == null ? "text-micro font-semibold" : "text-micro font-semibold bg-[hsl(var(--avatar-h)_42%_92%)] text-[hsl(var(--avatar-h)_40%_28%)] dark:bg-[hsl(var(--avatar-h)_28%_22%)] dark:text-[hsl(var(--avatar-h)_55%_86%)]",
			style: hue == null ? void 0 : { "--avatar-h": String(hue) },
			children: initials(name)
		})
	});
}
//#endregion
export { PersonAvatar as t };
