import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workspace-NrHasYwb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var WorkspaceContext = (0, import_react.createContext)({
	role: "admin",
	base: "/admin"
});
function useWorkspace() {
	return (0, import_react.useContext)(WorkspaceContext);
}
//#endregion
export { useWorkspace as n, WorkspaceContext as t };
