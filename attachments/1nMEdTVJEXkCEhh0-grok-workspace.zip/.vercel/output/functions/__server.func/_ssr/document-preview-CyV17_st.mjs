import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Download, a as Upload, nt as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { O as validateUploadFile, _ as defaultDocumentName, b as formatBytes, c as useAppStore, f as DOCUMENT_TYPE_CATALOG, h as canPreview, l as getFileData, p as FILE_RULES } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, r as SheetDescription, t as Sheet } from "./sheet-CY9M7c4U.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as FormField } from "./form-field-LURrrOeP.mjs";
import { t as Textarea } from "./textarea-CMcQQGlC.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/document-preview-CyV17_st.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-transform duration-300",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
function UploadProgress({ fileName, progress, complete, error, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-lg border bg-secondary/40 p-3", className),
		children: [
			complete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm font-medium text-success",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Upload complete"]
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-destructive",
				children: error
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Uploading…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 truncate text-micro text-muted-foreground",
				children: fileName
			}),
			!complete && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: progress,
					className: "flex-1"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-micro tabular-nums text-muted-foreground",
					children: [Math.round(progress), "%"]
				})]
			})
		]
	});
}
function DocumentUpload({ open, onOpenChange, student, presetType, replaceOf, asStudent, onUploaded }) {
	const upload = useAppStore((s) => s.uploadDocumentFile);
	const [type, setType] = (0, import_react.useState)(presetType || replaceOf?.type || "Passport");
	const [name, setName] = (0, import_react.useState)(replaceOf?.name || defaultDocumentName(presetType || "Passport", student.name));
	const [description, setDescription] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [duplicate, setDuplicate] = (0, import_react.useState)(null);
	const inputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const nextType = replaceOf?.type || presetType || "Passport";
		setType(nextType);
		setName(replaceOf?.name || defaultDocumentName(nextType, student.name));
		setPhase("idle");
		setProgress(0);
		setError("");
		setDuplicate(null);
	}, [
		open,
		presetType,
		replaceOf,
		student.name
	]);
	const reset = () => {
		setFile(null);
		setError("");
		setProgress(0);
		setPhase("idle");
		setDuplicate(null);
		setDescription("");
	};
	const onFile = (0, import_react.useCallback)((f) => {
		if (!f) return;
		const v = validateUploadFile(f);
		if (v) {
			setError(v);
			setFile(null);
			return;
		}
		setError("");
		setFile(f);
	}, []);
	async function runUpload(opts) {
		if (!file) {
			setError("Choose a file to upload.");
			return;
		}
		setPhase("uploading");
		setProgress(8);
		const dataUrl = await readFile(file);
		await animateProgress(setProgress);
		const result = upload({
			studentId: student.id,
			type,
			name: name.trim() || defaultDocumentName(type, student.name),
			fileName: file.name,
			fileType: file.type || "application/octet-stream",
			fileSize: formatBytes(file.size),
			dataUrl,
			studentInstruction: description.trim() || void 0,
			replaceExistingId: opts?.replaceExistingId ?? replaceOf?.id,
			asNewVersionOf: opts?.asNewVersionOf,
			forceNew: opts?.forceNew,
			fromStudent: asStudent,
			actorName: asStudent ? student.name : void 0,
			actorRole: asStudent ? "student" : void 0
		});
		if (!result.ok) {
			if (result.existing) {
				setPhase("idle");
				setProgress(0);
				setDuplicate(result.existing);
				return;
			}
			setPhase("fail");
			setError(result.error);
			return;
		}
		setPhase("done");
		toast.success(replaceOf ? "Document replaced" : "Document uploaded");
		onUploaded?.(result.document);
		window.setTimeout(() => {
			onOpenChange(false);
			reset();
		}, 650);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange: (v) => {
			if (!v) reset();
			onOpenChange(v);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "w-full overflow-y-auto p-0 sm:max-w-md max-sm:inset-x-0 max-sm:bottom-0 max-sm:top-auto max-sm:h-[92dvh] max-sm:max-w-none max-sm:rounded-t-2xl max-sm:border-t max-sm:data-[state=closed]:slide-out-to-bottom max-sm:data-[state=open]:slide-in-from-bottom",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: replaceOf ? "Replace document" : "Upload document" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: replaceOf ? "The new file will become the latest version." : "Files stay in this browser session for preview. Access is controlled by your counselor." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Document type",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: type,
							onValueChange: (v) => {
								setType(v);
								setName(defaultDocumentName(v, student.name));
							},
							disabled: Boolean(replaceOf),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DOCUMENT_TYPE_CATALOG.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: d.type,
								children: d.type
							}, d.type)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Document name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Description",
						hint: "Optional",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 3
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
						file,
						onFile,
						inputRef,
						disabled: phase === "uploading"
					}),
					file && (phase === "uploading" || phase === "done") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadProgress, {
						fileName: file.name,
						progress,
						complete: phase === "done"
					}),
					phase === "fail" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-destructive",
								children: "Unable to upload document."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted-foreground",
								children: error || "Please try again."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "mt-3",
								onClick: () => void runUpload(),
								children: "Retry"
							})
						]
					}),
					error && phase === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-micro text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-micro text-muted-foreground",
						children: [
							"Accepted: ",
							FILE_RULES.allowedExtensions.join(", "),
							" · up to ",
							formatBytes(FILE_RULES.maxBytes)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => onOpenChange(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: phase === "uploading",
							onClick: () => void runUpload(),
							children: replaceOf ? "Upload replacement" : "Upload"
						})]
					})
				]
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DuplicateChooser, {
		open: !!duplicate,
		type: duplicate?.type ?? type,
		onCancel: () => setDuplicate(null),
		onReplace: () => {
			const id = duplicate?.id;
			setDuplicate(null);
			if (id) runUpload({ replaceExistingId: id });
		},
		onVersion: () => {
			const id = duplicate?.id;
			setDuplicate(null);
			if (id) runUpload({
				asNewVersionOf: id,
				forceNew: false
			});
		}
	})] });
}
function DuplicateChooser({ open, type, onCancel, onReplace, onVersion }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[60] flex items-end justify-center bg-foreground/20 p-4 sm:items-center",
		onKeyDown: (e) => {
			if (e.key === "Escape") onCancel();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "dup-title",
			className: "w-full max-w-md rounded-xl bg-card p-6 shadow-popover",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					id: "dup-title",
					className: "text-base font-semibold",
					children: [
						"A ",
						type,
						" document already exists."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Choose how this file should be stored."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: onCancel,
							children: "Cancel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: onVersion,
							children: "Upload as new version"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onReplace,
							children: "Replace existing"
						})
					]
				})
			]
		})
	});
}
function DropZone({ file, onFile, inputRef, disabled }) {
	const [over, setOver] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		onDragOver: (e) => {
			e.preventDefault();
			setOver(true);
		},
		onDragLeave: () => setOver(false),
		onDrop: (e) => {
			e.preventDefault();
			setOver(false);
			onFile(e.dataTransfer.files?.[0] ?? null);
		},
		className: cn("flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed px-4 py-8 text-center transition-colors duration-150", over ? "border-primary bg-accent" : "border-border bg-secondary/30"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Drag & drop your file here"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-muted-foreground",
				children: "or"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				className: "sr-only",
				accept: FILE_RULES.allowedExtensions.join(","),
				onChange: (e) => onFile(e.target.files?.[0] ?? null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				disabled,
				onClick: () => inputRef.current?.click(),
				children: "Choose file"
			}),
			file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-micro text-muted-foreground",
				children: [
					file.name,
					" · ",
					formatBytes(file.size)
				]
			})
		]
	});
}
function readFile(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result ?? ""));
		reader.onerror = () => reject(/* @__PURE__ */ new Error("read failed"));
		reader.readAsDataURL(file);
	});
}
function animateProgress(setProgress) {
	return new Promise((resolve) => {
		let n = 8;
		const t = window.setInterval(() => {
			n = Math.min(92, n + 10 + Math.random() * 12);
			setProgress(n);
			if (n >= 82) {
				window.clearInterval(t);
				setProgress(100);
				resolve();
			}
		}, 90);
	});
}
function DocumentPreview({ doc }) {
	const data = getFileData(doc.id);
	const previewable = canPreview(doc.fileType, doc.fileName);
	const isImage = (doc.fileType || "").startsWith("image/") || /\.(png|jpe?g|webp|gif)$/i.test(doc.fileName || "");
	const isPdf = (doc.fileType || "") === "application/pdf" || /\.pdf$/i.test(doc.fileName || "");
	function download() {
		if (!data) return;
		const a = document.createElement("a");
		a.href = data;
		a.download = doc.fileName || `${doc.type}.pdf`;
		a.click();
	}
	if (!doc.fileName) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-56 flex-col items-center justify-center rounded-lg bg-secondary/50 text-sm text-muted-foreground",
		children: "No file uploaded yet"
	});
	if (!data || !previewable) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-56 flex-col items-center justify-center gap-3 rounded-lg bg-secondary/50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Preview unavailable"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-muted-foreground",
				children: doc.fileName
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: download,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Download document"]
			})
		]
	});
	if (isImage) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden rounded-lg border bg-secondary/30",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: data,
			alt: doc.fileName,
			className: "max-h-[420px] w-full object-contain"
		})
	});
	if (isPdf) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		title: doc.fileName,
		src: data,
		className: "h-[420px] w-full rounded-lg border bg-card"
	});
	return null;
}
//#endregion
export { DocumentUpload as n, Progress as r, DocumentPreview as t };
