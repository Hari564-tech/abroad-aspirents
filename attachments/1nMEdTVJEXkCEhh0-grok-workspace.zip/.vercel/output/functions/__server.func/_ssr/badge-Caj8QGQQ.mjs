import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-Caj8QGQQ.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-md px-2 py-0.5 text-micro font-medium ring-1 ring-inset tabular-nums", {
	variants: { variant: {
		default: "bg-primary/10 text-primary ring-primary/15",
		secondary: "bg-secondary text-muted-foreground ring-border",
		success: "bg-success/10 text-success ring-success/15",
		warning: "bg-warning/10 text-warning ring-warning/15",
		danger: "bg-destructive/10 text-destructive ring-destructive/15",
		info: "bg-info/10 text-info ring-info/15",
		private: "bg-private/10 text-private ring-private/15",
		outline: "text-foreground ring-border"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
