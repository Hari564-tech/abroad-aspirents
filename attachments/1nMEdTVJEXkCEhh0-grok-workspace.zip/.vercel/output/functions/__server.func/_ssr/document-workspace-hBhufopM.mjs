import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { B as FilePlus2, G as Download, H as EyeOff, M as Link2, O as Mail, U as ExternalLink, V as Eye, W as Ellipsis, _ as RotateCcw, a as Upload, m as ShieldAlert, nt as Check, p as ShieldCheck, q as Copy, tt as ChevronDown, v as RefreshCw, x as Plus, y as QrCode, z as FileText } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as relativeShort, S as isOverdue, T as portalUrl, c as useAppStore, d as DEFAULT_PORTAL_PERMISSIONS, f as DOCUMENT_TYPE_CATALOG, l as getFileData, m as REJECT_REASONS, v as documentStats, w as portalEffectiveStatus, x as groupedByCategory, y as expiryFromPreset } from "./router-z_xU0oK5.mjs";
import { t as cn } from "./utils-Bcse6IW9.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { i as DropdownMenuItem, o as DropdownMenuTrigger, r as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-CuItBiKD.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { a as formatShortDate, n as formatDateTime } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { t as EmptyState } from "./empty-state-CivQ_9Zu.mjs";
import { t as Card } from "./card-B_I_naJs.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-CnGpc8qo.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-B8yEom4G.mjs";
import { a as SheetTitle, i as SheetHeader, n as SheetContent, r as SheetDescription, t as Sheet } from "./sheet-CY9M7c4U.mjs";
import { t as Input } from "./input-DeY9zAIK.mjs";
import { t as DocumentStatusBadge } from "./document-status-badge-Xjx6MsLi.mjs";
import { t as Switch } from "./switch-95CbCe8f.mjs";
import { t as FormField } from "./form-field-LURrrOeP.mjs";
import { t as Textarea } from "./textarea-CMcQQGlC.mjs";
import { n as DocumentUpload, r as Progress, t as DocumentPreview } from "./document-preview-CyV17_st.mjs";
import { n as RadioGroupIndicator, r as RadioGroupItem$1, t as RadioGroup$1 } from "../_libs/radix-ui__react-radio-group.mjs";
import { t as renderSVG } from "../_libs/uqr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/document-workspace-hBhufopM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PasswordField({ label, value, onChange, warning = true, className }) {
	const [show, setShow] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid gap-1.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium",
				children: label
			}), warning && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 text-micro text-warning",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-3" }), "Sensitive"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: show ? "text" : "password",
				value,
				onChange: (e) => onChange?.(e.target.value),
				autoComplete: "off",
				className: "pr-20 font-mono"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-1 flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "icon",
					variant: "ghost",
					className: "size-7",
					onClick: () => setShow((s) => !s),
					"aria-label": show ? "Hide" : "Reveal",
					children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "icon",
					variant: "ghost",
					className: "size-7",
					"aria-label": "Copy",
					onClick: async () => {
						await navigator.clipboard.writeText(value);
						setCopied(true);
						toast.message("Copied to clipboard — handle credentials carefully.");
						setTimeout(() => setCopied(false), 1500);
					},
					children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
				})]
			})]
		})]
	});
}
function actionFor(doc) {
	if (doc.status === "pending" || doc.status === "rejected" || doc.status === "expired") return {
		label: "Upload",
		kind: "upload"
	};
	if (doc.status === "under_review" || doc.status === "uploaded") return {
		label: "Review",
		kind: "review"
	};
	return {
		label: "View",
		kind: "view"
	};
}
function DocumentRow({ doc, onView, onUpload, onReview }) {
	const overdue = isOverdue(doc.dueDate, doc.status);
	const action = actionFor(doc);
	const run = action.kind === "upload" ? onUpload : action.kind === "review" ? onReview : onView;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-1 items-center gap-2 border-b px-3 py-2.5 last:border-0 sm:grid-cols-[1.2fr_0.7fr_0.7fr_0.9fr_0.8fr_0.7fr_0.7fr_auto] sm:gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: doc.universityName ? `${doc.type} — ${doc.universityName}` : doc.type
			}), doc.universityName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-muted-foreground",
				children: doc.course
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden text-sm text-muted-foreground sm:block",
				children: doc.category
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: doc.required ? "Required" : "Optional"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: doc.status }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden text-sm text-muted-foreground sm:block",
				children: doc.uploadedBy ?? "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden text-sm text-muted-foreground sm:block",
				children: relativeShort(doc.updatedAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("hidden text-sm sm:block", overdue && "font-medium text-destructive"),
				children: doc.dueDate ? formatShortDate(doc.dueDate) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "xs",
				variant: "outline",
				onClick: run,
				children: [action.kind === "upload" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), action.label]
			})
		]
	});
}
function DocumentCard({ doc, onView, onUpload, onReview }) {
	const overdue = isOverdue(doc.dueDate, doc.status);
	const needsUpload = doc.status === "pending" || doc.status === "rejected" || doc.status === "expired";
	const needsReview = doc.status === "under_review" || doc.status === "uploaded";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border bg-card p-3 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: doc.universityName ? `${doc.type} — ${doc.universityName}` : doc.type
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-micro text-muted-foreground",
					children: [
						doc.category,
						" · ",
						doc.required ? "Required" : "Optional"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: doc.status })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 grid grid-cols-2 gap-2 text-micro text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["By ", doc.uploadedBy ?? "—"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: relativeShort(doc.updatedAt) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn(overdue && "font-medium text-destructive"),
						children: doc.dueDate ? `Due ${formatShortDate(doc.dueDate)}` : "No due date"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["v", doc.version || "—"] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				className: "mt-3 w-full",
				onClick: needsUpload ? onUpload : needsReview ? onReview : onView,
				children: [needsUpload ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), needsUpload ? "Upload" : needsReview ? "Review" : "View"]
			})
		]
	});
}
function DocumentCategory({ category, items, onAdd, onView, onUpload, onReview }) {
	const [open, setOpen] = (0, import_react.useState)(true);
	const done = items.filter((d) => d.status === "verified" || d.status === "uploaded" || d.status === "under_review").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-xl bg-card shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 px-3 py-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex min-w-0 flex-1 items-center gap-2 text-left",
				onClick: () => setOpen((v) => !v),
				"aria-expanded": open,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 text-muted-foreground transition-transform duration-150", !open && "-rotate-90") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: category
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-micro text-muted-foreground",
						children: [
							done,
							"/",
							items.length
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "xs",
				variant: "ghost",
				onClick: onAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Add document"]
			})]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden border-t sm:block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1.2fr_0.7fr_0.7fr_0.9fr_0.8fr_0.7fr_0.7fr_auto] gap-3 px-3 py-2 text-micro font-medium text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Document" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Category" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Required" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Uploaded by" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Updated" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Due" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				}),
				items.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentRow, {
					doc,
					onView: () => onView(doc),
					onUpload: () => onUpload(doc),
					onReview: () => onReview(doc)
				}, doc.id)),
				items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-4 text-sm text-muted-foreground",
					children: "No documents in this category yet."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2 border-t p-3 sm:hidden",
			children: [items.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentCard, {
				doc,
				onView: () => onView(doc),
				onUpload: () => onUpload(doc),
				onReview: () => onReview(doc)
			}, doc.id)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No documents in this category yet."
			})]
		})] })]
	});
}
function DocumentChecklist({ documents, onAdd, onView, onUpload, onReview }) {
	const groups = groupedByCategory(documents);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3",
		children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentCategory, {
			category: g.category,
			items: g.items,
			onAdd: () => onAdd(g.category),
			onView,
			onUpload,
			onReview
		}, g.category))
	});
}
function DocumentVersionHistory({ documentId }) {
	const sorted = [...useAppStore((s) => s.documentVersions.filter((v) => v.documentId === documentId))].sort((a, b) => b.version - a.version);
	if (!sorted.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "No previous versions."
	});
	function open(id, fileName) {
		const data = getFileData(id);
		if (!data) return;
		const a = document.createElement("a");
		a.href = data;
		a.download = fileName;
		a.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
			children: "Version history"
		}), sorted.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between rounded-lg border px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium",
				children: ["v", v.version]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-micro text-muted-foreground",
				children: [
					formatShortDate(v.uploadedAt),
					" · Uploaded by ",
					v.uploadedBy
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "xs",
					variant: "ghost",
					onClick: () => open(v.id, v.fileName),
					disabled: !getFileData(v.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), " View"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "xs",
					variant: "ghost",
					onClick: () => open(v.id, v.fileName),
					disabled: !getFileData(v.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Download"]
				})]
			})]
		}, v.id))]
	});
}
function DocumentRejectModal({ open, onOpenChange, document }) {
	const reject = useAppStore((s) => s.rejectDocument);
	const [reason, setReason] = (0, import_react.useState)(REJECT_REASONS[1]);
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Reject document" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "The student will see the reason and can upload a replacement." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				label: "Reason",
				required: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: reason,
					onValueChange: setReason,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: REJECT_REASONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: r,
						children: r
					}, r)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				label: "Additional note",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: note,
					onChange: (e) => setNote(e.target.value),
					rows: 3
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => onOpenChange(false),
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "destructive",
				onClick: () => {
					if (!document) return;
					reject(document.id, reason, note.trim() || void 0);
					toast.success("Document rejected");
					onOpenChange(false);
					setNote("");
				},
				children: "Reject document"
			})] })
		] })
	});
}
function DocumentDetailsDrawer({ open, onOpenChange, document: doc, student, onReplace }) {
	const verify = useAppStore((s) => s.verifyDocument);
	const requestReplacement = useAppStore((s) => s.requestReplacement);
	const updateMeta = useAppStore((s) => s.updateDocumentMeta);
	const recordView = useAppStore((s) => s.recordDocumentView);
	const recordDownload = useAppStore((s) => s.recordDocumentDownload);
	const activities = useAppStore((s) => s.documentActivities);
	const { role } = useWorkspace();
	const [rejectOpen, setRejectOpen] = (0, import_react.useState)(false);
	const [replaceOpen, setReplaceOpen] = (0, import_react.useState)(false);
	const [reason, setReason] = (0, import_react.useState)("Current document is unclear.");
	const [message, setMessage] = (0, import_react.useState)("Please upload a clear high-resolution scan.");
	const [due, setDue] = (0, import_react.useState)("");
	if (!doc) return null;
	const events = activities.filter((a) => a.documentId === doc.id);
	const canReview = role === "admin" || role === "employee";
	const canVerify = canReview;
	function download() {
		const data = getFileData(doc.id);
		recordDownload(doc.id);
		if (!data) {
			toast.message("No file is stored in this session to download.");
			return;
		}
		const a = document.createElement("a");
		a.href = data;
		a.download = doc.fileName || `${doc.type}.pdf`;
		a.click();
		toast.success("Download started");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange: (v) => {
			if (v) recordView(doc.id);
			onOpenChange(v);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "w-full overflow-y-auto p-0 sm:max-w-lg max-sm:inset-0 max-sm:h-dvh max-sm:max-w-none max-sm:rounded-none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: doc.fileName || doc.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
					"Uploaded by ",
					doc.uploadedBy ?? "—",
					doc.uploadedAt ? ` · ${formatDateTime(doc.uploadedAt)}` : ""
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: download,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Download"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => onReplace(doc),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), " Replace"]
						}),
						canVerify && doc.status !== "verified" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => {
								verify(doc.id);
								toast.success("Document verified");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " Verify"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" }), " More"]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
							align: "end",
							children: [canReview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								onClick: () => setRejectOpen(true),
								children: "Reject"
							}), canReview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								onClick: () => setReplaceOpen(true),
								children: "Request replacement"
							})]
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentPreview, { doc }),
						doc.status === "rejected" && doc.rejectReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: "rejected" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2",
									children: ["Reason: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: doc.rejectReason
									})]
								}),
								doc.rejectNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted-foreground",
									children: doc.rejectNote
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
							children: "Document details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-2 gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Document name",
									value: doc.fileName || doc.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Document type",
									value: doc.type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Category",
									value: doc.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Student",
									value: student.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Student ID",
									value: student.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Uploaded by",
									value: doc.uploadedBy ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Uploaded on",
									value: doc.uploadedAt ? formatShortDate(doc.uploadedAt) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Status",
									value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: doc.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Version",
									value: doc.version ? `v${doc.version}` : "—"
								}),
								doc.universityName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "University",
									value: doc.universityName
								}),
								doc.course && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Course",
									value: doc.course
								})
							]
						})] }),
						canReview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
									children: "Notes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-micro font-medium",
										children: "Internal note"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-micro text-muted-foreground",
										children: "Visible only to employees and admins."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										defaultValue: doc.internalNote,
										onBlur: (e) => updateMeta(doc.id, { internalNote: e.target.value }),
										rows: 2
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-micro font-medium",
										children: "Student instruction"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-micro text-muted-foreground",
										children: "Shown in the student portal."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										defaultValue: doc.studentInstruction,
										onBlur: (e) => updateMeta(doc.id, { studentInstruction: e.target.value }),
										rows: 2
									})
								] })
							]
						}),
						canVerify && doc.status !== "verified" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => {
										verify(doc.id);
										toast.success("Document verified");
									},
									children: "Mark as verified"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setRejectOpen(true),
									children: "Reject"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setReplaceOpen(true),
									children: "Request replacement"
								})
							]
						}),
						replaceOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-semibold",
									children: "Request replacement"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mt-3 block text-micro text-muted-foreground",
									children: "Reason"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "mt-1 h-9 w-full rounded-md border bg-background px-3 text-sm",
									value: reason,
									onChange: (e) => setReason(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mt-3 block text-micro text-muted-foreground",
									children: "Message to student"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm",
									rows: 3,
									value: message,
									onChange: (e) => setMessage(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mt-3 block text-micro text-muted-foreground",
									children: "Due date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									className: "mt-1 h-9 w-full rounded-md border bg-background px-3 text-sm",
									value: due,
									onChange: (e) => setDue(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setReplaceOpen(false),
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => {
											requestReplacement(doc.id, reason, message, due ? new Date(due).toISOString() : void 0);
											toast.success("Request sent");
											setReplaceOpen(false);
										},
										children: "Send request"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentVersionHistory, { documentId: doc.id }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
							children: "Activity"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
							className: "mt-3 grid gap-3",
							children: [events.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No activity yet."
							}), events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-medium",
									children: [
										e.actor,
										" ",
										e.action
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-micro text-muted-foreground",
									children: formatDateTime(e.timestamp)
								})]
							}, e.id))]
						})] })
					]
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentRejectModal, {
		open: rejectOpen,
		onOpenChange: setRejectOpen,
		document: doc
	})] });
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-0.5 font-medium",
		children: value
	})] });
}
function DocumentRequestModal({ open, onOpenChange, student, defaultType }) {
	const request = useAppStore((s) => s.requestDocument);
	const [type, setType] = (0, import_react.useState)(defaultType ?? "Transcript");
	const [required, setRequired] = (0, import_react.useState)(true);
	const [priority, setPriority] = (0, import_react.useState)("high");
	const [due, setDue] = (0, import_react.useState)("");
	const [instruction, setInstruction] = (0, import_react.useState)("Please upload the latest official transcript.");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => {
			onOpenChange(v);
			if (v && defaultType) setType(defaultType);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Request document" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "The request appears in the student document portal." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Document",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: type,
							onValueChange: setType,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DOCUMENT_TYPE_CATALOG.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: d.type,
								children: d.type
							}, d.type)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between rounded-lg border px-3 py-2 text-sm",
						children: ["Required", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: required,
							onCheckedChange: (v) => {
								setRequired(!!v);
								setPriority(v ? "high" : "optional");
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Priority",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: priority,
							onValueChange: (v) => setPriority(v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "high",
									children: "High"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "normal",
									children: "Normal"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "optional",
									children: "Optional"
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Due date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: due,
							onChange: (e) => setDue(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "Student instruction",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: instruction,
							onChange: (e) => setInstruction(e.target.value),
							rows: 3
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => onOpenChange(false),
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					request({
						studentId: student.id,
						type,
						required,
						priority,
						dueDate: due ? new Date(due).toISOString() : void 0,
						studentInstruction: instruction.trim() || void 0
					});
					toast.success("Request sent");
					onOpenChange(false);
				},
				children: "Send request"
			})] })
		] })
	});
}
var RadioGroup = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
	className: cn("grid gap-2", className),
	...props,
	ref
}));
RadioGroup.displayName = RadioGroup$1.displayName;
var RadioGroupItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem$1, {
	ref,
	className: cn("aspect-square size-4 rounded-full border border-input text-primary shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:border-primary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupIndicator, {
		className: "flex items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary" })
	})
}));
RadioGroupItem.displayName = RadioGroupItem$1.displayName;
function PortalAccessSettings({ method, email, onMethod, onEmail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
			className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
			children: "Access method"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
			value: method,
			onValueChange: (v) => onMethod(v),
			className: "mt-2 gap-2",
			children: [
				[
					"email_only",
					"Email only",
					"Student must use the configured email address to access the document portal."
				],
				[
					"link_only",
					"Link only",
					"Anyone with the generated link can access this student's document portal."
				],
				[
					"email_and_link",
					"Email + link",
					"The student needs the portal link and the configured email address."
				]
			].map(([value, label, hint]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer gap-3 rounded-lg border px-3 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
					value,
					className: "mt-0.5"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-medium",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-micro text-muted-foreground",
					children: hint
				})] })]
			}, value))
		})] }), method !== "link_only" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
			label: "Student email",
			required: method === "email_only",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "email",
				value: email,
				onChange: (e) => onEmail(e.target.value)
			})
		})]
	});
}
var ITEMS = [
	{
		key: "view",
		label: "View documents"
	},
	{
		key: "upload",
		label: "Upload documents"
	},
	{
		key: "replace",
		label: "Replace documents"
	},
	{
		key: "delete",
		label: "Delete documents"
	},
	{
		key: "download",
		label: "Download documents"
	}
];
function PortalPermissionSettings({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
		children: "Student permissions"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 divide-y rounded-lg border",
		children: ITEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center justify-between px-3 py-2.5 text-sm",
			children: [item.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				checked: value[item.key],
				onCheckedChange: (v) => onChange({
					...value,
					[item.key]: !!v
				})
			})]
		}, item.key))
	})] });
}
function PortalLink({ token, studentId, showOpen = true }) {
	const appendAudit = useAppStore((s) => s.appendAudit);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const url = portalUrl(token);
	async function copy() {
		try {
			await navigator.clipboard.writeText(url);
			setCopied(true);
			toast.success("Link copied");
			appendAudit({
				action: "PORTAL_LINK_COPIED",
				module: "Documents",
				recordId: studentId,
				details: "Copied student portal link",
				severity: "INFO"
			});
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			toast.error("Could not copy link");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 sm:flex-row sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "min-w-0 flex-1 truncate rounded-md bg-secondary px-3 py-2 font-mono text-xs",
			children: url
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => void copy(),
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Link copied" : "Copy link"]
			}), showOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "outline",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: url,
					target: "_blank",
					rel: "noreferrer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" }), " Open portal"]
				})
			})]
		})]
	});
}
function qrSvg(text, size = 180) {
	return renderSVG(text, {
		pixelSize: 8,
		whiteColor: "#ffffff",
		blackColor: "#111827"
	}).replace("<svg ", `<svg width="${size}" height="${size}" `);
}
function qrSvgDataUri(text, size = 180) {
	return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(qrSvg(text, size))}`;
}
function PortalQRCode({ token, size = 180 }) {
	const src = qrSvgDataUri(portalUrl(token), size);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 rounded-xl border bg-card p-5 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "QR code for the student document portal",
			width: size,
			height: size,
			className: "rounded-md bg-white p-2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Scan to open the student document portal."
		})]
	});
}
function PortalActivity({ portalId }) {
	const logs = useAppStore((s) => s.portalAccessLogs.filter((l) => l.portalId === portalId));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
		children: "Portal activity"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		className: "mt-3 grid gap-3",
		children: [logs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "No portal activity yet."
		}), logs.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				l.actor,
				" ",
				l.action
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-micro text-muted-foreground",
				children: formatDateTime(l.timestamp)
			})]
		}, l.id))]
	})] });
}
function PortalCreatedSuccess({ student, portal, stats, expiresLabel, onEmail, onQr, onEdit, onRevoke, onDone, onPrint, onRegenerate }) {
	const status = portalEffectiveStatus(portal);
	const methodLabel = portal.accessMethod === "email_only" ? "Email only" : portal.accessMethod === "link_only" ? "Link only" : "Email + Link";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-9 items-center justify-center rounded-full bg-success/10 text-success",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Student portal created"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						student.name,
						" · ",
						student.id
					]
				})] })]
			}),
			status === "revoked" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border px-3 py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mr-2 inline-block size-2 rounded-full bg-destructive" }),
					" Revoked",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "ml-3",
						onClick: onRegenerate,
						children: "Generate new link"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted-foreground",
						children: "Documents requested"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-semibold tabular-nums",
						children: stats.requiredTotal
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted-foreground",
						children: "Currently submitted"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-semibold tabular-nums",
						children: stats.complete
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted-foreground",
						children: "Access method"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium",
						children: methodLabel
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted-foreground",
						children: "Expires"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium",
						children: expiresLabel
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs text-muted-foreground",
				children: "Portal link"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalLink, {
				token: portal.token,
				studentId: student.id
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onEmail,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), " Send email"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onQr,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-4" }), " Generate QR"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onPrint,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }), " Instructions"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onEdit,
						children: "Edit access"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onRegenerate,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), " Regenerate"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "destructive",
						onClick: onRevoke,
						children: "Revoke"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: onDone,
						children: "Done"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro text-muted-foreground",
				children: "Access is configured by your counselor. This prototype does not claim production-grade security."
			})
		]
	});
}
function printPortalInstructions(student, portal, stats) {
	const url = portalUrl(portal.token);
	const method = portal.accessMethod === "email_only" ? "Email only" : portal.accessMethod === "link_only" ? "Link only" : "Email + Link";
	const qr = qrSvgDataUri(url, 160);
	const html = `<!doctype html>
<html><head><title>Meridian — Student document portal</title>
<style>
  @page { size: A4; margin: 18mm; }
  body { font-family: Inter, ui-sans-serif, system-ui, sans-serif; color: #111827; }
  .brand { display:flex; align-items:center; gap:12px; }
  .mark { width:32px; height:32px; background:#2563eb; border-radius:8px; }
  h1 { font-size: 22px; margin: 8px 0 4px; }
  h2 { font-size: 11px; letter-spacing: .16em; text-transform: uppercase; color:#6b7280; margin: 28px 0 10px; }
  .meta { display:grid; grid-template-columns: 1fr 1fr; gap: 12px 24px; font-size:14px; }
  .k { color:#6b7280; font-size:12px; }
  ol { padding-left: 18px; line-height: 1.7; }
  footer { margin-top: 48px; font-size: 12px; color:#6b7280; border-top:1px solid #e5e7eb; padding-top:12px; display:flex; justify-content:space-between; }
  .row { display:flex; gap:32px; align-items:flex-start; }
  code { font-size:12px; }
</style></head>
<body>
  <div class="brand"><div class="mark"></div><div><strong>MERIDIAN</strong><div class="k">Student operations</div></div></div>
  <h1>Student document upload portal</h1>
  <p class="k">Controlled access · configured by your counselor</p>
  <div class="row">
    <div class="meta" style="flex:1">
      <div><div class="k">Student</div><div>${student.name}</div></div>
      <div><div class="k">Student ID</div><div>${student.id}</div></div>
      <div><div class="k">Portal</div><div><code>${url}</code></div></div>
      <div><div class="k">Access</div><div>${method}</div></div>
      <div><div class="k">Expires</div><div>${portal.expiresAt ? formatShortDate(portal.expiresAt) : "Never"}</div></div>
      <div><div class="k">Documents requested</div><div>${stats.requiredTotal}</div></div>
      <div><div class="k">Submitted</div><div>${stats.complete}</div></div>
      <div><div class="k">Remaining</div><div>${stats.remaining}</div></div>
    </div>
    <img src="${qr}" width="140" height="140" alt="Portal QR" />
  </div>
  <h2>Instructions</h2>
  <ol>
    <li>Open the portal link.</li>
    <li>Verify your email if requested.</li>
    <li>Upload the required documents.</li>
    <li>Review your submissions.</li>
    <li>Replace any document requested by your counselor.</li>
  </ol>
  <footer>
    <span>Meridian Student Operations</span>
    <span>Generated ${formatShortDate((/* @__PURE__ */ new Date()).toISOString())}</span>
  </footer>
</body></html>`;
	const w = window.open("", "_blank", "noopener,noreferrer,width=900,height=1100");
	if (!w) return;
	w.document.write(html);
	w.document.close();
	w.focus();
	window.setTimeout(() => w.print(), 400);
}
function PortalShareDrawer({ open, onOpenChange, student, startCreated }) {
	const portals = useAppStore((s) => s.portals);
	const documents = useAppStore((s) => s.documents.filter((d) => d.studentId === student.id));
	const createPortal = useAppStore((s) => s.createPortal);
	const updatePortal = useAppStore((s) => s.updatePortal);
	const revokePortal = useAppStore((s) => s.revokePortal);
	const regeneratePortal = useAppStore((s) => s.regeneratePortal);
	const appendAudit = useAppStore((s) => s.appendAudit);
	const existing = (0, import_react.useMemo)(() => portals.find((p) => p.studentId === student.id && portalEffectiveStatus(p) !== "expired") ?? portals.find((p) => p.studentId === student.id), [portals, student.id]);
	const [method, setMethod] = (0, import_react.useState)(existing?.accessMethod ?? "email_and_link");
	const [email, setEmail] = (0, import_react.useState)(existing?.email ?? student.email);
	const [permissions, setPermissions] = (0, import_react.useState)(existing?.permissions ?? { ...DEFAULT_PORTAL_PERMISSIONS });
	const [expiry, setExpiry] = (0, import_react.useState)("7d");
	const [customExpiry, setCustomExpiry] = (0, import_react.useState)("");
	const [phase, setPhase] = (0, import_react.useState)(startCreated && existing ? "created" : "form");
	const [ticks, setTicks] = (0, import_react.useState)([
		false,
		false,
		false
	]);
	const [portalId, setPortalId] = (0, import_react.useState)(existing?.id);
	const [revokeOpen, setRevokeOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const current = portals.find((p) => p.studentId === student.id && portalEffectiveStatus(p) !== "expired") ?? portals.find((p) => p.studentId === student.id);
		setEmail(current?.email ?? student.email);
		setMethod(current?.accessMethod ?? "email_and_link");
		setPermissions(current?.permissions ?? { ...DEFAULT_PORTAL_PERMISSIONS });
		setPortalId(current?.id);
		if (startCreated && current) setPhase("created");
		else if (current && portalEffectiveStatus(current) === "active") setPhase("created");
		else setPhase("form");
	}, [open]);
	const portal = portals.find((p) => p.id === portalId) ?? existing;
	const stats = documentStats(documents);
	const expiresLabel = portal?.expiresAt ? formatShortDate(portal.expiresAt) : "Never";
	function simulateCreate(existingPortal = false) {
		setPhase("creating");
		setTicks([
			false,
			false,
			false
		]);
		window.setTimeout(() => setTicks([
			true,
			false,
			false
		]), 280);
		window.setTimeout(() => setTicks([
			true,
			true,
			false
		]), 560);
		window.setTimeout(() => setTicks([
			true,
			true,
			true
		]), 840);
		window.setTimeout(() => {
			let next = portal;
			if (!existingPortal || !next || next.status !== "active") {
				next = createPortal({
					studentId: student.id,
					accessMethod: method,
					email: method === "link_only" ? void 0 : email,
					expiresAt: expiryFromPreset(expiry, customExpiry ? new Date(customExpiry).toISOString() : void 0),
					permissions
				});
				setPortalId(next.id);
			} else updatePortal(next.id, {
				accessMethod: method,
				email,
				permissions,
				expiresAt: expiryFromPreset(expiry, customExpiry ? new Date(customExpiry).toISOString() : void 0),
				status: "active"
			});
			setPhase("created");
			toast.success("Portal created");
		}, 1100);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "w-full overflow-y-auto p-0 sm:max-w-lg max-sm:inset-x-0 max-sm:bottom-0 max-sm:top-auto max-sm:h-[94dvh] max-sm:max-w-none max-sm:rounded-t-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Student document portal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
				student.name,
				" · ",
				student.id
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 p-6",
				children: [
					phase === "creating" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "Creating student portal…"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-2 text-sm",
							children: [
								"Saving permissions",
								"Preparing document workspace",
								"Generating access link"
							].map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [ticks[i] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-4 rounded-full border" }), ticks[i] ? `✓ ${label}` : label]
							}, label))
						})]
					}),
					phase === "form" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						portal && portalEffectiveStatus(portal) === "revoked" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border px-3 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mr-2 inline-block size-2 rounded-full bg-destructive" }),
								" Revoked",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									className: "ml-3",
									onClick: () => simulateCreate(false),
									children: "Generate new link"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalAccessSettings, {
							method,
							email,
							onMethod: setMethod,
							onEmail: setEmail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalPermissionSettings, {
							value: permissions,
							onChange: setPermissions
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Portal expiration",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: expiry,
								onValueChange: (v) => setExpiry(v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "never",
										children: "Never"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "24h",
										children: "24 hours"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "7d",
										children: "7 days"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "30d",
										children: "30 days"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "custom",
										children: "Custom"
									})
								] })]
							})
						}),
						expiry === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "Expires on",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "datetime-local",
								value: customExpiry,
								onChange: (e) => setCustomExpiry(e.target.value)
							})
						}),
						expiry !== "never" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-micro text-muted-foreground",
							children: ["Expires ", formatShortDate(expiryFromPreset(expiry, customExpiry ? new Date(customExpiry).toISOString() : void 0) ?? (/* @__PURE__ */ new Date()).toISOString())]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => onOpenChange(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => simulateCreate(false),
								children: "Generate student upload link"
							})]
						}),
						portal && portalEffectiveStatus(portal) === "active" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 border-t pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalLink, {
								token: portal.token,
								studentId: student.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalActivity, { portalId: portal.id })]
						})
					] }),
					phase === "created" && portal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalCreatedSuccess, {
						student,
						portal,
						stats,
						expiresLabel,
						onCopyAudit: () => appendAudit({
							action: "PORTAL_LINK_COPIED",
							module: "Documents",
							recordId: student.id,
							details: "Copied student portal link",
							severity: "INFO"
						}),
						onEmail: () => setPhase("email"),
						onQr: () => setPhase("qr"),
						onEdit: () => setPhase("form"),
						onRevoke: () => setRevokeOpen(true),
						onDone: () => onOpenChange(false),
						onPrint: () => printPortalInstructions(student, portal, stats),
						onRegenerate: () => {
							const next = regeneratePortal(portal.id);
							if (next) {
								setPortalId(next.id);
								toast.success("Portal created");
							}
						}
					}),
					phase === "email" && portal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailComposer, {
						student,
						email: email || student.email,
						url: portalUrl(portal.token),
						onCancel: () => setPhase("created"),
						onSend: () => {
							appendAudit({
								action: "PORTAL_SHARED",
								module: "Documents",
								recordId: student.id,
								details: `Shared portal with ${email || student.email}`,
								severity: "SUCCESS"
							});
							toast.success("Email simulated successfully");
							setPhase("created");
						}
					}),
					phase === "qr" && portal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalQRCode, { token: portal.token }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setPhase("created"),
							children: "Back"
						})]
					})
				]
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
		open: revokeOpen,
		onOpenChange: setRevokeOpen,
		title: "Revoke student portal?",
		description: "The current link will no longer provide access to the document portal.",
		confirmLabel: "Revoke access",
		onConfirm: () => {
			if (portal) {
				revokePortal(portal.id);
				toast.success("Portal revoked");
				setPhase("form");
			}
		}
	})] });
}
function EmailComposer({ student, email, url, onCancel, onSend }) {
	const [to, setTo] = (0, import_react.useState)(email);
	const [subject, setSubject] = (0, import_react.useState)("Complete your Meridian document submission");
	const [message, setMessage] = (0, import_react.useState)(`Hello ${student.name.split(" ")[0]},\n\nPlease use the Meridian student document portal to upload your pending documents.\n\nPortal:\n${url}\n\nThank you,\nMeridian Student Operations`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Send document portal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				label: "To",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: to,
					onChange: (e) => setTo(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				label: "Subject",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: subject,
					onChange: (e) => setSubject(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				label: "Message",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 8,
					value: message,
					onChange: (e) => setMessage(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onCancel,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onSend,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), " Send email"]
				})]
			})
		]
	});
}
function DocumentWorkspace({ student, compactHeader = false, showPortalBanner = true, onCreatePortal }) {
	const documents = useAppStore((s) => s.documents.filter((d) => d.studentId === student.id));
	const portals = useAppStore((s) => s.portals);
	const seed = useAppStore((s) => s.seedStudentDocuments);
	const [uploadOpen, setUploadOpen] = (0, import_react.useState)(false);
	const [presetType, setPresetType] = (0, import_react.useState)();
	const [replaceOf, setReplaceOf] = (0, import_react.useState)();
	const [active, setActive] = (0, import_react.useState)(null);
	const [requestOpen, setRequestOpen] = (0, import_react.useState)(false);
	const [portalOpen, setPortalOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const uploadFlag = sessionStorage.getItem(`meridian-upload-${student.id}`);
		const portalFlag = sessionStorage.getItem(`meridian-portal-${student.id}`);
		if (uploadFlag) {
			sessionStorage.removeItem(`meridian-upload-${student.id}`);
			seed(student.id);
			setUploadOpen(true);
		}
		if (portalFlag) {
			sessionStorage.removeItem(`meridian-portal-${student.id}`);
			seed(student.id);
			setPortalOpen(true);
		}
	}, [student.id, seed]);
	const stats = (0, import_react.useMemo)(() => documentStats(documents), [documents]);
	const portal = portals.find((p) => p.studentId === student.id && portalEffectiveStatus(p) === "active") ?? portals.find((p) => p.studentId === student.id);
	function openPortal() {
		if (onCreatePortal) {
			onCreatePortal();
			return;
		}
		setPortalOpen(true);
	}
	if (documents.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			!compactHeader && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Documents",
				description: "Upload, manage and collect documents for this student.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: openPortal,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), " Generate student upload link"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Upload,
				title: "No documents uploaded yet.",
				description: "Upload a document or create a student upload portal.",
				actionLabel: "Upload document",
				onAction: () => {
					seed(student.id);
					setUploadOpen(true);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => {
						seed(student.id);
						openPortal();
					},
					children: "Generate portal"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentUpload, {
				open: uploadOpen,
				onOpenChange: setUploadOpen,
				student
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShareDrawer, {
				open: portalOpen,
				onOpenChange: setPortalOpen,
				student
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			compactHeader ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Documents"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Upload, manage and collect documents for this student."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setRequestOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePlus2, { className: "size-4" }), " Request document"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: openPortal,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), " Generate student upload link"]
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Documents",
				description: "Upload, manage and collect documents for this student.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => setRequestOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePlus2, { className: "size-4" }), " Request document"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: openPortal,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), " Generate student upload link"]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
							children: "Documents"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-lg font-semibold tabular-nums",
							children: [
								stats.complete,
								" / ",
								stats.requiredTotal,
								" complete"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [stats.remaining, " documents remaining"]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-x-4 gap-y-1 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-success",
								children: [
									"✓ ",
									stats.verified,
									" Verified"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-info",
								children: [
									"◷ ",
									stats.underReview,
									" Under Review"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									"! ",
									stats.pending,
									" Pending"
								]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: stats.percent,
					className: "mt-4 h-2"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total Documents",
						value: stats.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Uploaded",
						value: stats.uploaded
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Pending",
						value: stats.pending
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Under Review",
						value: stats.underReview
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Verified",
						value: stats.verified
					})
				]
			}),
			showPortalBanner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Student upload portal"
				}), portal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-micro capitalize text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `mr-1.5 inline-block size-1.5 rounded-full ${portalEffectiveStatus(portal) === "active" ? "bg-success" : "bg-destructive"}` }), portalEffectiveStatus(portal) === "active" ? "Active" : portalEffectiveStatus(portal)]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-micro text-muted-foreground",
					children: "No portal generated yet."
				})] }), portal && portalEffectiveStatus(portal) === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalLink, {
					token: portal.token,
					studentId: student.id
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: openPortal,
					children: "Generate new link"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentChecklist, {
				documents,
				onAdd: (category) => {
					const match = DOCUMENT_TYPE_CATALOG.find((d) => d.category === category);
					setPresetType(match?.type);
					setReplaceOf(void 0);
					setUploadOpen(true);
				},
				onView: (doc) => setActive(doc),
				onUpload: (doc) => {
					setPresetType(doc.type);
					setReplaceOf(doc.status === "pending" || doc.status === "rejected" ? doc : void 0);
					setUploadOpen(true);
				},
				onReview: (doc) => setActive(doc)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentUpload, {
				open: uploadOpen,
				onOpenChange: (v) => {
					setUploadOpen(v);
					if (!v) setReplaceOf(void 0);
				},
				student,
				presetType,
				replaceOf
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentDetailsDrawer, {
				open: !!active,
				onOpenChange: (v) => !v && setActive(null),
				document: active,
				student,
				onReplace: (doc) => {
					setActive(null);
					setReplaceOf(doc);
					setPresetType(doc.type);
					setUploadOpen(true);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentRequestModal, {
				open: requestOpen,
				onOpenChange: setRequestOpen,
				student
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShareDrawer, {
				open: portalOpen,
				onOpenChange: setPortalOpen,
				student
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xl font-semibold tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { PasswordField as n, PortalShareDrawer as r, DocumentWorkspace as t };
