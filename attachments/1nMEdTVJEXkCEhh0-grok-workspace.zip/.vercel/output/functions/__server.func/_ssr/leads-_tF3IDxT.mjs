import { t as LeadsPage } from "./leads-page-BmtNK3Sj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-_tF3IDxT.js
var SplitComponent = LeadsPage;
//#endregion
export { SplitComponent as component };
