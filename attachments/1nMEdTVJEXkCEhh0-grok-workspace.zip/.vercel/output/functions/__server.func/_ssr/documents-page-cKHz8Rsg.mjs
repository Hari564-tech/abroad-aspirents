import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Download, l as Trash2, p as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as statusLabel, M as DOCUMENT_CATEGORIES, c as useAppStore, v as documentStats } from "./router-z_xU0oK5.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { n as useWorkspace } from "./workspace-NrHasYwb.mjs";
import { a as formatShortDate } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { i as useStudentMap, r as useScopedIds } from "./scoped-BYNid1DS.mjs";
import { t as ConfirmDialog } from "./confirm-dialog-CnGpc8qo.mjs";
import { t as DocumentStatusBadge } from "./document-status-badge-Xjx6MsLi.mjs";
import { t as StatCard } from "./stat-card-0qMA4LOU.mjs";
import { t as DataTable } from "./data-table-CQHsEWvg.mjs";
import { t as FilterSelect } from "./filter-select-DRpDDDny.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-page-cKHz8Rsg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"pending",
	"uploaded",
	"under_review",
	"verified",
	"rejected",
	"expired"
];
function DocumentsPage() {
	const { documents } = useScopedIds();
	const students = useStudentMap();
	useAppStore((s) => s.employees);
	const verify = useAppStore((s) => s.verifyDocument);
	const remove = useAppStore((s) => s.deleteDocuments);
	const { base, role } = useWorkspace();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [country, setCountry] = (0, import_react.useState)("all");
	const [type, setType] = (0, import_react.useState)("all");
	const [uploadedBy, setUploadedBy] = (0, import_react.useState)("all");
	const [studentId, setStudentId] = (0, import_react.useState)("all");
	const [dateRange, setDateRange] = (0, import_react.useState)("all");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const types = (0, import_react.useMemo)(() => [...new Set(documents.map((d) => d.type))].sort(), [documents]);
	const uploaders = (0, import_react.useMemo)(() => [...new Set(documents.map((d) => d.uploadedBy).filter(Boolean))], [documents]);
	const studentOptions = (0, import_react.useMemo)(() => [...new Set(documents.map((d) => d.studentId))].map((id) => ({
		value: id,
		label: `${students[id]?.name ?? id} (${id})`
	})).sort((a, b) => a.label.localeCompare(b.label)), [documents, students]);
	const filtered = (0, import_react.useMemo)(() => {
		return documents.filter((d) => {
			const student = students[d.studentId];
			if (status !== "all" && d.status !== status) return false;
			if (category !== "all" && d.category !== category) return false;
			if (type !== "all" && d.type !== type) return false;
			if (uploadedBy !== "all" && d.uploadedBy !== uploadedBy) return false;
			if (studentId !== "all" && d.studentId !== studentId) return false;
			if (country !== "all" && student?.country !== country) return false;
			if (dateRange !== "all") {
				const t = new Date(d.updatedAt).getTime();
				const days = dateRange === "today" ? 1 : dateRange === "7d" ? 7 : 30;
				if (t < Date.now() - days * 864e5) return false;
			}
			if (q) {
				if (!`${student?.name ?? ""} ${d.studentId} ${d.name} ${d.type} ${d.fileName ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
			}
			return true;
		});
	}, [
		documents,
		students,
		status,
		category,
		type,
		uploadedBy,
		country,
		studentId,
		dateRange,
		q
	]);
	const kpis = (0, import_react.useMemo)(() => documentStats(documents), [documents]);
	const columns = (0, import_react.useMemo)(() => [
		{
			id: "student",
			header: "Student",
			cell: ({ row }) => {
				const s = students[row.original.studentId];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: s?.name ?? row.original.studentId
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-micro text-muted-foreground",
					children: row.original.studentId
				})] });
			}
		},
		{
			accessorKey: "type",
			header: "Document"
		},
		{
			accessorKey: "category",
			header: "Category"
		},
		{
			accessorKey: "status",
			header: "Status",
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: row.original.status })
		},
		{
			accessorKey: "uploadedBy",
			header: "Uploaded By",
			cell: ({ row }) => row.original.uploadedBy ?? "—"
		},
		{
			accessorKey: "updatedAt",
			header: "Updated",
			cell: ({ row }) => formatShortDate(row.original.updatedAt)
		},
		{
			id: "actions",
			header: "",
			enableSorting: false,
			cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "xs",
				variant: "ghost",
				onClick: (e) => {
					e.stopPropagation();
					navigate({ to: `${base}/students/${row.original.studentId}` });
				},
				children: "Open"
			})
		}
	], [
		students,
		base,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Documents",
				description: "Manage student documents across the organization."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 grid-cols-2 lg:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total Documents",
						value: kpis.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Pending Review",
						value: kpis.underReview + kpis.uploaded
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Verified",
						value: kpis.verified
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Rejected",
						value: kpis.rejected
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Student Uploads",
						value: kpis.studentUploads
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				data: filtered,
				columns,
				getRowId: (d) => d.id,
				searchPlaceholder: "Search documents…",
				globalFilter: q,
				onGlobalFilterChange: setQ,
				selectable: true,
				onRowClick: (d) => void navigate({ to: `${base}/students/${d.studentId}` }),
				emptyTitle: "No documents found",
				extraFilters: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: studentId,
						onChange: setStudentId,
						placeholder: "Student",
						options: studentOptions,
						className: "w-[220px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: country,
						onChange: setCountry,
						placeholder: "Country",
						options: [
							"Germany",
							"UK",
							"USA"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: type,
						onChange: setType,
						placeholder: "Document Type",
						options: types
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: category,
						onChange: setCategory,
						placeholder: "Category",
						options: [...DOCUMENT_CATEGORIES]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: status,
						onChange: setStatus,
						placeholder: "Status",
						options: STATUSES.map((s) => ({
							value: s,
							label: statusLabel(s)
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: uploadedBy,
						onChange: setUploadedBy,
						placeholder: "Uploaded By",
						options: uploaders
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
						value: dateRange,
						onChange: setDateRange,
						placeholder: "Date",
						options: [
							{
								value: "today",
								label: "Today"
							},
							{
								value: "7d",
								label: "Last 7 days"
							},
							{
								value: "30d",
								label: "Last 30 days"
							}
						]
					})
				] }),
				bulkActions: (selected, clear) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "xs",
						variant: "outline",
						onClick: () => {
							selected.forEach((d) => verify(d.id));
							toast.success("Document verified");
							clear();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5" }), " Mark verified"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "xs",
						variant: "outline",
						onClick: () => {
							toast.message("Download is available for files stored in this session.");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Download"]
					}),
					role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "xs",
						variant: "destructive",
						onClick: () => setPendingDelete(selected.map((d) => d.id)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Delete"]
					})
				] }),
				renderMobileCard: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: d.type
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-micro text-muted-foreground",
						children: students[d.studentId]?.name ?? d.studentId
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentStatusBadge, { status: d.status })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!pendingDelete,
				onOpenChange: (v) => !v && setPendingDelete(null),
				title: "Delete documents?",
				description: "This action cannot be undone.",
				confirmLabel: "Delete",
				onConfirm: () => {
					if (pendingDelete) {
						remove(pendingDelete);
						toast.success("Document deleted");
						setPendingDelete(null);
					}
				}
			})
		]
	});
}
//#endregion
export { DocumentsPage as t };
