import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Download, z as FileText } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { P as INTAKES, c as useAppStore, k as APPLICATION_STATUSES } from "./router-z_xU0oK5.mjs";
import { t as Button } from "./button-Dg_pds-p.mjs";
import { s as toCsv, t as downloadText } from "./format-DGBT4Fq1.mjs";
import { t as PageHeader } from "./page-header-DdUbVup6.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-B_I_naJs.mjs";
import { n as useEmployeeMap } from "./scoped-BYNid1DS.mjs";
import { t as FilterSelect } from "./filter-select-DRpDDDny.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-c0TW2LAn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REPORTS = [
	"Student Registration",
	"Employee Performance",
	"Application Funnel",
	"Payment Report",
	"University Report",
	"Visa Report",
	"Status Report"
];
function ReportsPage() {
	const students = useAppStore((s) => s.students);
	const applications = useAppStore((s) => s.applications);
	useAppStore((s) => s.payments);
	const universities = useAppStore((s) => s.universities);
	const employees = useAppStore((s) => s.employees);
	const appendAudit = useAppStore((s) => s.appendAudit);
	const empMap = useEmployeeMap();
	const [report, setReport] = (0, import_react.useState)(REPORTS[0]);
	const [country, setCountry] = (0, import_react.useState)("all");
	const [intake, setIntake] = (0, import_react.useState)("all");
	const [employee, setEmployee] = (0, import_react.useState)("all");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [generated, setGenerated] = (0, import_react.useState)(false);
	const rows = students.filter((s) => {
		if (country !== "all" && s.country !== country) return false;
		if (intake !== "all" && s.intake !== intake) return false;
		if (employee !== "all" && empMap[s.employeeId]?.name !== employee) return false;
		if (status !== "all" && s.status !== status) return false;
		return true;
	});
	function exportCsv() {
		downloadText(`${report.toLowerCase().replaceAll(" ", "-")}.csv`, toCsv(rows.map((s) => ({
			id: s.id,
			name: s.name,
			country: s.country,
			intake: s.intake,
			status: s.status,
			payment: s.paymentStatus
		}))));
		appendAudit({
			action: "EXPORT",
			module: "Reports",
			recordId: report,
			details: `Exported ${report}`,
			severity: "INFO"
		});
		toast.success("Report exported");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Reports",
				description: "Generate operational summaries for leadership reviews."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: report,
							onChange: setReport,
							placeholder: "Report",
							options: REPORTS,
							includeAll: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: country,
							onChange: setCountry,
							placeholder: "Country",
							options: [
								"Germany",
								"UK",
								"USA"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: intake,
							onChange: setIntake,
							placeholder: "Intake",
							options: INTAKES
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: employee,
							onChange: setEmployee,
							placeholder: "Employee",
							options: employees.filter((e) => e.role === "employee").map((e) => e.name)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSelect, {
							value: status,
							onChange: setStatus,
							placeholder: "Status",
							options: APPLICATION_STATUSES
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								setGenerated(true);
								toast.success("Report generated");
							},
							children: "Generate report"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: exportCsv,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Export CSV"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => {
								downloadText(`${report}.txt`, `${report}\nGenerated ${(/* @__PURE__ */ new Date()).toLocaleString()}\nRows: ${rows.length}`);
								toast.message("PDF export is simulated in this prototype.");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }), " Export PDF"]
						})
					]
				})]
			}),
			generated && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Matching students" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "text-2xl font-semibold tabular-nums",
						children: rows.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Applications" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "text-2xl font-semibold tabular-nums",
						children: applications.filter((a) => rows.some((s) => s.id === a.studentId)).length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Universities" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "text-2xl font-semibold tabular-nums",
						children: universities.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "sm:col-span-3 overflow-x-auto p-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-table",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-left text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b",
									children: [
										"ID",
										"Name",
										"Country",
										"Status",
										"Payment"
									].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-5 py-2",
										children: h
									}, h))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.slice(0, 12).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b last:border-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2 font-mono text-xs",
										children: s.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2",
										children: s.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2",
										children: s.country
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2",
										children: s.status
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-2",
										children: s.paymentStatus
									})
								]
							}, s.id)) })]
						})
					})
				]
			})
		]
	});
}
var SplitComponent = ReportsPage;
//#endregion
export { SplitComponent as component };
