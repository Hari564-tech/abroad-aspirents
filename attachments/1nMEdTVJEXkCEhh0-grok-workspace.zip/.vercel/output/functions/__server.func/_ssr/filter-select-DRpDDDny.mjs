import { F as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dpl4SA1s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/filter-select-DRpDDDny.js
var import_jsx_runtime = require_jsx_runtime();
function normalize(option) {
	return typeof option === "string" ? {
		value: option,
		label: option
	} : option;
}
function FilterSelect({ value, onChange, placeholder, options, allLabel = "All", includeAll = true, className }) {
	const items = options.map(normalize);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value,
		onValueChange: onChange,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
			className: className ?? "w-[160px]",
			"aria-label": placeholder,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [includeAll && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: "all",
			children: allLabel
		}), items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: item.value,
			children: item.label
		}, item.value))] })]
	});
}
//#endregion
export { FilterSelect as t };
