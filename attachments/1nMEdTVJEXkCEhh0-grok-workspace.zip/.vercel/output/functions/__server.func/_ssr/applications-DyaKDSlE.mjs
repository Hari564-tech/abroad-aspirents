import { t as ApplicationsPage } from "./applications-page-DXK4vr3X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-DyaKDSlE.js
var SplitComponent = ApplicationsPage;
//#endregion
export { SplitComponent as component };
