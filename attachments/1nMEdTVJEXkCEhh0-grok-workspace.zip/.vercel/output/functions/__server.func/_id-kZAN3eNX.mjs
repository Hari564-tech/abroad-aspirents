import { F as require_jsx_runtime } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as Route$6 } from "./_ssr/router-z_xU0oK5.mjs";
import { t as StudentDetailPage } from "./_ssr/student-detail-DeWrQk24.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-kZAN3eNX.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route$6.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentDetailPage, { studentId: id });
}
//#endregion
export { Page as component };
