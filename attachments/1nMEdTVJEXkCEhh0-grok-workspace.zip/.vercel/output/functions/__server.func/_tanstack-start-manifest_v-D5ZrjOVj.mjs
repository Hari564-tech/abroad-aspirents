//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D5ZrjOVj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/employee",
			"/login",
			"/student-upload/$token"
		],
		preloads: [
			"/assets/index-BJ0__AvW.js",
			"/assets/store-DTxJLMmn.js",
			"/assets/createLucideIcon-C7_OX_5N.js",
			"/assets/preload-helper-RO8LfUGp.js",
			"/assets/useMatch-zPdJOndR.js",
			"/assets/link-CJlukQI_.js",
			"/assets/useRouter-CQCgyO5f.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BJ0__AvW.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BDSnBrY0.js",
			"/assets/useNavigate-CMGY4Qok.js",
			"/assets/loading-state-W3LHC0Jz.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: [
			"/admin/applications",
			"/admin/audit",
			"/admin/dashboard",
			"/admin/documents",
			"/admin/leads",
			"/admin/payments",
			"/admin/reports",
			"/admin/settings",
			"/admin/universities",
			"/admin/",
			"/admin/employees/$id",
			"/admin/students/$id",
			"/admin/students/new",
			"/admin/employees/",
			"/admin/students/"
		],
		preloads: [
			"/assets/admin-CaDWM_QR.js",
			"/assets/useNavigate-CMGY4Qok.js",
			"/assets/app-shell-Br3oxTU-.js",
			"/assets/workspace-B5dk67PZ.js",
			"/assets/loading-state-W3LHC0Jz.js"
		]
	},
	"/employee": {
		filePath: "/workspace/src/routes/employee.tsx",
		children: [
			"/employee/applications",
			"/employee/dashboard",
			"/employee/documents",
			"/employee/leads",
			"/employee/payments",
			"/employee/profile",
			"/employee/universities",
			"/employee/",
			"/employee/students/$id",
			"/employee/students/new",
			"/employee/students/"
		],
		preloads: [
			"/assets/employee-BJzwtlbf.js",
			"/assets/useNavigate-CMGY4Qok.js",
			"/assets/app-shell-Br3oxTU-.js",
			"/assets/workspace-B5dk67PZ.js",
			"/assets/loading-state-W3LHC0Jz.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-C0NfVLwn.js",
			"/assets/useNavigate-CMGY4Qok.js",
			"/assets/logo-D7O22Msv.js",
			"/assets/button-JBi4SmFT.js",
			"/assets/loading-state-W3LHC0Jz.js",
			"/assets/checkbox-CYyN_oWV.js",
			"/assets/input-Bmev3P2V.js",
			"/assets/label-A-j2v3PO.js"
		]
	},
	"/admin/applications": {
		filePath: "/workspace/src/routes/admin/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-D48nBc_F.js", "/assets/applications-page-C8mIW9HF.js"]
	},
	"/admin/audit": {
		filePath: "/workspace/src/routes/admin/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-7SjkLgh6.js",
			"/assets/data-table-BBgoBUDR.js",
			"/assets/stat-card-DGjAgg_7.js",
			"/assets/format-BTt5poIw.js",
			"/assets/isToday-CfSkiR6L.js",
			"/assets/sheet-81lpDyir.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/status-badge-YicKUBlo.js",
			"/assets/filter-select-DvjKvv6M.js"
		]
	},
	"/admin/dashboard": {
		filePath: "/workspace/src/routes/admin/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-u2zpbYda.js",
			"/assets/download-psCFPw_Z.js",
			"/assets/file-text-Ca0_rO8z.js",
			"/assets/graduation-cap-ZYyVnajl.js",
			"/assets/stat-card-DGjAgg_7.js",
			"/assets/users-C4rW7jGg.js",
			"/assets/utils-zylJN5HD.js",
			"/assets/avatar-BnyUIOsG.js",
			"/assets/button-JBi4SmFT.js",
			"/assets/format-BTt5poIw.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/status-badge-YicKUBlo.js",
			"/assets/scoped-CpDcxSx7.js",
			"/assets/select-D39xhie0.js",
			"/assets/documents-attention-widget-Dd3-ZzZY.js"
		]
	},
	"/admin/documents": {
		filePath: "/workspace/src/routes/admin/documents.tsx",
		children: void 0,
		preloads: ["/assets/documents-Cpq6ZKJ6.js", "/assets/documents-page-DjVegRiI.js"]
	},
	"/admin/leads": {
		filePath: "/workspace/src/routes/admin/leads.tsx",
		children: void 0,
		preloads: ["/assets/leads-Cw2sqrrb.js", "/assets/leads-page-CWqthsLg.js"]
	},
	"/admin/payments": {
		filePath: "/workspace/src/routes/admin/payments.tsx",
		children: void 0,
		preloads: ["/assets/payments-C6EzgfSn.js", "/assets/payments-page-BCIi1YqP.js"]
	},
	"/admin/reports": {
		filePath: "/workspace/src/routes/admin/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-D0Gloj0X.js",
			"/assets/download-psCFPw_Z.js",
			"/assets/file-text-Ca0_rO8z.js",
			"/assets/button-JBi4SmFT.js",
			"/assets/format-BTt5poIw.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/scoped-CpDcxSx7.js",
			"/assets/filter-select-DvjKvv6M.js"
		]
	},
	"/admin/settings": {
		filePath: "/workspace/src/routes/admin/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-V1PWc1XV.js",
			"/assets/button-JBi4SmFT.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/input-Bmev3P2V.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/select-D39xhie0.js",
			"/assets/switch-Be_ZdLXZ.js",
			"/assets/tabs-CdZ-lPv2.js"
		]
	},
	"/admin/universities": {
		filePath: "/workspace/src/routes/admin/universities.tsx",
		children: void 0,
		preloads: ["/assets/universities-QgqDHF6e.js", "/assets/universities-page-DZVXnooh.js"]
	},
	"/employee/applications": {
		filePath: "/workspace/src/routes/employee/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-ByM4jG0y.js", "/assets/applications-page-C8mIW9HF.js"]
	},
	"/employee/dashboard": {
		filePath: "/workspace/src/routes/employee/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DQaAOIba.js",
			"/assets/stat-card-DGjAgg_7.js",
			"/assets/avatar-BnyUIOsG.js",
			"/assets/button-JBi4SmFT.js",
			"/assets/format-BTt5poIw.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/status-badge-YicKUBlo.js",
			"/assets/scoped-CpDcxSx7.js",
			"/assets/documents-attention-widget-Dd3-ZzZY.js"
		]
	},
	"/employee/documents": {
		filePath: "/workspace/src/routes/employee/documents.tsx",
		children: void 0,
		preloads: ["/assets/documents-Ch-uyY1g.js", "/assets/documents-page-DjVegRiI.js"]
	},
	"/employee/leads": {
		filePath: "/workspace/src/routes/employee/leads.tsx",
		children: void 0,
		preloads: ["/assets/leads-Bt0JUVDn.js", "/assets/leads-page-CWqthsLg.js"]
	},
	"/employee/payments": {
		filePath: "/workspace/src/routes/employee/payments.tsx",
		children: void 0,
		preloads: ["/assets/payments-BFPKyxHv.js", "/assets/payments-page-BCIi1YqP.js"]
	},
	"/employee/profile": {
		filePath: "/workspace/src/routes/employee/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-Bb5PHfcY.js",
			"/assets/stat-card-DGjAgg_7.js",
			"/assets/avatar-BnyUIOsG.js",
			"/assets/format-BTt5poIw.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/scoped-CpDcxSx7.js"
		]
	},
	"/employee/universities": {
		filePath: "/workspace/src/routes/employee/universities.tsx",
		children: void 0,
		preloads: ["/assets/universities-BBD0BP-B.js", "/assets/universities-page-DZVXnooh.js"]
	},
	"/student-upload/$token": {
		filePath: "/workspace/src/routes/student-upload.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/student-upload._token-CcyXSTfe.js",
			"/assets/check-CrF9mvFq.js",
			"/assets/upload--TgnN-cR.js",
			"/assets/utils-zylJN5HD.js",
			"/assets/logo-D7O22Msv.js",
			"/assets/button-JBi4SmFT.js",
			"/assets/format-BTt5poIw.js",
			"/assets/input-Bmev3P2V.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/confirm-dialog-By1f7TFd.js",
			"/assets/document-status-badge-AIGQWcqV.js",
			"/assets/document-preview-lOgvZQeC.js"
		]
	},
	"/admin/employees/$id": {
		filePath: "/workspace/src/routes/admin/employees/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-CXGjezAR.js",
			"/assets/empty-state-BlX9TEA5.js",
			"/assets/stat-card-DGjAgg_7.js",
			"/assets/avatar-BnyUIOsG.js",
			"/assets/format-BTt5poIw.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/card-Dbkf1lrt.js",
			"/assets/badge-0_uWSpCw.js",
			"/assets/status-badge-YicKUBlo.js",
			"/assets/switch-Be_ZdLXZ.js",
			"/assets/tabs-CdZ-lPv2.js"
		]
	},
	"/admin/students/$id": {
		filePath: "/workspace/src/routes/admin/students/$id.tsx",
		children: ["/admin/students/$id/edit"],
		preloads: ["/assets/_id-C9EAr8hC.js", "/assets/student-detail-CA1RxUOv.js"]
	},
	"/admin/students/new": {
		filePath: "/workspace/src/routes/admin/students/new.tsx",
		children: void 0,
		preloads: ["/assets/new-8Y_GL_8d.js", "/assets/student-form-CT0ez3q6.js"]
	},
	"/employee/students/$id": {
		filePath: "/workspace/src/routes/employee/students/$id.tsx",
		children: ["/employee/students/$id/edit"],
		preloads: ["/assets/_id-BjemRCP0.js", "/assets/student-detail-CA1RxUOv.js"]
	},
	"/employee/students/new": {
		filePath: "/workspace/src/routes/employee/students/new.tsx",
		children: void 0,
		preloads: ["/assets/new-DNAA8sRS.js", "/assets/student-form-CT0ez3q6.js"]
	},
	"/admin/employees/": {
		filePath: "/workspace/src/routes/admin/employees/index.tsx",
		children: void 0,
		preloads: [
			"/assets/employees-Ba6il3_s.js",
			"/assets/data-table-BBgoBUDR.js",
			"/assets/stat-card-DGjAgg_7.js",
			"/assets/avatar-BnyUIOsG.js",
			"/assets/format-BTt5poIw.js",
			"/assets/page-header-DkWFyslZ.js",
			"/assets/badge-0_uWSpCw.js"
		]
	},
	"/admin/students/": {
		filePath: "/workspace/src/routes/admin/students/index.tsx",
		children: void 0,
		preloads: ["/assets/students-DA8mhMbY.js", "/assets/students-page-CZMW6isA.js"]
	},
	"/employee/students/": {
		filePath: "/workspace/src/routes/employee/students/index.tsx",
		children: void 0,
		preloads: ["/assets/students-DS3glSL1.js", "/assets/students-page-CZMW6isA.js"]
	},
	"/admin/students/$id/edit": {
		filePath: "/workspace/src/routes/admin/students/$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/_id.edit-BgPZyo90.js", "/assets/student-form-CT0ez3q6.js"]
	},
	"/employee/students/$id/edit": {
		filePath: "/workspace/src/routes/employee/students/$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/_id.edit-vKE9CFJV.js", "/assets/student-form-CT0ez3q6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
